# Integracja z main.js — GUI wyboru okna/aplikacji z wyszukiwarką

Ten plik NIE jest częścią wtyczki (appka go nie wczyta) — to instrukcja
dla Ciebie, żeby dodać opcjonalną obsługę po stronie hosta.

## Jak to działa bez tej integracji

Wtyczka sprawdza, czy appka wystawia `window.sigmanek.desktopSources()`.
Jeśli nie — po prostu używa normalnego, natywnego selektora przeglądarki
(`getDisplayMedia`, bez pola do wpisywania szukanej nazwy, ale ze
wszystkimi oknami/ekranami z miniaturkami do wyboru). **Wtyczka działa
w pełni już teraz, bez żadnych zmian w main.js.**

Poniższa integracja dodaje tylko **własne okienko z polem "Szukaj"**, które
filtruje listę okien/aplikacji po nazwie w czasie rzeczywistym.

## 1. main.js — desktopCapturer + IPC

```js
const { desktopCapturer, ipcMain, session } = require('electron');

// Lista źródeł do wyświetlenia w GUI wtyczki (z miniaturkami)
ipcMain.handle('nagrywanie-ekranu:list-sources', async () => {
  const sources = await desktopCapturer.getSources({
    types: ['window', 'screen'],
    thumbnailSize: { width: 300, height: 200 },
    fetchWindowIcons: true,
  });
  return sources.map(s => ({
    id: s.id,
    name: s.name,
    thumbnail: s.thumbnail.isEmpty() ? null : s.thumbnail.toDataURL(),
    appIcon: s.appIcon && !s.appIcon.isEmpty() ? s.appIcon.toDataURL() : null,
  }));
});

// Zapamiętujemy, co user wybrał w GUI wtyczki
let pendingSourceId = null;
ipcMain.handle('nagrywanie-ekranu:select-source', (event, sourceId) => {
  pendingSourceId = sourceId;
  return true;
});

// Podpiąć RAZ (np. przy starcie appki / tworzeniu głównego okna).
// Dzięki temu getDisplayMedia() wywołane z wtyczki NIE pokaże
// dodatkowego natywnego okienka — od razu zwróci wybrane wcześniej źródło.
session.defaultSession.setDisplayMediaRequestHandler((request, callback) => {
  desktopCapturer.getSources({ types: ['window', 'screen'] }).then(sources => {
    const chosen = sources.find(s => s.id === pendingSourceId) || sources[0];
    callback({
      video: chosen,
      audio: 'loopback', // dźwięk systemowy — działa tylko na Windows
    });
  });
}, { useSystemPicker: false });
```

## 2. preload.js — dopisz do istniejącego `contextBridge.exposeInMainWorld('sigmanek', {...})`

```js
contextBridge.exposeInMainWorld('sigmanek', {
  // ...Twoje istniejące metody (perf, goToLobby, account, openExternal)...

  desktopSources: () => ipcRenderer.invoke('nagrywanie-ekranu:list-sources'),
  selectDesktopSource: (id) => ipcRenderer.invoke('nagrywanie-ekranu:select-source', id),
});
```

## Uwagi

- `audio: 'loopback'` (dźwięk systemowy przechwytywany automatycznie przy
  wyborze źródła) działa tylko na Windows. Na macOS/Linux ustaw
  `audio: false` w `callback(...)` — user i tak może dograć mikrofon,
  wtyczka to obsłuży sama.
- Jeśli robisz to samo dla kolejnej wtyczki, możesz uogólnić kanały IPC
  (np. `desktop-capture:list-sources` bez prefiksu `nagrywanie-ekranu:`),
  żeby jeden handler obsługiwał wszystkie wtyczki na raz.
- `setDisplayMediaRequestHandler` jest globalny dla sesji — jeśli inne
  części appki też używają `getDisplayMedia`, upewnij się, że nie
  nadpiszesz się nawzajem.
