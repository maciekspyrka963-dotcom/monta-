# Integracja z main.js — wybór ekranu/okna w Electronie

Ten plik NIE jest częścią wtyczki (appka go nie wczyta) — to instrukcja
dla Ciebie, do zmian w kodzie hosta (appki).

**Ważne: to, co poniżej pozwala nagrywać CAŁY EKRAN i DOWOLNE OKNO w systemie
— gry, przeglądarkę, Discorda, cokolwiek — a nie tylko okno appki Sigmanek.
`desktopCapturer.getSources({ types: ['window', 'screen'] })` zwraca listę
WSZYSTKICH okien otwartych w systemie (w tym gry) oraz cały ekran/ekrany.
Okno samej appki Sigmanek to tylko jedna pozycja na tej liście, tak jak
każde inne okno.**

## ⚠️ WYMAGANE — bez tego wtyczka nie zadziała wcale

Electron, w przeciwieństwie do zwykłej przeglądarki, **nie ma wbudowanego
natywnego okienka wyboru ekranu/okna**. Wywołanie `getDisplayMedia()`
z poziomu wtyczki (czy jakiejkolwiek strony renderowanej w Electronie)
zawsze zakończy się błędem:

```
DOMException: Not supported
```

...dopóki w procesie main nie zarejestrujesz handlera. To nie jest
opcjonalne ulepszenie — bez tego kroku funkcja nagrywania w ogóle się
nie uruchomi, niezależnie od tego jak wtyczka jest napisana.

### Minimalna wersja (main.js)

```js
const { session, desktopCapturer } = require('electron');

session.defaultSession.setDisplayMediaRequestHandler(async (request, callback) => {
  const sources = await desktopCapturer.getSources({ types: ['window', 'screen'] });
  // Bez własnego GUI: bierzemy po prostu cały ekran główny —
  // to WYSTARCZY, żeby nagrać grę działającą na pełnym ekranie
  // (grę, pulpit, cokolwiek), bo 'screen' to obraz całego monitora.
  const screen = sources.find(s => s.id.startsWith('screen')) || sources[0];
  callback({ video: screen, audio: 'loopback' }); // 'loopback' = dźwięk systemowy, tylko Windows
});
```

To wystarczy, żeby przycisk „Wybierz co nagrywać” w wtyczce zadziałał —
i już teraz pozwoli nagrać cały ekran (czyli i grę, i cokolwiek innego na
nim). Jedyne czego brakuje w tej wersji: user nie wybiera konkretnego
OKNA (np. samej gry, jeśli chce ją nagrać w oknie, a nie cały pulpit) —
appka zawsze bierze cały ekran. Żeby dać wybór konkretnego okna/aplikacji
(to, co wtyczka pokazuje domyślnie w swoim GUI), potrzebna jest pełna
wersja niżej.

## Pełna wersja — GUI z wyszukiwarką po nazwie (jak w wtyczce)

Wtyczka sama w sobie ma gotowy modal z polem „Szukaj” i siatką miniaturek
(`index.html` / `script.js`, funkcja `openSourceModal`). Lista, którą tam
zobaczy user, będzie zawierać WSZYSTKIE otwarte okna w systemie — w tym
grę, jeśli jest uruchomiona — plus opcje całego ekranu. Modal uruchomi się
automatycznie, jeśli appka wystawi `window.sigmanek.desktopSources()`.

### 1. main.js

```js
const { desktopCapturer, ipcMain, session } = require('electron');

// Lista źródeł do wyświetlenia w GUI wtyczki (z miniaturkami) —
// obejmuje WSZYSTKIE okna w systemie (gry, przeglądarki, itd.) + ekrany.
ipcMain.handle('nagrywanie-ekranu:list-sources', async () => {
  const sources = await desktopCapturer.getSources({
    types: ['window', 'screen'],
    thumbnailSize: { width: 300, height: 200 },
    fetchWindowIcons: true,
  });
  return sources.map(s => ({
    id: s.id,
    name: s.name,
    thumbnail: s.thumbnail.isEmpty() ? null : s.thumbnail.toDataURL(),
    appIcon: s.appIcon && !s.appIcon.isEmpty() ? s.appIcon.toDataURL() : null,
  }));
});

// Zapamiętujemy, co user wybrał w GUI wtyczki
let pendingSourceId = null;
ipcMain.handle('nagrywanie-ekranu:select-source', (event, sourceId) => {
  pendingSourceId = sourceId;
  return true;
});

// Podpiąć RAZ (np. przy starcie appki / tworzeniu głównego okna).
// To ZASTĘPUJE minimalną wersję z sekcji wyżej — nie dodawaj obu naraz.
session.defaultSession.setDisplayMediaRequestHandler(async (request, callback) => {
  const sources = await desktopCapturer.getSources({ types: ['window', 'screen'] });
  const chosen = sources.find(s => s.id === pendingSourceId) || sources[0];
  callback({
    video: chosen,
    audio: 'loopback', // dźwięk systemowy — działa tylko na Windows
  });
});
```

### 2. preload.js — dopisz do istniejącego `contextBridge.exposeInMainWorld('sigmanek', {...})`

```js
contextBridge.exposeInMainWorld('sigmanek', {
  // ...Twoje istniejące metody (perf, goToLobby, account, openExternal)...

  desktopSources: () => ipcRenderer.invoke('nagrywanie-ekranu:list-sources'),
  selectDesktopSource: (id) => ipcRenderer.invoke('nagrywanie-ekranu:select-source', id),
});
```

Jeśli te dwie metody NIE są wystawione, wtyczka automatycznie nie pokaże
modala z wyszukiwarką — spróbuje zwykłego `getDisplayMedia()`, co zadziała
tylko jeśli dodałeś przynajmniej minimalną wersję z sekcji wyżej.

## Testowanie po zmianie main.js/preload.js

1. Zapisz zmiany, `npm start`.
2. **Odpal jakąś grę / inną appkę w tle** — to właśnie ma być nagrywane.
3. Otwórz appkę Sigmanek, wejdź w wtyczkę, kliknij „Wybierz co nagrywać”.
4. Jeśli masz pełną wersję: powinieneś zobaczyć na liście m.in. okno tej
   gry (i cały ekran jako osobną opcję) — wybierz je, kliknij Start,
   przełącz się do gry i graj, appka nagrywa w tle.
5. Sprawdź konsolę (`Ctrl+Shift+I` w oknie Electrona) — jeśli nadal widzisz
   `DOMException: Not supported`, handler się nie podpiął (sprawdź, czy
   `setDisplayMediaRequestHandler` jest wywołane zanim wtyczka próbuje
   nagrywać, i czy nie masz dwóch konfliktujących wywołań tej metody
   w różnych miejscach kodu).

## Uwagi

- `audio: 'loopback'` (dźwięk systemowy przechwytywany automatycznie przy
  wyborze źródła — czyli np. dźwięk z gry) działa tylko na Windows.
  Na macOS/Linux ustaw `audio: false` w `callback(...)` — user i tak
  może dograć mikrofon, wtyczka to obsłuży sama (opcja „Tylko mikrofon” /
  „Systemowy + mikrofon”).
- Jeśli robisz to samo dla kolejnej wtyczki, możesz uogólnić kanały IPC
  (np. `desktop-capture:list-sources` bez prefiksu `nagrywanie-ekranu:`),
  żeby jeden handler obsługiwał wszystkie wtyczki na raz.
- `setDisplayMediaRequestHandler` jest globalny dla sesji — jeśli inne
  części appki też używają `getDisplayMedia`, upewnij się, że nie
  nadpiszesz się nawzajem (powinien być podpięty raz, w jednym miejscu).
