(() => {
  "use strict";

  // ---------- Elementy UI ----------
  const pickSourceBtn   = document.getElementById("pickSourceBtn");
  const sourceStatus    = document.getElementById("sourceStatus");
  const qualitySelect   = document.getElementById("qualitySelect");
  const fpsSelect       = document.getElementById("fpsSelect");
  const bitrateMode     = document.getElementById("bitrateMode");
  const manualBitrateWrap = document.getElementById("manualBitrateWrap");
  const manualBitrate   = document.getElementById("manualBitrate");
  const manualBitrateVal = document.getElementById("manualBitrateVal");
  const manualBitrateMbps = document.getElementById("manualBitrateMbps");
  const audioModeSelect = document.getElementById("audioModeSelect");
  const micDeviceWrap   = document.getElementById("micDeviceWrap");
  const micDeviceSelect = document.getElementById("micDeviceSelect");
  const showCursorChk   = document.getElementById("showCursorChk");
  const customQualityWrap = document.getElementById("customQualityWrap");
  const customWidth  = document.getElementById("customWidth");
  const customHeight = document.getElementById("customHeight");

  const sourceModal = document.getElementById("sourceModal");
  const sourceModalClose = document.getElementById("sourceModalClose");
  const sourceSearch = document.getElementById("sourceSearch");
  const sourceGrid = document.getElementById("sourceGrid");

  const startBtn = document.getElementById("startBtn");
  const pauseBtn = document.getElementById("pauseBtn");
  const stopBtn  = document.getElementById("stopBtn");
  const statusLine = document.getElementById("statusLine");
  const recBadge = document.getElementById("recBadge");
  const recTimer = document.getElementById("recTimer");

  const previewCard  = document.getElementById("previewCard");
  const previewVideo = document.getElementById("previewVideo");
  const trimStart = document.getElementById("trimStart");
  const trimEnd   = document.getElementById("trimEnd");
  const trimStartVal = document.getElementById("trimStartVal");
  const trimEndVal   = document.getElementById("trimEndVal");
  const trimSpeed = document.getElementById("trimSpeed");
  const previewTrimBtn = document.getElementById("previewTrimBtn");
  const downloadFullBtn = document.getElementById("downloadFullBtn");
  const downloadTrimBtn = document.getElementById("downloadTrimBtn");
  const resetBtn = document.getElementById("resetBtn");
  const fileInfo = document.getElementById("fileInfo");
  const trimProgressWrap = document.getElementById("trimProgressWrap");
  const trimProgressFill = document.getElementById("trimProgressFill");
  const trimProgressLabel = document.getElementById("trimProgressLabel");

  // ---------- Stan ----------
  let displayStream = null;   // stream z getDisplayMedia (obraz + ew. audio systemowe)
  let micStream = null;       // stream z mikrofonu
  let recordStream = null;    // finalny stream przekazywany do MediaRecordera
  let audioCtx = null;        // do miksowania audio (system + mikrofon)
  let mediaRecorder = null;
  let chunks = [];
  let recordedBlob = null;
  let recordedUrl = null;

  let timerInterval = null;
  let recordStartTs = 0;
  let pausedAccum = 0;
  let pauseStartTs = 0;

  // ---------- Pomoc: presety jakości ----------
  const QUALITY_PRESETS = {
    "480":  { width: 854,  height: 480 },
    "720":  { width: 1280, height: 720 },
    "1080": { width: 1920, height: 1080 },
    "1440": { width: 2560, height: 1440 },
    "2160": { width: 3840, height: 2160 },
  };

  function getSelectedQuality() {
    if (qualitySelect.value === "custom") {
      const w = Math.max(160, Math.min(7680, Number(customWidth.value) || 1920));
      const h = Math.max(90, Math.min(4320, Number(customHeight.value) || 1080));
      return { width: w, height: h };
    }
    return QUALITY_PRESETS[qualitySelect.value] || QUALITY_PRESETS["1080"];
  }

  qualitySelect.addEventListener("change", () => {
    customQualityWrap.style.display = qualitySelect.value === "custom" ? "" : "none";
  });

  function computeAutoBitrate(width, height, fps) {
    // Skaluje się płynnie z każdą rozdzielczością (także niestandardową):
    // ok. 2.4 bita na piksel przy 1080p/30fps jako punkt odniesienia,
    // tak by obraz był czytelny bez zbędnego obciążania CPU/dysku.
    const bitsPerPixelAt1080p30 = 5_000_000 / (1920 * 1080);
    let bitrate = width * height * bitsPerPixelAt1080p30;
    const fpsFactor = fps >= 60 ? 1.5 : fps >= 48 ? 1.3 : fps >= 30 ? 1.0 : fps >= 24 ? 0.85 : 0.6;
    bitrate *= fpsFactor;
    // trzymaj się w granicach suwaka ręcznego (1000 kbps – 100 000 kbps)
    return Math.round(Math.min(100_000_000, Math.max(1_000_000, bitrate)));
  }

  function pickMimeType() {
    const candidates = [
      "video/webm;codecs=vp9,opus",
      "video/webm;codecs=vp8,opus",
      "video/webm;codecs=h264,opus",
      "video/webm",
    ];
    for (const c of candidates) {
      if (window.MediaRecorder && MediaRecorder.isTypeSupported(c)) return c;
    }
    return ""; // przeglądarka sama wybierze
  }

  function fmtTime(totalSeconds) {
    const s = Math.max(0, Math.floor(totalSeconds));
    const hh = String(Math.floor(s / 3600)).padStart(2, "0");
    const mm = String(Math.floor((s % 3600) / 60)).padStart(2, "0");
    const ss = String(s % 60).padStart(2, "0");
    return `${hh}:${mm}:${ss}`;
  }

  function fmtShort(t) {
    const m = Math.floor(t / 60);
    const s = (t % 60).toFixed(1);
    return `${String(m).padStart(2, "0")}:${s.padStart(4, "0")}`;
  }

  // ---------- Krok 1: wybór źródła ----------
  // Jeśli appka-host wystawia window.sigmanek.desktopSources() (patrz
  // INTEGRACJA_HOST.md dołączony do wtyczki), otwieramy własne GUI z
  // wyszukiwarką po nazwie aplikacji/okna i miniaturkami. W przeciwnym
  // razie — normalny natywny selektor przeglądarki (bez pola szukania,
  // ale zawsze działa, bez żadnej dodatkowej konfiguracji).
  pickSourceBtn.addEventListener("click", async () => {
    stopAllTracks();
    if (window.sigmanek && typeof window.sigmanek.desktopSources === "function") {
      openSourceModal();
    } else {
      await pickViaNativePicker();
    }
  });

  async function openSourceModal() {
    sourceModal.hidden = false;
    sourceSearch.value = "";
    sourceGrid.innerHTML = `<p class="hint" id="sourceGridEmpty">Ładowanie listy…</p>`;
    sourceSearch.focus();
    try {
      const sources = await window.sigmanek.desktopSources(); // [{id, name, thumbnail, appIcon}]
      renderSourceGrid(sources);
    } catch (err) {
      console.error(err);
      sourceGrid.innerHTML = `<p class="hint">❌ Nie udało się pobrać listy okien/aplikacji. Spróbuj ponownie.</p>`;
    }
  }

  function renderSourceGrid(sources) {
    if (!sources || sources.length === 0) {
      sourceGrid.innerHTML = `<p class="hint">Brak dostępnych okien/ekranów.</p>`;
      return;
    }
    sourceGrid.innerHTML = "";
    sources.forEach((s) => {
      const item = document.createElement("button");
      item.className = "source-item";
      item.type = "button";
      item.dataset.name = (s.name || "").toLowerCase();
      item.innerHTML = `
        ${s.thumbnail ? `<img class="source-thumb" src="${s.thumbnail}" alt="" />` : `<div class="source-thumb"></div>`}
        <div class="source-item-label">
          ${s.appIcon ? `<img src="${s.appIcon}" alt="" />` : ""}
          <span>${escapeHtml(s.name || "Bez nazwy")}</span>
        </div>`;
      item.addEventListener("click", () => selectDesktopSource(s));
      sourceGrid.appendChild(item);
    });
  }

  function escapeHtml(str) {
    const d = document.createElement("div");
    d.textContent = str;
    return d.innerHTML;
  }

  sourceSearch.addEventListener("input", () => {
    const q = sourceSearch.value.trim().toLowerCase();
    document.querySelectorAll(".source-item").forEach((el) => {
      el.classList.toggle("hidden-by-search", q && !el.dataset.name.includes(q));
    });
  });

  sourceModalClose.addEventListener("click", () => { sourceModal.hidden = true; });
  sourceModal.addEventListener("click", (e) => { if (e.target === sourceModal) sourceModal.hidden = true; });

  async function selectDesktopSource(source) {
    try {
      // Mówimy hostowi, którego źródła użyć przy najbliższym
      // navigator.mediaDevices.getDisplayMedia (patrz INTEGRACJA_HOST.md).
      if (typeof window.sigmanek.selectDesktopSource === "function") {
        await window.sigmanek.selectDesktopSource(source.id);
      }
      sourceModal.hidden = true;
      await pickViaNativePicker(source.name);
    } catch (err) {
      console.error(err);
      sourceStatus.textContent = "❌ Nie udało się wybrać źródła.";
    }
  }

  async function pickViaNativePicker(knownName) {
    try {
      const q = getSelectedQuality();
      const fps = Number(fpsSelect.value);
      const audioMode = audioModeSelect.value;

      displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          width: { ideal: q.width },
          height: { ideal: q.height },
          frameRate: { ideal: fps, max: fps },
        },
        audio: audioMode === "system" || audioMode === "both",
        preferCurrentTab: false,
      });

      const track = displayStream.getVideoTracks()[0];
      const settings = track.getSettings ? track.getSettings() : {};
      const label = knownName || track.label || "wybrane źródło";

      sourceStatus.textContent = `✅ Wybrano: ${label}` +
        (settings.width ? ` (${settings.width}×${settings.height})` : "");
      statusLine.textContent = "Źródło gotowe — możesz kliknąć Start.";
      startBtn.disabled = false;

      track.addEventListener("ended", () => {
        if (mediaRecorder && mediaRecorder.state !== "inactive") {
          stopRecording();
        }
        sourceStatus.textContent = "⚠️ Udostępnianie zakończone przez system. Wybierz źródło ponownie.";
        startBtn.disabled = true;
      });

    } catch (err) {
      console.error(err);
      if (err && (err.name === "NotSupportedError" || /not supported/i.test(err.message || ""))) {
        sourceStatus.textContent =
          "❌ Ta appka (Electron) nie ma jeszcze skonfigurowanego wyboru ekranu w main.js — " +
          "bez tego nagrywanie nie zadziała. Zobacz plik INTEGRACJA_HOST.md dołączony do wtyczki " +
          "(sekcja „Wymagane”) i dodaj session.setDisplayMediaRequestHandler.";
      } else if (err && err.name === "NotAllowedError") {
        sourceStatus.textContent = "❌ Nie wybrano źródła (anulowano lub brak zgody systemu).";
      } else {
        sourceStatus.textContent = "❌ Nie udało się wybrać źródła: " + (err && err.message ? err.message : "nieznany błąd");
      }
    }
  }

  function stopAllTracks() {
    [displayStream, micStream, recordStream].forEach(s => {
      if (s) s.getTracks().forEach(t => t.stop());
    });
    displayStream = null;
    micStream = null;
    recordStream = null;
    if (audioCtx) {
      audioCtx.close().catch(() => {});
      audioCtx = null;
    }
  }

  // ---------- UI: tryb bitrate ----------
  bitrateMode.addEventListener("change", () => {
    manualBitrateWrap.style.display = bitrateMode.value === "manual" ? "" : "none";
  });
  manualBitrate.addEventListener("input", () => {
    manualBitrateVal.textContent = manualBitrate.value;
    manualBitrateMbps.textContent = (Number(manualBitrate.value) / 1000).toFixed(1);
  });

  // ---------- Tryb audio + wybór konkretnego mikrofonu ----------
  audioModeSelect.addEventListener("change", async () => {
    const wantsMic = audioModeSelect.value === "mic" || audioModeSelect.value === "both";
    micDeviceWrap.style.display = wantsMic ? "" : "none";
    if (wantsMic) await refreshMicDevices();
  });

  async function refreshMicDevices() {
    try {
      // Etykiety urządzeń są puste dopóki user nie zezwoli na mikrofon —
      // więc najpierw krótko prosimy o dostęp, żeby odblokować nazwy.
      let tmpStream = null;
      const devicesBefore = await navigator.mediaDevices.enumerateDevices();
      const needsPermission = devicesBefore
        .filter(d => d.kind === "audioinput")
        .every(d => !d.label);
      if (needsPermission) {
        tmpStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      }

      const devices = await navigator.mediaDevices.enumerateDevices();
      const mics = devices.filter(d => d.kind === "audioinput");

      micDeviceSelect.innerHTML = '<option value="">(domyślny)</option>' +
        mics.map((m, i) => `<option value="${m.deviceId}">${escapeHtml(m.label || "Mikrofon " + (i + 1))}</option>`).join("");

      if (tmpStream) tmpStream.getTracks().forEach(t => t.stop());
    } catch (err) {
      console.error(err);
      micDeviceSelect.innerHTML = '<option value="">(domyślny — brak dostępu do listy)</option>';
    }
  }

  // ---------- Krok 2: start / pauza / stop ----------
  startBtn.addEventListener("click", async () => {
    if (!displayStream) return;

    try {
      // mikrofon (opcjonalnie, z wybranym urządzeniem jeśli wskazane)
      const audioMode = audioModeSelect.value;
      if (audioMode === "mic" || audioMode === "both") {
        const deviceId = micDeviceSelect.value;
        micStream = await navigator.mediaDevices.getUserMedia({
          audio: deviceId ? { deviceId: { exact: deviceId } } : true,
        });
      }

      recordStream = await buildFinalStream();

      const fps = Number(fpsSelect.value);
      const q = getSelectedQuality();
      const videoBitsPerSecond = bitrateMode.value === "manual"
        ? Number(manualBitrate.value) * 1000   // suwak jest w kbps (1000–100000)
        : computeAutoBitrate(q.width, q.height, fps);

      const mimeType = pickMimeType();
      const options = { videoBitsPerSecond };
      if (mimeType) options.mimeType = mimeType;

      chunks = [];
      mediaRecorder = new MediaRecorder(recordStream, options);

      mediaRecorder.addEventListener("dataavailable", (e) => {
        if (e.data && e.data.size > 0) chunks.push(e.data);
      });

      mediaRecorder.addEventListener("stop", onRecorderStopped);

      // timeslice 1000ms: dane trafiają na bieżąco do pamięci kawałkami,
      // zamiast czekać na koniec — mniejsze ryzyko utraty danych i lagów.
      mediaRecorder.start(1000);

      recordStartTs = Date.now();
      pausedAccum = 0;
      startTimer();

      recBadge.classList.add("live");
      startBtn.disabled = true;
      pauseBtn.disabled = false;
      stopBtn.disabled = false;
      pickSourceBtn.disabled = true;
      statusLine.textContent = "🔴 Trwa nagrywanie…";
      previewCard.style.display = "none";

    } catch (err) {
      console.error(err);
      statusLine.textContent = "❌ Nie udało się uruchomić nagrywania (sprawdź mikrofon/uprawnienia).";
    }
  });

  async function buildFinalStream() {
    const videoTrack = displayStream.getVideoTracks()[0];
    const systemAudioTracks = displayStream.getAudioTracks();
    const micTracks = micStream ? micStream.getAudioTracks() : [];

    // Brak dodatkowego audio -> po prostu użyj oryginalnego wideo + ewentualnie
    // system audio bez dodatkowego przetwarzania (najlżejsza opcja).
    if (micTracks.length === 0) {
      return displayStream;
    }

    // Trzeba zmiksować system audio + mikrofon w jeden tor -> Web Audio API.
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const destination = audioCtx.createMediaStreamDestination();

    if (systemAudioTracks.length > 0) {
      const sysSource = audioCtx.createMediaStreamSource(new MediaStream(systemAudioTracks));
      sysSource.connect(destination);
    }
    const micSource = audioCtx.createMediaStreamSource(new MediaStream(micTracks));
    micSource.connect(destination);

    const finalStream = new MediaStream();
    finalStream.addTrack(videoTrack);
    destination.stream.getAudioTracks().forEach(t => finalStream.addTrack(t));
    return finalStream;
  }

  pauseBtn.addEventListener("click", () => {
    if (!mediaRecorder) return;
    if (mediaRecorder.state === "recording") {
      mediaRecorder.pause();
      pauseStartTs = Date.now();
      pauseBtn.textContent = "▶ Wznów";
      statusLine.textContent = "⏸ Pauza.";
      recBadge.classList.remove("live");
    } else if (mediaRecorder.state === "paused") {
      mediaRecorder.resume();
      pausedAccum += Date.now() - pauseStartTs;
      pauseBtn.textContent = "⏸ Pauza";
      statusLine.textContent = "🔴 Trwa nagrywanie…";
      recBadge.classList.add("live");
    }
  });

  stopBtn.addEventListener("click", stopRecording);

  function stopRecording() {
    if (!mediaRecorder || mediaRecorder.state === "inactive") return;
    mediaRecorder.stop();
    stopTimer();
    recBadge.classList.remove("live");
    startBtn.disabled = true;
    pauseBtn.disabled = true;
    stopBtn.disabled = true;
    pickSourceBtn.disabled = false;
    pauseBtn.textContent = "⏸ Pauza";
    statusLine.textContent = "Przetwarzanie nagrania…";
  }

  function onRecorderStopped() {
    recordedBlob = new Blob(chunks, { type: mediaRecorder.mimeType || "video/webm" });
    if (recordedUrl) URL.revokeObjectURL(recordedUrl);
    recordedUrl = URL.createObjectURL(recordedBlob);

    previewVideo.src = recordedUrl;
    previewCard.style.display = "";
    statusLine.textContent = "✅ Nagranie gotowe. Wybierz źródło ponownie, aby nagrać kolejny materiał.";

    const sizeMb = (recordedBlob.size / (1024 * 1024)).toFixed(1);
    fileInfo.textContent = `Rozmiar: ${sizeMb} MB`;

    previewVideo.addEventListener("loadedmetadata", () => {
      const dur = previewVideo.duration;
      trimStart.max = dur;
      trimEnd.max = dur;
      trimEnd.value = dur;
      trimStartVal.textContent = fmtShort(0);
      trimEndVal.textContent = fmtShort(dur);
    }, { once: true });

    // zwolnij strumienie źródłowe — nagranie jest już zapisane w pamięci jako blob
    stopAllTracks();
  }

  // ---------- Timer ----------
  function startTimer() {
    stopTimer();
    timerInterval = setInterval(() => {
      const elapsed = (Date.now() - recordStartTs - pausedAccum) / 1000;
      recTimer.textContent = fmtTime(elapsed);
    }, 500);
  }
  function stopTimer() {
    if (timerInterval) clearInterval(timerInterval);
    timerInterval = null;
  }

  // ---------- Przycinanie ----------
  trimStart.addEventListener("input", () => {
    let s = Number(trimStart.value);
    let e = Number(trimEnd.value);
    if (s >= e) { s = Math.max(0, e - 0.2); trimStart.value = s; }
    trimStartVal.textContent = fmtShort(s);
  });
  trimEnd.addEventListener("input", () => {
    let s = Number(trimStart.value);
    let e = Number(trimEnd.value);
    if (e <= s) { e = s + 0.2; trimEnd.value = e; }
    trimEndVal.textContent = fmtShort(e);
  });

  previewTrimBtn.addEventListener("click", () => {
    const s = Number(trimStart.value);
    const e = Number(trimEnd.value);
    previewVideo.currentTime = s;
    previewVideo.play();
    const stopAt = () => {
      if (previewVideo.currentTime >= e) {
        previewVideo.pause();
        previewVideo.removeEventListener("timeupdate", stopAt);
      }
    };
    previewVideo.addEventListener("timeupdate", stopAt);
  });

  // ---------- Pobieranie pełnego nagrania ----------
  downloadFullBtn.addEventListener("click", () => {
    if (!recordedBlob) return;
    triggerDownload(recordedBlob, buildFileName("nagranie"));
  });

  function buildFileName(prefix) {
    const now = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    const stamp = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}_${pad(now.getHours())}-${pad(now.getMinutes())}`;
    return `${prefix}_${stamp}.webm`;
  }

  function triggerDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  // ---------- Przytnij i pobierz (re-render przez canvas) ----------
  downloadTrimBtn.addEventListener("click", async () => {
    if (!recordedBlob) return;
    const s = Number(trimStart.value);
    const e = Number(trimEnd.value);
    const speed = Number(trimSpeed.value);
    if (e - s < 0.2) {
      fileInfo.textContent = "Zaznacz co najmniej 0.2s materiału do przycięcia.";
      return;
    }

    downloadTrimBtn.disabled = true;
    trimProgressWrap.style.display = "";
    trimProgressFill.style.width = "0%";
    trimProgressLabel.textContent = "Przygotowywanie…";

    try {
      const trimmedBlob = await renderTrimmedClip(recordedUrl, s, e, speed, (pct, label) => {
        trimProgressFill.style.width = `${pct}%`;
        if (label) trimProgressLabel.textContent = label;
      });
      triggerDownload(trimmedBlob, buildFileName("nagranie_przyciete"));
      trimProgressLabel.textContent = "Gotowe ✅";
    } catch (err) {
      console.error(err);
      trimProgressLabel.textContent = "❌ Błąd podczas przycinania.";
    } finally {
      downloadTrimBtn.disabled = false;
      setTimeout(() => { trimProgressWrap.style.display = "none"; }, 2500);
    }
  });

  function renderTrimmedClip(sourceUrl, start, end, speed, onProgress) {
    return new Promise((resolve, reject) => {
      const srcVideo = document.createElement("video");
      srcVideo.src = sourceUrl;
      srcVideo.muted = false;
      srcVideo.preload = "auto";
      // szybszy eksport = szybsze odtwarzanie podczas re-nagrywania
      srcVideo.playbackRate = speed;

      srcVideo.addEventListener("loadedmetadata", () => {
        srcVideo.currentTime = start;

        srcVideo.addEventListener("seeked", () => {
          try {
            const canvas = document.createElement("canvas");
            canvas.width = srcVideo.videoWidth;
            canvas.height = srcVideo.videoHeight;
            const ctx = canvas.getContext("2d");

            const fps = Number(fpsSelect.value) || 30;
            const canvasStream = canvas.captureStream(fps);

            // audio: przechwyć dźwięk odtwarzanego <video> przez Web Audio API
            let mixedStream = canvasStream;
            try {
              const ac = new (window.AudioContext || window.webkitAudioContext)();
              const srcNode = ac.createMediaElementSource(srcVideo);
              const dest = ac.createMediaStreamDestination();
              srcNode.connect(dest);
              // podłączamy też do głośników, żeby użytkownik mógł wyciszyć kartę
              // (opcjonalnie — tu pomijamy, żeby nie dublować dźwięku na głos)
              dest.stream.getAudioTracks().forEach(t => mixedStream.addTrack(t));
              srcVideo._audioCtxRef = ac; // zachowaj referencję do zamknięcia później
            } catch (audioErr) {
              console.warn("Brak audio w przyciętym klipie:", audioErr);
            }

            const mimeType = pickMimeType();
            const recOptions = mimeType ? { mimeType } : {};
            const outRecorder = new MediaRecorder(mixedStream, recOptions);
            const outChunks = [];

            outRecorder.addEventListener("dataavailable", (e) => {
              if (e.data && e.data.size > 0) outChunks.push(e.data);
            });

            outRecorder.addEventListener("stop", () => {
              if (srcVideo._audioCtxRef) srcVideo._audioCtxRef.close().catch(() => {});
              const blob = new Blob(outChunks, { type: outRecorder.mimeType || "video/webm" });
              resolve(blob);
            });

            const duration = (end - start) / speed;
            let rafId;

            const drawFrame = () => {
              if (srcVideo.currentTime >= end || srcVideo.paused || srcVideo.ended) {
                return;
              }
              ctx.drawImage(srcVideo, 0, 0, canvas.width, canvas.height);
              const pct = Math.min(100, ((srcVideo.currentTime - start) / (end - start)) * 100);
              onProgress(pct, `Przetwarzanie… ${pct.toFixed(0)}%`);
              rafId = requestAnimationFrame(drawFrame);
            };

            srcVideo.addEventListener("timeupdate", function checkEnd() {
              if (srcVideo.currentTime >= end) {
                srcVideo.removeEventListener("timeupdate", checkEnd);
                srcVideo.pause();
                cancelAnimationFrame(rafId);
                outRecorder.stop();
              }
            });

            outRecorder.start(500);
            srcVideo.play().then(() => {
              rafId = requestAnimationFrame(drawFrame);
            }).catch(reject);

            // zabezpieczenie: twardy limit czasu (2x spodziewany czas + 5s)
            setTimeout(() => {
              if (outRecorder.state !== "inactive") {
                srcVideo.pause();
                cancelAnimationFrame(rafId);
                outRecorder.stop();
              }
            }, Math.max(4000, duration * 1000 * 2 + 5000));

          } catch (e) {
            reject(e);
          }
        }, { once: true });
      }, { once: true });

      srcVideo.addEventListener("error", reject);
    });
  }

  // ---------- Reset ----------
  resetBtn.addEventListener("click", () => {
    previewCard.style.display = "none";
    if (recordedUrl) URL.revokeObjectURL(recordedUrl);
    recordedBlob = null;
    recordedUrl = null;
    chunks = [];
    recTimer.textContent = "00:00:00";
    sourceStatus.textContent = "Nic nie wybrano — kliknij, aby wskazać ekran, okno lub kartę.";
    statusLine.textContent = "Wybierz źródło, aby odblokować nagrywanie.";
    startBtn.disabled = true;
    fileInfo.textContent = "";
  });

  // ---------- Sprzątanie przy zamknięciu wtyczki ----------
  window.addEventListener("beforeunload", () => {
    stopAllTracks();
    if (recordedUrl) URL.revokeObjectURL(recordedUrl);
  });

})();
