(function () {
  "use strict";

  /* ============================================================
     SIGMANET — silnik przeglądarki wewnętrznej appki Sigmanek
     Rozpoznaje wyłącznie domeny .sigma i .sgm ORAZ dowolne nazwy
     publiczne z wewnętrznego rejestru (nie są to prawdziwe domeny
     internetowe — działają tylko wewnątrz Sigmanetu).
     ============================================================ */

  // ---------- KONFIGURACJA BACKENDU ----------
  // Podmień na prawdziwy adres po wdrożeniu domains_api.php (patrz DEPLOY.md).
  var API_BASE = "https://sigmanet.ct.ws/domains_api.php";
  var API_ENABLED = API_BASE.indexOf("TU-WPISZ") === -1;
  var API_TIMEOUT_MS = 6000;

  var HOME = "sigmanet.sgm";
  var LEGACY_STORAGE_KEY = "sigmanet_user_sites"; // stare, czysto-lokalne strony (v1)
  var CACHE_KEY = "sigmanet_domains_cache";
  var OWNER_KEY = "sigmanet_owner_token";
  var RESERVED = [HOME, "home.sigma", "sigmapedia.sgm", "gigachad.sigma", "terminal.sgm", "poczta.sgm", "moje.sgm", "hostuj.sgm", "tuba.sgm", "web.sgm"];

  // ---------- pomocnicze ----------
  function esc(str) {
    return String(str || "").replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function tpl(kicker, title, body, extraClass) {
    return (
      '<div class="' + (extraClass || "") + '">' +
      '<span class="kicker">' + esc(kicker) + "</span>" +
      "<h1>" + esc(title) + "</h1>" +
      body +
      "</div>"
    );
  }

  function paragraphs(text) {
    return "<p>" + esc(text || "").split(/\n{2,}/).join("</p><p>") + "</p>";
  }

  function getOwnerToken() {
    var t = localStorage.getItem(OWNER_KEY);
    if (!t) {
      t = "own_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
      localStorage.setItem(OWNER_KEY, t);
    }
    return t;
  }

  function loadLegacySites() {
    try { return JSON.parse(localStorage.getItem(LEGACY_STORAGE_KEY) || "{}"); }
    catch (e) { return {}; }
  }

  function getCache() {
    try { return JSON.parse(localStorage.getItem(CACHE_KEY) || "[]"); }
    catch (e) { return []; }
  }
  function setCache(list) { localStorage.setItem(CACHE_KEY, JSON.stringify(list || [])); }
  function cacheUpsert(record) {
    var list = getCache().filter(function (d) { return d.domain !== record.domain; });
    list.push(record);
    setCache(list);
  }
  function cacheRemove(domain) {
    setCache(getCache().filter(function (d) { return d.domain !== domain; }));
  }

  // ---------- klient API (z timeoutem i pełną obsługą braku backendu) ----------
  function withTimeout(promise, ms) {
    return Promise.race([
      promise,
      new Promise(function (_, rej) { setTimeout(function () { rej(new Error("timeout")); }, ms); })
    ]);
  }

  function apiGet(action, params) {
    if (!API_ENABLED) return Promise.reject(new Error("api-not-configured"));
    var qs = new URLSearchParams(Object.assign({ action: action }, params || {})).toString();
    return withTimeout(fetch(API_BASE + "?" + qs, { method: "GET" }), API_TIMEOUT_MS)
      .then(function (res) { if (!res.ok) throw new Error("http-" + res.status); return res.json(); });
  }

  function apiPost(action, body) {
    if (!API_ENABLED) return Promise.reject(new Error("api-not-configured"));
    return withTimeout(fetch(API_BASE + "?action=" + encodeURIComponent(action), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {})
    }), API_TIMEOUT_MS).then(function (res) { if (!res.ok) throw new Error("http-" + res.status); return res.json(); });
  }

  function fetchDirectory() {
    return apiGet("list", {}).then(function (data) {
      var list = (data && data.items) || [];
      setCache(list);
      return list;
    }).catch(function () { return getCache(); });
  }

  // ---------- walidacja nazw ----------
  function validLocalName(name, suffix) {
    return /^[a-z0-9-]{1,60}$/i.test(name) && (suffix === "sigma" || suffix === "sgm");
  }
  function validPublicName(name) {
    if (!name) return false;
    name = name.trim();
    if (name.length < 2 || name.length > 190) return false;
    if (/\s/.test(name)) return false;
    if (/\.(sigma|sgm)$/i.test(name)) return false; // to zarezerwowane dla adresów lokalnych
    return /^[a-z0-9][a-z0-9.\-]*$/i.test(name);
  }

  // ============================================================
  // WBUDOWANE STRONY
  // ============================================================
  var SITES = {};

  SITES[HOME] = {
    render: function () {
      var body =
        '<p>To wewnętrzna sieć Sigmanka — działa tylko tutaj, w tej appce, nie w zwykłej przeglądarce. Wpisz adres kończący się na <span class="sig-link">.sigma</span> / <span class="sig-link">.sgm</span>, albo wpisz w pasku adresu <code>sgm home</code>, żeby zawsze tu wrócić.</p>' +
        '<p><span class="sig-link" data-nav="hostuj.sgm">🛠 Hostuj własną stronę →</span> &nbsp;·&nbsp; <span class="sig-link" data-nav="moje.sgm">moje węzły</span></p>' +
        '<form class="searchbox" id="homeSearchForm"><input id="homeSearchInput" type="text" placeholder="wpisz adres albo szukaj..." /><button type="submit">Szukaj</button></form>' +
        '<div class="card-grid">' +
          ["sigmapedia.sgm", "gigachad.sigma", "terminal.sgm", "poczta.sgm", "tuba.sgm", "web.sgm", "hostuj.sgm"].map(function (d) {
            return '<div class="site-card" data-nav="' + d + '"><div class="domain">' + d + "</div></div>";
          }).join("") +
        "</div>" +
        '<span class="kicker" style="display:block;margin-top:26px;">WĘZŁY UŻYTKOWNIKÓW</span>' +
        '<div class="card-grid" id="dirList"><p style="font-family:var(--font-mono);font-size:12px;color:var(--ink-soft);">ładowanie rejestru…</p></div>';
      return tpl("SIGMANET // STRONA STARTOWA", "Witaj w sieci Sigma", body);
    },
    afterRender: function () {
      var box = document.getElementById("dirList");
      if (!box) return;
      fetchDirectory().then(function (list) {
        if (!list || !list.length) {
          box.innerHTML = '<p style="font-family:var(--font-mono);font-size:12px;color:var(--ink-soft);">Rejestr jest pusty. Bądź pierwszy — <span class="sig-link" data-nav="hostuj.sgm">hostuj.sgm</span>.</p>';
          return;
        }
        box.innerHTML = list.slice(0, 40).map(function (d) {
          var badge = d.kind === "public" ? "🌐" : "🔒";
          return '<div class="site-card" data-nav="' + esc(d.domain) + '"><div class="domain">' + esc(d.domain) + " " + badge + '</div><div class="desc">' + esc(d.title || "") + "</div></div>";
        }).join("");
      });
    }
  };

  // stary adres — przekierowanie dla wygody
  SITES["home.sigma"] = { render: function () { return SITES[HOME].render(); }, afterRender: function () { return SITES[HOME].afterRender(); } };

  SITES["sigmapedia.sgm"] = {
    render: function (path) {
      if (path === "geneza") {
        return tpl("SIGMAPEDIA // ARTYKUŁ", "Geneza pojęcia",
          "<p>Zapis historii pojawienia się terminu w internetowym slangu.</p>" +
          '<p><span class="sig-link" data-nav="sigmapedia.sgm">← wróć do Sigmapedii</span></p>');
      }
      if (path === "zasady") {
        return tpl("SIGMAPEDIA // ARTYKUŁ", "Nieoficjalna lista zasad",
          "<p>Zbiór żartobliwych „zasad”, traktowany bardziej jako zabawa niż poradnik.</p>" +
          '<p><span class="sig-link" data-nav="sigmapedia.sgm">← wróć do Sigmapedii</span></p>');
      }
      return tpl("SIGMAPEDIA // WOLNA ENCYKLOPEDIA SIECI SIGMA", "Sigmapedia",
        "<p>Mała, żartobliwa encyklopedia appki. Wybierz artykuł:</p>" +
        '<div class="card-grid">' +
        '<div class="site-card" data-nav="sigmapedia.sgm/geneza"><div class="domain">geneza</div></div>' +
        '<div class="site-card" data-nav="sigmapedia.sgm/zasady"><div class="domain">zasady</div></div>' +
        "</div>");
    }
  };

  SITES["gigachad.sigma"] = {
    render: function () {
      return tpl("WĘZEŁ ZWERYFIKOWANY", "gigachad.sigma",
        "<p>Jeden z pierwszych zarejestrowanych adresów w sieci Sigma — istnieje głównie dla żartu.</p>" +
        '<p><span class="sig-link" data-nav="' + HOME + '">← wróć na start</span></p>');
    }
  };

  SITES["terminal.sgm"] = {
    render: function () {
      return tpl("SIGMANET // WĘZEŁ DIAGNOSTYCZNY", "terminal.sgm",
        "<p>Statyczny podgląd „terminala” — czysto dekoracyjny, nic tu się nie uruchamia.</p>" +
        '<pre style="background:#0a0a0d;color:#33e6d8;padding:16px 18px;border-radius:4px;font-family:var(--font-mono);font-size:12px;line-height:1.7;overflow:auto;">' +
        esc("sigma@node-04:~$ status\n> węzeł aktywny · sieć: sigmanet\n> domeny lokalne: .sigma .sgm\n> domeny publiczne: rejestr wewnętrzny\nsigma@node-04:~$ _") +
        "</pre>");
    }
  };

  // ---------- tuba.sgm — odtwarzacz YouTube (oficjalny embed, działa bo serwujemy przez http://127.0.0.1) ----------
  function extractYoutubeId(input) {
    var v = (input || "").trim();
    var m =
      v.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([a-z0-9_-]{6,})/i) ||
      (/^[a-z0-9_-]{6,}$/i.test(v) ? [null, v] : null);
    return m ? m[1] : null;
  }

  // ---------- web.sgm — prawdziwa przeglądarka (Electron <webview>, wymaga webviewTag:true w main.js) ----------
  SITES["web.sgm"] = {
    render: function () {
      var body =
        '<div class="webview-bar" style="display:flex;gap:6px;margin:0 0 10px;">' +
          '<button type="button" id="webBack">←</button>' +
          '<button type="button" id="webForward">→</button>' +
          '<button type="button" id="webReload">⟳</button>' +
          '<input type="text" id="webAddr" placeholder="google.com" style="flex:1;font-family:var(--font-mono);padding:6px 8px;border:1px solid #dcd3ba;border-radius:4px;" />' +
          '<button type="button" id="webGo">Idź</button>' +
        "</div>" +
        '<webview id="webFrame" src="https://www.google.com" style="width:100%;height:520px;border:1px solid #dcd3ba;border-radius:6px;background:#fff;"></webview>';
      return tpl("SIGMANET // WEB", "Prawdziwa przeglądarka", body);
    },
    afterRender: function () {
      var frame = document.getElementById("webFrame");
      var addr = document.getElementById("webAddr");
      function normalize(v) {
        v = (v || "").trim();
        if (!v) return "https://www.google.com";
        if (!/^https?:\/\//i.test(v)) v = "https://" + v;
        return v;
      }
      function go() { var url = normalize(addr.value); frame.src = url; }
      document.getElementById("webGo").addEventListener("click", go);
      addr.addEventListener("keydown", function (e) { if (e.key === "Enter") go(); });
      document.getElementById("webBack").addEventListener("click", function () { if (frame.canGoBack && frame.canGoBack()) frame.goBack(); });
      document.getElementById("webForward").addEventListener("click", function () { if (frame.canGoForward && frame.canGoForward()) frame.goForward(); });
      document.getElementById("webReload").addEventListener("click", function () { if (frame.reload) frame.reload(); });
      frame.addEventListener("did-navigate", function (e) { addr.value = e.url; });
      frame.addEventListener("did-navigate-in-page", function (e) { addr.value = e.url; });
      addr.value = "https://www.google.com";
    }
  };

  SITES["tuba.sgm"] = {
    render: function () {
      return tpl("SIGMANET // TUBA", "Odtwarzacz wideo",
        "<p>Wklej link do YouTube (albo samo ID filmu) — odtworzy się bezpośrednio tutaj, przez oficjalny odtwarzacz YouTube.</p>" +
        '<form class="sig-form" id="tubaForm">' +
          '<div style="display:flex;gap:6px;"><input type="text" id="tubaInput" placeholder="https://youtube.com/watch?v=..." style="flex:1;" /><button type="submit">Odtwórz</button></div>' +
        "</form>" +
        '<div class="form-msg" id="tubaMsg"></div>' +
        '<div id="tubaPlayer" style="margin-top:16px;"></div>');
    },
    afterRender: function () {
      var form = document.getElementById("tubaForm");
      var input = document.getElementById("tubaInput");
      var msg = document.getElementById("tubaMsg");
      var player = document.getElementById("tubaPlayer");
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        var id = extractYoutubeId(input.value);
        if (!id) { msg.style.color = "#c23a3a"; msg.textContent = "Nie rozpoznaję tego linku/ID."; return; }
        msg.textContent = "";
        player.innerHTML =
          '<iframe width="100%" height="400" style="border:0;border-radius:6px;" ' +
          'src="https://www.youtube.com/embed/' + encodeURIComponent(id) + '" ' +
          'title="YouTube" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" ' +
          'allowfullscreen></iframe>';
      });
    }
  };

  SITES["poczta.sgm"] = {
    render: function () {
      return tpl("SIGMANET // POCZTA", "poczta.sgm",
        '<div class="empty-state"><div class="icon">✉️</div><p><strong>Skrzynka jest pusta.</strong><br/>Sigmanet nie ma jeszcze modułu poczty.</p></div>');
    }
  };

  // ---------- hostuj.sgm ----------
  SITES["hostuj.sgm"] = {
    render: function () {
      var offlineNote = API_ENABLED ? "" :
        '<p class="form-msg" style="color:#c23a3a;">Rejestr wspólny nie jest jeszcze podłączony (backend nieskonfigurowany) — hosting jest chwilowo niedostępny.</p>';
      return tpl("SIGMANET // HOSTING", "Hostuj własną stronę",
        "<p>Zajmij nazwę i opublikuj treść w sieci Sigma. Możesz zaznaczyć jeden typ adresu albo oba naraz — poprowadzą do tej samej strony.</p>" +
        offlineNote +
        '<form class="sig-form" id="hostForm">' +
          '<div><label>Tytuł strony</label><input type="text" id="hostTitle" required /></div>' +
          '<div><label>Treść</label><textarea id="hostBody" placeholder="Zwykły tekst — pusta linia = nowy akapit."></textarea></div>' +

          '<div style="border-top:1px solid #e2dbc9;padding-top:12px;">' +
            '<label style="display:flex;align-items:center;gap:6px;text-transform:none;letter-spacing:0;font-size:13px;color:var(--ink);"><input type="checkbox" id="wantPublic" /> Chcę darmową nazwę publiczną (rejestr wewnętrzny)</label>' +
            '<div id="publicBlock" style="display:none;margin-top:8px;">' +
              '<div style="display:flex;gap:6px;"><input type="text" id="publicName" placeholder="np. mojastrona albo cos.ct.ws" style="flex:1;" /><button type="button" id="checkPublic">Sprawdź</button></div>' +
              '<div class="form-msg" id="publicStatus"></div>' +
              '<p style="font-size:11px;color:var(--ink-soft);margin-top:4px;">⚠️ Ta nazwa <strong>nie</strong> otworzy się w zwykłej przeglądarce ani w Google — to nie jest prawdziwa domena internetowa, tylko unikalna nazwa w wewnętrznym rejestrze Sigmanetu. Działa wyłącznie tutaj.</p>' +
            "</div>" +
          "</div>" +

          '<div style="border-top:1px solid #e2dbc9;padding-top:12px;">' +
            '<label style="display:flex;align-items:center;gap:6px;text-transform:none;letter-spacing:0;font-size:13px;color:var(--ink);"><input type="checkbox" id="wantLocal" checked /> Chcę adres .sigma / .sgm</label>' +
            '<div id="localBlock" style="margin-top:8px;">' +
              '<div style="display:flex;gap:6px;"><input type="text" id="localName" placeholder="nazwa" style="flex:1;" /><select id="localSuffix" style="font-family:var(--font-mono);border:1px solid #dcd3ba;border-radius:4px;"><option value="sigma">.sigma</option><option value="sgm">.sgm</option></select><button type="button" id="checkLocal">Sprawdź</button></div>' +
              '<div class="form-msg" id="localStatus"></div>' +
            "</div>" +
          "</div>" +

          '<button type="submit">Opublikuj</button>' +
          '<div class="form-msg" id="hostMsg"></div>' +
        "</form>");
    },
    afterRender: function () {
      var wantPublic = document.getElementById("wantPublic");
      var wantLocal = document.getElementById("wantLocal");
      var publicBlock = document.getElementById("publicBlock");
      var localBlock = document.getElementById("localBlock");

      wantPublic.addEventListener("change", function () { publicBlock.style.display = wantPublic.checked ? "block" : "none"; });
      wantLocal.addEventListener("change", function () { localBlock.style.display = wantLocal.checked ? "block" : "none"; });

      document.getElementById("checkPublic").addEventListener("click", function () {
        var name = document.getElementById("publicName").value.trim();
        var status = document.getElementById("publicStatus");
        if (!validPublicName(name)) { status.style.color = "#c23a3a"; status.textContent = "Nieprawidłowa nazwa."; return; }
        status.style.color = "#5a5548"; status.textContent = "sprawdzam…";
        apiGet("check", { domain: name }).then(function (r) {
          status.style.color = r.available ? "#2f7a2f" : "#c23a3a";
          status.textContent = r.available ? "✓ wolne" : "✗ zajęte";
        }).catch(function () { status.style.color = "#c23a3a"; status.textContent = "brak połączenia z rejestrem"; });
      });

      document.getElementById("checkLocal").addEventListener("click", function () {
        var name = document.getElementById("localName").value.trim();
        var suffix = document.getElementById("localSuffix").value;
        var status = document.getElementById("localStatus");
        if (!validLocalName(name, suffix)) { status.style.color = "#c23a3a"; status.textContent = "Nieprawidłowa nazwa."; return; }
        var full = name.toLowerCase() + "." + suffix;
        status.style.color = "#5a5548"; status.textContent = "sprawdzam…";
        apiGet("check", { domain: full }).then(function (r) {
          status.style.color = r.available ? "#2f7a2f" : "#c23a3a";
          status.textContent = r.available ? "✓ wolne" : "✗ zajęte";
        }).catch(function () { status.style.color = "#c23a3a"; status.textContent = "brak połączenia z rejestrem"; });
      });

      document.getElementById("hostForm").addEventListener("submit", function (e) {
        e.preventDefault();
        var msg = document.getElementById("hostMsg");
        msg.style.color = "#5a5548";

        if (!API_ENABLED) { msg.style.color = "#c23a3a"; msg.textContent = "Backend nie jest skonfigurowany — hosting niedostępny."; return; }

        var title = document.getElementById("hostTitle").value.trim();
        var body = document.getElementById("hostBody").value.trim();
        var jobs = [];
        var groupId = "grp_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

        if (wantPublic.checked) {
          var pubName = document.getElementById("publicName").value.trim();
          if (!validPublicName(pubName)) { msg.style.color = "#c23a3a"; msg.textContent = "Popraw nazwę publiczną."; return; }
          jobs.push({ domain: pubName, kind: "public", title: title, body: body, owner_token: getOwnerToken(), group_id: groupId });
        }
        if (wantLocal.checked) {
          var locName = document.getElementById("localName").value.trim();
          var suffix = document.getElementById("localSuffix").value;
          if (!validLocalName(locName, suffix)) { msg.style.color = "#c23a3a"; msg.textContent = "Popraw nazwę .sigma/.sgm."; return; }
          jobs.push({ domain: locName.toLowerCase() + "." + suffix, kind: "local", title: title, body: body, owner_token: getOwnerToken(), group_id: groupId });
        }
        if (!jobs.length) { msg.style.color = "#c23a3a"; msg.textContent = "Wybierz przynajmniej jeden typ adresu."; return; }

        msg.textContent = "publikuję…";
        var results = [];
        function next() {
          if (!jobs.length) {
            var ok = results.filter(function (r) { return r.ok; }).map(function (r) { return r.domain; });
            var bad = results.filter(function (r) { return !r.ok; });
            if (ok.length) {
              ok.forEach(function (d) { cacheUpsert({ domain: d, kind: d.match(/\.(sigma|sgm)$/) ? "local" : "public", title: title, body: body }); });
              msg.style.color = "#2f7a2f";
              msg.innerHTML = "Opublikowano: " + ok.map(function (d) { return '<span class="sig-link" data-nav="' + esc(d) + '">' + esc(d) + "</span>"; }).join(", ");
            }
            if (bad.length) {
              msg.style.color = "#c23a3a";
              msg.textContent += (ok.length ? " · " : "") + "błąd: " + bad.map(function (b) { return b.domain + " (" + (b.error || "zajęte") + ")"; }).join(", ");
            }
            return;
          }
          var job = jobs.shift();
          apiPost("create", job).then(function (r) {
            results.push({ domain: job.domain, ok: !!(r && r.ok), error: r && r.error });
            next();
          }).catch(function () {
            results.push({ domain: job.domain, ok: false, error: "brak połączenia" });
            next();
          });
        }
        next();
      });
    }
  };

  // ---------- moje.sgm ----------
  SITES["moje.sgm"] = {
    render: function () {
      return tpl("SIGMANET // TWOJE WĘZŁY", "moje.sgm",
        "<p>Strony, które opublikowałeś z tego urządzenia.</p>" +
        '<div id="mineList"><p style="font-family:var(--font-mono);font-size:12px;color:var(--ink-soft);">wczytuję…</p></div>' +
        '<p style="margin-top:16px;"><span class="sig-link" data-nav="hostuj.sgm">+ dodaj kolejną stronę</span></p>');
    },
    afterRender: function () {
      var box = document.getElementById("mineList");
      var legacy = loadLegacySites();
      var legacyRows = Object.keys(legacy).map(function (d) { return { domain: d, kind: "local", title: legacy[d].title || d, legacy: true }; });

      function renderRows(rows) {
        var all = rows.concat(legacyRows);
        if (!all.length) {
          box.innerHTML = '<p style="font-family:var(--font-mono);font-size:12px;color:var(--ink-soft);">Nie masz jeszcze żadnych węzłów.</p>';
          return;
        }
        box.innerHTML = all.map(function (d) {
          var badge = d.kind === "public" ? "🌐" : "🔒";
          return '<div class="mysite-row"><span class="domain" data-nav="' + esc(d.domain) + '">' + esc(d.domain) + " " + badge + '</span><button data-delete-domain="' + esc(d.domain) + '" data-legacy="' + (d.legacy ? "1" : "0") + '">usuń</button></div>';
        }).join("");
      }

      if (!API_ENABLED) { renderRows([]); return; }
      apiPost("list_mine", { owner_token: getOwnerToken() }).then(function (r) {
        renderRows((r && r.items) || []);
      }).catch(function () { renderRows([]); });
    }
  };

  // ============================================================
  // ROZWIĄZYWANIE ADRESÓW
  // ============================================================
  function renderRemoteSite(domain, data) {
    var badge = data.kind === "public" ? "🌐 nazwa publiczna (tylko w Sigmanet)" : "🔒 adres lokalny .sigma/.sgm";
    return tpl(domain.toUpperCase() + " // " + badge, data.title || domain,
      paragraphs(data.body) +
      '<p><span class="sig-link" data-nav="' + HOME + '">← wróć na start</span></p>');
  }

  function renderErrorPage(domain) {
    return tpl("BŁĄD 404 // WĘZEŁ NIEZNANY", "Nie znaleziono węzła",
      '<p>Sigmanet nie zna adresu <code>' + esc(domain) + "</code>. Sprawdź pisownię albo utwórz go sam pod " +
      '<span class="sig-link" data-nav="hostuj.sgm">hostuj.sgm</span>.</p>' +
      '<p><span class="sig-link" data-nav="' + HOME + '">← wróć na start</span></p>',
      "error-page");
  }

  function renderSearchPage(query) {
    var builtins = Object.keys(SITES);
    var cached = getCache().map(function (d) { return d.domain; });
    var all = builtins.concat(cached);
    var hits = all.filter(function (d) { return d.toLowerCase().indexOf(query.toLowerCase()) !== -1; });
    var body = hits.length
      ? '<div class="card-grid">' + hits.map(function (d) { return '<div class="site-card" data-nav="' + esc(d) + '"><div class="domain">' + esc(d) + "</div></div>"; }).join("") + "</div>"
      : "<p>Brak wyników dla „" + esc(query) + "”.</p>";
    return tpl("SIGMANET // WYNIKI WYSZUKIWANIA", "Szukaj: " + query, body);
  }

  function resolveContent(domain, path) {
    if (SITES[domain]) return Promise.resolve(SITES[domain].render(path));

    var doFallback = function () {
      var cached = getCache().find(function (d) { return d.domain === domain; });
      if (cached) return renderRemoteSite(domain, cached);
      var legacy = loadLegacySites()[domain];
      if (legacy) return renderRemoteSite(domain, { title: legacy.title, body: legacy.body, kind: "local" });
      return renderErrorPage(domain);
    };

    if (!API_ENABLED) return Promise.resolve(doFallback());

    return apiGet("resolve", { domain: domain }).then(function (res) {
      if (res && res.ok) { cacheUpsert(res.item); return renderRemoteSite(domain, res.item); }
      return doFallback();
    }).catch(doFallback);
  }

  // ---------- routing / historia ----------
  var history_ = [];
  var histIndex = -1;

  function parseInput(raw) {
    var v = (raw || "").trim();
    if (/^sgm\s+home$/i.test(v)) return { kind: "sigma", domain: HOME, path: "" };
    v = v.replace(/^sigma:\/\//i, "").replace(/^https?:\/\//i, "");
    var m = v.match(/^([a-z0-9-]+\.(?:sigma|sgm))(?:\/(.*))?$/i);
    if (m) return { kind: "sigma", domain: m[1].toLowerCase(), path: (m[2] || "").toLowerCase() };
    if (!v) return { kind: "sigma", domain: HOME, path: "" };
    if (SITES[v.toLowerCase()] || getCache().some(function (d) { return d.domain === v.toLowerCase(); })) {
      return { kind: "sigma", domain: v.toLowerCase(), path: "" };
    }
    if (/^[^\s]+\.[a-z]{2,}([\/?#].*)?$/i.test(v)) return { kind: "external", url: v };
    return { kind: "search", query: v };
  }

  // ---------- DOM ----------
  var el = {
    tabTitle: document.getElementById("tabTitle"),
    addressForm: document.getElementById("addressForm"),
    addressInput: document.getElementById("addressInput"),
    btnBack: document.getElementById("btnBack"),
    btnForward: document.getElementById("btnForward"),
    btnReload: document.getElementById("btnReload"),
    btnHome: document.getElementById("btnHome"),
    btnLobby: document.getElementById("btnLobby"),
    progressFill: document.getElementById("progressFill"),
    handshake: document.getElementById("handshake"),
    page: document.getElementById("page"),
    statusText: document.getElementById("statusText"),
    pingText: document.getElementById("pingText")
  };

  function updateNavButtons() {
    el.btnBack.disabled = histIndex <= 0;
    el.btnForward.disabled = histIndex >= history_.length - 1;
  }

  function showHandshake(label) {
    el.progressFill.classList.remove("active");
    void el.progressFill.offsetWidth;
    el.progressFill.classList.add("active");
    el.handshake.classList.add("show");
    el.page.classList.add("hidden");
    el.handshake.textContent = "SIGMA-56K // ŁĄCZENIE Z WĘZŁEM: " + label + "\nNEGOCJACJA PROTOKOŁU... OK\nTRANSFER PAKIETÓW... ";
    var cursor = document.createElement("span");
    cursor.className = "cursor";
    el.handshake.appendChild(cursor);
  }

  function finishHandshake(html, entry) {
    el.handshake.classList.remove("show");
    el.page.classList.remove("hidden");
    el.page.innerHTML = html;
    var site = SITES[entry.domain];
    if (site && site.afterRender) site.afterRender(entry.path);
  }

  function display(entry) {
    var label = entry.domain + (entry.path ? "/" + entry.path : "");
    el.addressInput.value = label;
    el.tabTitle.textContent = entry.domain;
    el.statusText.textContent = "sigma://" + label + " — łączenie…";

    showHandshake(label);
    var t0 = Date.now();
    resolveContent(entry.domain, entry.path).then(function (html) {
      var wait = Math.max(0, 480 - (Date.now() - t0));
      setTimeout(function () {
        el.statusText.textContent = "sigma://" + label + " — połączono";
        finishHandshake(html, entry);
      }, wait);
    });
  }

  function pushHistory(entry) {
    history_ = history_.slice(0, histIndex + 1);
    history_.push(entry);
    histIndex = history_.length - 1;
    updateNavButtons();
  }

  function navigate(raw) {
    var parsed = parseInput(raw);

    if (parsed.kind === "external") {
      el.statusText.textContent = "to nie jest adres Sigmanetu — otwieram w zwykłej przeglądarce";
      if (window.sigmanek && typeof window.sigmanek.openExternal === "function") {
        var url = /^https?:\/\//i.test(parsed.url) ? parsed.url : "https://" + parsed.url;
        window.sigmanek.openExternal(url);
      }
      return;
    }

    if (parsed.kind === "search") {
      var searchEntry = { domain: "wyniki.sgm", path: "" };
      pushHistory(searchEntry);
      el.addressInput.value = searchEntry.domain;
      el.tabTitle.textContent = searchEntry.domain;
      showHandshake(searchEntry.domain);
      setTimeout(function () { finishHandshake(renderSearchPage(parsed.query), searchEntry); }, 350);
      return;
    }

    var entry = { domain: parsed.domain, path: parsed.path || "" };
    pushHistory(entry);
    display(entry);
  }

  // ---------- eventy chrome ----------
  el.addressForm.addEventListener("submit", function (e) { e.preventDefault(); navigate(el.addressInput.value); });
  el.btnBack.addEventListener("click", function () { if (histIndex > 0) { histIndex -= 1; updateNavButtons(); display(history_[histIndex]); } });
  el.btnForward.addEventListener("click", function () { if (histIndex < history_.length - 1) { histIndex += 1; updateNavButtons(); display(history_[histIndex]); } });
  el.btnReload.addEventListener("click", function () { if (history_[histIndex]) display(history_[histIndex]); });
  el.btnHome.addEventListener("click", function () { navigate(HOME); });
  el.btnLobby.addEventListener("click", function () { if (window.sigmanek && typeof window.sigmanek.goToLobby === "function") window.sigmanek.goToLobby(); });

  // ---------- delegacja zdarzeń wewnątrz treści ----------
  el.page.addEventListener("click", function (e) {
    var navTarget = e.target.closest("[data-nav]");
    if (navTarget) { navigate(navTarget.getAttribute("data-nav")); return; }

    var delTarget = e.target.closest("[data-delete-domain]");
    if (delTarget) {
      var domain = delTarget.getAttribute("data-delete-domain");
      var isLegacy = delTarget.getAttribute("data-legacy") === "1";
      if (isLegacy) {
        var legacy = loadLegacySites();
        delete legacy[domain];
        localStorage.setItem(LEGACY_STORAGE_KEY, JSON.stringify(legacy));
        navigate("moje.sgm");
        return;
      }
      if (API_ENABLED) {
        apiPost("delete", { domain: domain, owner_token: getOwnerToken() }).then(function () {
          cacheRemove(domain);
          navigate("moje.sgm");
        });
      }
    }
  });

  el.page.addEventListener("submit", function (e) {
    if (e.target.id === "homeSearchForm") {
      e.preventDefault();
      var q = document.getElementById("homeSearchInput").value.trim();
      if (q) navigate(q);
    }
  });

  // ---------- pasek statusu: fałszywy ping ----------
  setInterval(function () { el.pingText.textContent = "sigma-node · " + (8 + Math.floor(Math.random() * 34)) + "ms"; }, 2200);
  el.pingText.textContent = "sigma-node · 14ms";

  // ---------- start ----------
  navigate(HOME);
})();
