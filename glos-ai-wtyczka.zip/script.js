// ============================================================
// Każdy user hostuje silnik AI SAM, u siebie na komputerze —
// dlatego wtyczka gada z localhost, nie z żadnym zewnętrznym
// serwerem. Zero kosztów dla kogokolwiek, na zawsze.
//
// User musi mieć uruchomiony lokalny programik (patrz
// lokalny-silnik/README.md) — bez niego przyciski niżej
// pokażą błąd połączenia, to normalne.
// ============================================================
const BACKEND_URL = "http://127.0.0.1:8765";

// Oczekiwane endpointy na Twoim backendzie:
//   POST {BACKEND_URL}/clone
//     multipart/form-data: name=<tekst>, audio=<plik>
//     odpowiedź JSON: { "voice_id": "abc123" }
//
//   POST {BACKEND_URL}/generate
//     JSON: { "voice_id": "abc123", "text": "..." }
//     odpowiedź: plik audio (audio/mpeg lub audio/wav) w treści odpowiedzi

const cloneBtn = document.getElementById("cloneBtn");
const cloneStatus = document.getElementById("cloneStatus");
const voiceNameInput = document.getElementById("voiceName");
const sampleFileInput = document.getElementById("sampleFile");

const generateBtn = document.getElementById("generateBtn");
const genStatus = document.getElementById("genStatus");
const textInput = document.getElementById("textInput");
const player = document.getElementById("player");
const downloadLink = document.getElementById("downloadLink");

const backBtn = document.getElementById("backBtn");

let currentVoiceId = null;
let engineReady = false;

function setStatus(el, text, kind) {
  el.textContent = text;
  el.className = "status" + (kind ? " " + kind : "");
}

async function checkEngine() {
  try {
    const res = await fetch(`${BACKEND_URL}/ping`, { method: "GET" });
    if (res.ok) {
      engineReady = true;
      setStatus(cloneStatus, "Lokalny silnik wykryty — możesz działać.", "ok");
    } else {
      throw new Error("bad status");
    }
  } catch (err) {
    engineReady = false;
    setStatus(
      cloneStatus,
      "Nie widzę lokalnego silnika na tym komputerze. Uruchom program \"Głos AI — Silnik\" (patrz instrukcja instalacji), potem odśwież tę stronę.",
      "err"
    );
  }
}

checkEngine();

sampleFileInput.addEventListener("change", () => {
  cloneBtn.disabled = !(sampleFileInput.files.length && voiceNameInput.value.trim());
});
voiceNameInput.addEventListener("input", () => {
  cloneBtn.disabled = !(sampleFileInput.files.length && voiceNameInput.value.trim());
});

cloneBtn.addEventListener("click", async () => {
  const file = sampleFileInput.files[0];
  const name = voiceNameInput.value.trim();
  if (!file || !name) return;

  if (!engineReady) {
    setStatus(cloneStatus, "Najpierw uruchom lokalny silnik na tym komputerze (patrz instrukcja).", "err");
    return;
  }

  cloneBtn.disabled = true;
  setStatus(cloneStatus, "Tworzę głos z próbki… to może potrwać do minuty.", "busy");

  try {
    const form = new FormData();
    form.append("name", name);
    form.append("audio", file);

    const res = await fetch(`${BACKEND_URL}/clone`, {
      method: "POST",
      body: form,
    });

    if (!res.ok) throw new Error(`Serwer zwrócił błąd ${res.status}`);
    const data = await res.json();
    if (!data.voice_id) throw new Error("Brak voice_id w odpowiedzi serwera");

    currentVoiceId = data.voice_id;
    setStatus(cloneStatus, "Gotowe! Głos utworzony. Możesz teraz generować mowę.", "ok");

    textInput.disabled = false;
    generateBtn.disabled = false;
    cloneBtn.disabled = false;
  } catch (err) {
    console.error(err);
    setStatus(cloneStatus, "Nie udało się utworzyć głosu: " + err.message, "err");
    cloneBtn.disabled = false;
  }
});

generateBtn.addEventListener("click", async () => {
  const text = textInput.value.trim();
  if (!text || !currentVoiceId) return;

  generateBtn.disabled = true;
  setStatus(genStatus, "Generuję nagranie…", "busy");
  player.style.display = "none";
  downloadLink.style.display = "none";

  try {
    const res = await fetch(`${BACKEND_URL}/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ voice_id: currentVoiceId, text }),
    });

    if (!res.ok) throw new Error(`Serwer zwrócił błąd ${res.status}`);

    const blob = await res.blob();
    const url = URL.createObjectURL(blob);

    player.src = url;
    player.style.display = "block";
    downloadLink.href = url;
    downloadLink.style.display = "inline-block";

    setStatus(genStatus, "Gotowe.", "ok");
  } catch (err) {
    console.error(err);
    setStatus(genStatus, "Nie udało się wygenerować nagrania: " + err.message, "err");
  } finally {
    generateBtn.disabled = false;
  }
});

backBtn.addEventListener("click", () => {
  if (window.sigmanek && window.sigmanek.goToLobby) {
    window.sigmanek.goToLobby();
  }
});
