/* ============================================================
   PROSTY MONTAŻ — silnik edytora wideo (Faza 1)
   Import mediow, oś czasu wielościeżkowa, ciecie/przycinanie,
   podglad na zywo. (Teksty/przejscia/filtry/audio-mix/eksport
   dochodza w kolejnych fazach.)
   ============================================================ */

// ---------- STAN PROJEKTU ----------
let project = {
  fps: 30,
  width: 1280,
  height: 720,
  tracks: [] // {id, kind:'visual'|'audio', type:'video'|'image'|'text'|'audio-track', clips:[]}
};

let mediaLibrary = []; // {id, name, type, file, url, duration, el, width, height}
let mediaCounter = 0;
let clipCounter = 0;
let trackCounter = 0;

let selectedClipId = null;
let currentTime = 0;
let isPlaying = false;
let pxPerSec = 60; // poziom przybliżenia osi czasu

let history = [];
let historyIndex = -1;
let suppressHistory = false;

// ---------- DOM ----------
const previewCanvas = document.getElementById('previewCanvas');
const pctx = previewCanvas.getContext('2d');
const mediaList = document.getElementById('mediaList');
const tracksContainer = document.getElementById('tracksContainer');
const timelineRuler = document.getElementById('timelineRuler');
const timelineScroll = document.getElementById('timelineScroll');
const propsContent = document.getElementById('propsContent');
const fileInput = document.getElementById('fileInput');
const projectInput = document.getElementById('projectInput');
const timeDisplay = document.getElementById('timeDisplay');

function uidMedia(){ return 'M'+(++mediaCounter); }
function uidClip(){ return 'C'+(++clipCounter); }
function uidTrack(){ return 'T'+(++trackCounter); }

function fmtTime(t){
  if(!isFinite(t) || t<0) t=0;
  const m = Math.floor(t/60);
  const s = t-m*60;
  return `${String(m).padStart(2,'0')}:${s.toFixed(1).padStart(4,'0')}`;
}

function projectDuration(){
  let max = 0;
  project.tracks.forEach(tr=> tr.clips.forEach(c=> { max = Math.max(max, c.start+c.duration); }));
  return max;
}

// ---------- IMPORT MEDIÓW ----------
function importFiles(fileList){
  Array.from(fileList).forEach(file=>{
    const url = URL.createObjectURL(file);
    let type = 'video';
    if(file.type.startsWith('image/')) type = 'image';
    else if(file.type.startsWith('audio/')) type = 'audio';
    else if(file.type.startsWith('video/')) type = 'video';

    const item = { id: uidMedia(), name:file.name, type, file, url, duration:0, el:null, width:0, height:0 };
    mediaLibrary.push(item);

    if(type==='video'){
      const v = document.createElement('video');
      v.src = url; v.preload='metadata'; v.muted=false;
      v.onloadedmetadata = ()=>{
        item.duration = v.duration; item.width=v.videoWidth; item.height=v.videoHeight; item.el=v;
        renderMediaList();
      };
    } else if(type==='audio'){
      const a = document.createElement('audio');
      a.src = url; a.preload='metadata';
      a.onloadedmetadata = ()=>{ item.duration=a.duration; item.el=a; renderMediaList(); };
    } else if(type==='image'){
      const img = new Image();
      img.onload = ()=>{ item.duration=5; item.width=img.width; item.height=img.height; item.el=img; renderMediaList(); };
      img.src = url;
    }
  });
  renderMediaList();
}

function renderMediaList(){
  if(mediaLibrary.length===0){
    mediaList.innerHTML = '<div class="media-empty">Brak mediów — zaimportuj wideo, zdjęcia albo muzykę.</div>';
    return;
  }
  mediaList.innerHTML = '';
  mediaLibrary.forEach(item=>{
    const div = document.createElement('div');
    div.className = 'media-item';
    div.draggable = true;
    div.dataset.mediaId = item.id;
    const icon = item.type==='video' ? '🎞️' : item.type==='image' ? '🖼️' : '🎵';
    div.innerHTML = `<div class="thumb">${icon}</div>
      <div class="meta"><div class="name">${escapeHtml(item.name)}</div><div class="dur">${item.duration? fmtTime(item.duration):'...'}</div></div>`;
    div.addEventListener('dragstart', (e)=>{
      e.dataTransfer.setData('text/media-id', item.id);
    });
    div.addEventListener('dblclick', ()=>{
      // szybkie dodanie na koniec pierwszej pasujacej sciezki (lub nowej)
      addClipFromMedia(item, findOrCreateTrackFor(item), null);
    });
    mediaList.appendChild(div);
  });
}

function escapeHtml(s){ return (s||'').replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

document.getElementById('importBtn').onclick = ()=> fileInput.click();
document.getElementById('importTopBtn').onclick = ()=> fileInput.click();
fileInput.addEventListener('change', (e)=>{ if(e.target.files.length) importFiles(e.target.files); fileInput.value=''; });

// drag & drop plikow z systemu na panel biblioteki
const mediaPanel = document.getElementById('mediaPanel');
mediaPanel.addEventListener('dragover', e=>{ e.preventDefault(); });
mediaPanel.addEventListener('drop', e=>{
  e.preventDefault();
  if(e.dataTransfer.files && e.dataTransfer.files.length) importFiles(e.dataTransfer.files);
});

// ---------- ŚCIEŻKI ----------
function addTrack(kind){
  const track = { id: uidTrack(), kind, type: kind==='visual'?'video':'audio-track', clips: [] };
  if(kind==='visual') project.tracks.push(track); // wizualne: na koncu tablicy = na wierzchu kompozycji
  else project.tracks.push(track);
  renderTracks();
  return track;
}

function findOrCreateTrackFor(mediaItem){
  const wantKind = mediaItem.type==='audio' ? 'audio' : 'visual';
  let track = [...project.tracks].reverse().find(t=>t.kind===wantKind);
  if(!track) track = addTrack(wantKind);
  return track;
}

function visualTracks(){ return project.tracks.filter(t=>t.kind==='visual'); }
function audioTracks(){ return project.tracks.filter(t=>t.kind==='audio'); }

// ---------- KLIPY ----------
function addClipFromMedia(mediaItem, track, startTime){
  const dur = mediaItem.duration || 5;
  const start = startTime!==null && startTime!==undefined ? startTime : trackEndTime(track);
  const clip = {
    id: uidClip(),
    trackId: track.id,
    mediaId: mediaItem.id,
    type: mediaItem.type, // 'video'|'image'|'audio'
    start, duration: mediaItem.type==='image' ? 5 : dur,
    sourceIn: 0, sourceOut: dur,
    volume: 100,
    filters: { brightness:100, contrast:100, saturate:100 }
  };
  track.clips.push(clip);
  selectClip(clip.id);
  ensureWholeTimelineVisible();
  renderTracks();
  pushHistory();
  return clip;
}

// Jeśli po dodaniu/wydłużeniu klipu cały montaż nie mieści się już w widoku,
// automatycznie dopasuj przybliżenie tak, żeby zawsze było widać wszystko.
function ensureWholeTimelineVisible(){
  const availWidth = Math.max(100, timelineScroll.clientWidth - 80);
  const neededWidth = projectDuration() * pxPerSec;
  if(neededWidth > availWidth){
    pxPerSec = computeMinZoom();
  }
}

function trackEndTime(track){
  let max = 0;
  track.clips.forEach(c=> max = Math.max(max, c.start+c.duration));
  return max;
}

function getClipById(id){
  for(const tr of project.tracks){
    const c = tr.clips.find(cl=>cl.id===id);
    if(c) return {clip:c, track:tr};
  }
  return null;
}

function getMediaById(id){ return mediaLibrary.find(m=>m.id===id); }

function selectClip(id){
  selectedClipId = id;
  renderTracks();
  renderProps();
}

function deleteClip(id){
  const found = getClipById(id);
  if(!found) return;
  found.track.clips = found.track.clips.filter(c=>c.id!==id);
  if(selectedClipId===id) selectedClipId = null;
  renderTracks(); renderProps(); pushHistory();
}

function splitClipAt(id, atTime){
  const found = getClipById(id);
  if(!found) return;
  const { clip, track } = found;
  if(atTime <= clip.start || atTime >= clip.start+clip.duration) return;
  const offsetIntoClip = atTime - clip.start;
  const newClip = JSON.parse(JSON.stringify(clip));
  newClip.id = uidClip();
  newClip.start = atTime;
  newClip.duration = clip.duration - offsetIntoClip;
  newClip.sourceIn = clip.sourceIn + offsetIntoClip;
  clip.duration = offsetIntoClip;
  clip.sourceOut = clip.sourceIn + offsetIntoClip;
  track.clips.push(newClip);
  renderTracks(); pushHistory();
}

// ---------- RENDEROWANIE OSI CZASU ----------
const TRACK_COLORS = {
  video: 'linear-gradient(180deg,#3b5bdb,#2740a0)',
  image: 'linear-gradient(180deg,#2f9e44,#1c6b28)',
  audio: 'linear-gradient(180deg,#e8590c,#a83c0c)',
  text: 'linear-gradient(180deg,#ae3ec9,#7b1fa2)'
};

function renderRuler(){
  const dur = Math.max(5, projectDuration()+2);
  const w = dur*pxPerSec;
  timelineRuler.style.width = w+'px';
  timelineRuler.innerHTML = '';
  const stepSec = pxPerSec<40 ? 5 : pxPerSec<90 ? 2 : 1;
  for(let t=0; t<=dur; t+=stepSec){
    const tick = document.createElement('div');
    tick.style.cssText = `position:absolute; left:${t*pxPerSec+70}px; top:0; height:100%; border-left:1px solid #333a4d; padding-left:3px; font-size:9px; color:#8890a3; display:flex; align-items:center;`;
    tick.textContent = fmtTime(t);
    timelineRuler.appendChild(tick);
  }
  const ph = document.createElement('div');
  ph.id = 'rulerPlayhead';
  ph.style.cssText = `position:absolute; left:${currentTime*pxPerSec+70}px; top:0; bottom:0; width:2px; background:#ff5c7a;`;
  timelineRuler.appendChild(ph);
  timelineRuler.onclick = (e)=>{
    const rect = timelineRuler.getBoundingClientRect();
    const x = e.clientX - rect.left - 70;
    seekTo(Math.max(0, x/pxPerSec));
  };
}

function renderTracks(){
  const dur = Math.max(5, projectDuration()+2);
  const w = dur*pxPerSec;
  tracksContainer.innerHTML = '';
  tracksContainer.style.width = (w+70)+'px';

  // wizualne od gory (ostatnia w tablicy = pierwszy wiersz = na wierzchu kompozycji)
  const vTracks = [...visualTracks()].reverse();
  vTracks.forEach(track=> tracksContainer.appendChild(buildTrackRow(track, w)));
  audioTracks().forEach(track=> tracksContainer.appendChild(buildTrackRow(track, w)));

  const ph = document.createElement('div');
  ph.id = 'playhead';
  ph.style.left = (currentTime*pxPerSec+70)+'px';
  ph.style.height = tracksContainer.scrollHeight+'px';
  tracksContainer.appendChild(ph);

  renderRuler();
}

function buildTrackRow(track, totalWidth){
  const row = document.createElement('div');
  row.className = 'track-row' + (track.kind==='audio' ? ' audio':'');
  row.style.width = totalWidth+'px';
  row.dataset.trackId = track.id;

  const label = document.createElement('div');
  label.className = 'track-label';
  label.textContent = track.kind==='audio' ? '🎵' : '🎞️';
  row.appendChild(label);

  track.clips.forEach(clip=>{
    row.appendChild(buildClipEl(clip));
  });

  row.addEventListener('dragover', e=> e.preventDefault());
  row.addEventListener('drop', e=>{
    e.preventDefault();
    const mediaId = e.dataTransfer.getData('text/media-id');
    if(!mediaId) return;
    const media = getMediaById(mediaId);
    if(!media) return;
    const isAudioTrack = track.kind==='audio';
    if(isAudioTrack && media.type!=='audio') return;
    if(!isAudioTrack && media.type==='audio') return;
    const rect = row.getBoundingClientRect();
    const x = e.clientX - rect.left - 70;
    addClipFromMedia(media, track, Math.max(0, x/pxPerSec));
  });

  return row;
}

function buildClipEl(clip){
  const media = getMediaById(clip.mediaId);
  const label = clip.type==='text' ? ('🔤 '+(clip.text||'').slice(0,20)) : (media? media.name : '');
  const el = document.createElement('div');
  el.className = `clip type-${clip.type}` + (clip.id===selectedClipId ? ' selected':'');
  el.style.left = (clip.start*pxPerSec+70)+'px';
  el.style.width = Math.max(6, clip.duration*pxPerSec)+'px';
  el.dataset.clipId = clip.id;
  el.innerHTML = `<div class="clip-label">${escapeHtml(label)}</div>
    <div class="trim-handle left"></div><div class="trim-handle right"></div>`;

  el.addEventListener('pointerdown', (e)=>{
    if(e.target.classList.contains('trim-handle')) return; // obsluga osobno
    e.stopPropagation();
    selectClip(clip.id);
    startClipDrag(e, clip);
  });
  el.querySelector('.trim-handle.left').addEventListener('pointerdown', (e)=>{
    e.stopPropagation(); selectClip(clip.id); startClipTrim(e, clip, 'left');
  });
  el.querySelector('.trim-handle.right').addEventListener('pointerdown', (e)=>{
    e.stopPropagation(); selectClip(clip.id); startClipTrim(e, clip, 'right');
  });
  return el;
}

// ---------- PRZECIĄGANIE / PRZYCINANIE KLIPÓW ----------
let dragState = null; // {mode:'move'|'trim-left'|'trim-right', clip, startX, origStart, origDur, origIn, origOut}

function startClipDrag(e, clip){
  dragState = { mode:'move', clip, startX:e.clientX, origStart:clip.start };
  window.addEventListener('pointermove', onClipDragMove);
  window.addEventListener('pointerup', onClipDragEnd);
}
function startClipTrim(e, clip, side){
  dragState = { mode: side==='left'?'trim-left':'trim-right', clip, startX:e.clientX,
    origStart:clip.start, origDur:clip.duration, origIn:clip.sourceIn, origOut:clip.sourceOut };
  window.addEventListener('pointermove', onClipDragMove);
  window.addEventListener('pointerup', onClipDragEnd);
}

function onClipDragMove(e){
  if(!dragState) return;
  const dx = e.clientX - dragState.startX;
  const dt = dx / pxPerSec;
  const clip = dragState.clip;
  const media = getMediaById(clip.mediaId);
  const maxDur = media ? (media.type==='image' ? 3600 : media.duration) : 3600;

  if(dragState.mode==='move'){
    let newStart = Math.max(0, dragState.origStart + dt);
    // snapowanie: probujemy dopasowac zarowno poczatek jak i koniec klipu do punktow snap
    const snappedStart = snapTime(newStart, clip.id);
    const snappedEnd = snapTime(newStart+clip.duration, clip.id) - clip.duration;
    if(Math.abs(snappedStart-newStart) <= Math.abs(snappedEnd-newStart)) newStart = snappedStart;
    else newStart = snappedEnd;
    clip.start = Math.max(0, newStart);
  } else if(dragState.mode==='trim-left'){
    let newStart = dragState.origStart + dt;
    newStart = snapTime(Math.max(0,newStart), clip.id);
    let newIn = dragState.origIn + (newStart - dragState.origStart);
    newIn = Math.max(0, newIn);
    const delta = newStart - dragState.origStart;
    const newDur = dragState.origDur - delta;
    if(newDur > 0.1 && newIn >= 0){
      clip.start = newStart; clip.sourceIn = newIn; clip.duration = newDur;
    }
  } else if(dragState.mode==='trim-right'){
    let newEnd = dragState.origStart + dragState.origDur + dt;
    newEnd = snapTime(newEnd, clip.id);
    let newDur = newEnd - dragState.origStart;
    let newOut = dragState.origOut + (newDur - dragState.origDur);
    if(newDur > 0.1 && newOut <= maxDur+0.001){
      clip.duration = newDur; clip.sourceOut = newOut;
    }
  }
  renderTracks();
}
function onClipDragEnd(){
  window.removeEventListener('pointermove', onClipDragMove);
  window.removeEventListener('pointerup', onClipDragEnd);
  if(dragState){ ensureWholeTimelineVisible(); renderTracks(); pushHistory(); }
  dragState = null;
}

// ---------- ODTWARZANIE / PODGLĄD ----------
function seekTo(t){
  currentTime = Math.max(0, Math.min(t, projectDuration()));
  renderRuler();
  const ph = document.getElementById('playhead');
  if(ph) ph.style.left = (currentTime*pxPerSec+70)+'px';
  renderFrame(currentTime);
  updateTimeDisplay();
}

function updateTimeDisplay(){
  timeDisplay.textContent = `${fmtTime(currentTime)} / ${fmtTime(projectDuration())}`;
}

function renderFrame(t){
  pctx.fillStyle = '#000';
  pctx.fillRect(0,0,previewCanvas.width, previewCanvas.height);
  visualTracks().forEach(track=>{
    const active = activeClipsOnTrack(track, t);
    if(active.length===0) return;
    if(active.length===1){
      drawVisualClip(active[0], t, 1);
    } else {
      // dwa nakladajace sie klipy = przenikanie (crossfade)
      const [a,b] = active; // a zaczal sie wczesniej
      const overlapStart = b.start;
      const overlapEnd = a.start+a.duration;
      const overlapDur = Math.max(0.001, overlapEnd-overlapStart);
      const progress = Math.max(0, Math.min(1, (t-overlapStart)/overlapDur));
      drawVisualClip(a, t, 1-progress);
      drawVisualClip(b, t, progress);
    }
  });
}

function drawVisualClip(clip, t, alpha){
  pctx.save();
  pctx.globalAlpha = Math.max(0, Math.min(1, alpha));
  if(clip.type==='text'){
    drawTextClip(clip, t);
    pctx.restore();
    return;
  }
  const media = getMediaById(clip.mediaId);
  if(!media || !media.el){ pctx.restore(); return; }
  const srcTime = clip.sourceIn + (t - clip.start);
  const f = clip.filters || {brightness:100,contrast:100,saturate:100};
  pctx.filter = `brightness(${f.brightness}%) contrast(${f.contrast}%) saturate(${f.saturate}%)`;
  if(media.type==='video'){
    if(Math.abs(media.el.currentTime - srcTime) > 0.25 && !isPlaying){
      try{ media.el.currentTime = srcTime; }catch(e){}
    }
    drawCover(pctx, media.el, media.width, media.height);
  } else if(media.type==='image'){
    drawCover(pctx, media.el, media.width, media.height);
  }
  pctx.restore();
}

function drawTextClip(clip, t){
  const w = previewCanvas.width, h = previewCanvas.height;
  const cssFont = txtFontCss(clip.fontFamily||'Anton');
  const styleParts = [];
  if(clip.italic) styleParts.push('italic');
  if(clip.bold) styleParts.push('bold');
  pctx.font = `${styleParts.join(' ')} ${clip.fontSize||64}px ${cssFont}`.trim();
  pctx.textAlign = clip.align||'center';
  pctx.textBaseline = 'middle';

  // plynne pojawianie/znikanie (fade in/out) na podstawie pozycji w czasie klipu
  let fadeAlpha = 1;
  const localElapsed = t - clip.start;
  const localRemaining = (clip.start+clip.duration) - t;
  const fadeIn = clip.fadeIn||0, fadeOut = clip.fadeOut||0;
  if(fadeIn>0 && localElapsed < fadeIn) fadeAlpha *= Math.max(0, localElapsed/fadeIn);
  if(fadeOut>0 && localRemaining < fadeOut) fadeAlpha *= Math.max(0, localRemaining/fadeOut);
  pctx.globalAlpha *= Math.max(0, Math.min(1, fadeAlpha)) * ((clip.opacity!==undefined?clip.opacity:100)/100);

  const x = w*((clip.x!==undefined?clip.x:50)/100);
  const y = h*((clip.y!==undefined?clip.y:85)/100);
  const lines = (clip.text||'').split('\n');
  const lineH = (clip.fontSize||64)*1.2;
  const startY = y - (lineH*(lines.length-1))/2;

  if(clip.bgEnabled){
    let maxW = 0;
    lines.forEach(line=>{ maxW = Math.max(maxW, pctx.measureText(line).width); });
    const pad = clip.bgPadding!==undefined ? clip.bgPadding : 16;
    const boxW = maxW + pad*2;
    const boxH = lineH*lines.length + pad*1.2;
    let boxX = x - boxW/2;
    if(clip.align==='left') boxX = x - pad;
    if(clip.align==='right') boxX = x - boxW + pad;
    const boxY = startY - lineH/2 - pad*0.6;
    pctx.save();
    pctx.globalAlpha *= (clip.bgOpacity!==undefined?clip.bgOpacity:80)/100;
    pctx.fillStyle = clip.bgColor||'#000000';
    const r = 10;
    pctx.beginPath();
    pctx.moveTo(boxX+r, boxY);
    pctx.arcTo(boxX+boxW, boxY, boxX+boxW, boxY+boxH, r);
    pctx.arcTo(boxX+boxW, boxY+boxH, boxX, boxY+boxH, r);
    pctx.arcTo(boxX, boxY+boxH, boxX, boxY, r);
    pctx.arcTo(boxX, boxY, boxX+boxW, boxY, r);
    pctx.closePath();
    pctx.fill();
    pctx.restore();
  }

  lines.forEach((line,i)=>{
    const ly = startY + i*lineH;
    if(clip.strokeWidth>0){
      pctx.lineWidth = clip.strokeWidth;
      pctx.strokeStyle = clip.strokeColor||'#000000';
      pctx.lineJoin = 'round';
      pctx.strokeText(line, x, ly);
    }
    pctx.fillStyle = clip.color||'#ffffff';
    pctx.fillText(line, x, ly);
  });
}

function drawCover(c, el, iw, ih){
  const cw = previewCanvas.width, ch = previewCanvas.height;
  const scale = Math.max(cw/iw, ch/ih);
  const dw = iw*scale, dh = ih*scale;
  c.drawImage(el, (cw-dw)/2, (ch-dh)/2, dw, dh);
}

// ---------- PĘTLA ODTWARZANIA ----------
let lastFrameTs = 0;
let rafId = null;

function play(){
  if(isPlaying) return;
  if(currentTime >= projectDuration()) currentTime = 0;
  isPlaying = true;
  lastFrameTs = performance.now();
  document.getElementById('playPauseBtn').textContent = '⏸';
  rafId = requestAnimationFrame(playbackTick);
}
function pause(){
  isPlaying = false;
  document.getElementById('playPauseBtn').textContent = '▶️';
  if(rafId) cancelAnimationFrame(rafId);
  mediaLibrary.forEach(m=>{ if(m.el && m.el.pause) m.el.pause(); });
}
function togglePlay(){ isPlaying ? pause() : play(); }

function playbackTick(ts){
  if(!isPlaying) return;
  const dt = (ts - lastFrameTs)/1000;
  lastFrameTs = ts;
  currentTime += dt;
  const dur = projectDuration();
  if(currentTime >= dur){
    currentTime = dur;
    pause();
    renderFrame(currentTime);
    updateTimeDisplayAndPlayhead();
    return;
  }
  syncMediaPlayback(currentTime);
  renderFrame(currentTime);
  updateTimeDisplayAndPlayhead();
  rafId = requestAnimationFrame(playbackTick);
}

function updateTimeDisplayAndPlayhead(){
  updateTimeDisplay();
  const ph = document.getElementById('playhead');
  if(ph) ph.style.left = (currentTime*pxPerSec+70)+'px';
  const rph = document.getElementById('rulerPlayhead');
  if(rph) rph.style.left = (currentTime*pxPerSec+70)+'px';
}

function syncMediaPlayback(t){
  const activeMediaIds = new Set();
  [...visualTracks(), ...audioTracks()].forEach(track=>{
    const clips = activeClipsOnTrack(track, t);
    let fadeMul = {};
    if(clips.length===2){
      const [a,b] = clips;
      const overlapStart = b.start, overlapEnd = a.start+a.duration;
      const overlapDur = Math.max(0.001, overlapEnd-overlapStart);
      const progress = Math.max(0, Math.min(1, (t-overlapStart)/overlapDur));
      fadeMul[a.id] = 1-progress; fadeMul[b.id] = progress;
    }
    clips.forEach(clip=>{
      if(clip.type==='text') return;
      const media = getMediaById(clip.mediaId);
      if(!media || !media.el) return;
      if(media.type==='image') return;
      activeMediaIds.add(media.id);
      const srcTime = clip.sourceIn + (t - clip.start);
      const mul = fadeMul[clip.id]!==undefined ? fadeMul[clip.id] : 1;
      media.el.volume = Math.max(0, Math.min(1,(clip.volume!==undefined?clip.volume:100)/100 * mul));
      if(media.el.paused){
        try{ media.el.currentTime = srcTime; }catch(e){}
        media.el.play().catch(()=>{});
      } else if(Math.abs(media.el.currentTime - srcTime) > 0.2){
        try{ media.el.currentTime = srcTime; }catch(e){}
      }
    });
  });
  // zatrzymaj media ktore nie sa juz aktywne
  mediaLibrary.forEach(m=>{
    if(m.el && m.type!=='image' && !activeMediaIds.has(m.id) && !m.el.paused){
      m.el.pause();
    }
  });
}

document.getElementById('playPauseBtn').onclick = togglePlay;
document.getElementById('skipBackBtn').onclick = ()=> seekTo(currentTime-1);
document.getElementById('skipFwdBtn').onclick = ()=> seekTo(currentTime+1);
window.addEventListener('keydown', (e)=>{
  const tag=(e.target.tagName||'').toLowerCase();
  if(tag==='input'||tag==='textarea') return;
  if(e.code==='Space'){ e.preventDefault(); togglePlay(); }
  if(e.key==='Delete' && selectedClipId){ deleteClip(selectedClipId); }
});

// ---------- PANEL WŁAŚCIWOŚCI ----------
function renderProps(){
  const found = selectedClipId ? getClipById(selectedClipId) : null;
  if(!found){
    propsContent.innerHTML = '<p class="props-empty">Kliknij klip na osi czasu, żeby go edytować.</p>';
    return;
  }
  const { clip } = found;

  if(clip.type==='text'){
    renderTextProps(clip);
    return;
  }

  const media = getMediaById(clip.mediaId);
  const f = clip.filters || {brightness:100,contrast:100,saturate:100};
  let html = `<div class="field"><label>Plik</label><div style="font-size:12px; color:var(--text-dim);">${media?escapeHtml(media.name):''}</div></div>`;
  html += `<div class="field"><label>Start na osi <span>${clip.start.toFixed(2)}s</span></label><input type="range" id="propStart" min="0" max="${Math.max(30,projectDuration())}" step="0.05" value="${clip.start}"></div>`;
  html += `<div class="field"><label>Długość <span>${clip.duration.toFixed(2)}s</span></label><input type="range" id="propDur" min="0.1" max="${media?(media.type==='image'?60:media.duration):60}" step="0.05" value="${clip.duration}"></div>`;
  if(clip.type!=='image'){
    html += `<div class="field"><label>Głośność <span>${clip.volume}%</span></label><input type="range" id="propVolume" min="0" max="100" value="${clip.volume}"></div>`;
  }
  if(clip.type==='video' || clip.type==='image'){
    html += `<h3 style="margin-top:14px;">Filtry / efekty</h3>`;
    html += `<div class="chip-row" style="margin-bottom:10px;">
      <button class="chip" data-fpreset="naturalny">Naturalny</button>
      <button class="chip" data-fpreset="zywe">Żywe kolory</button>
      <button class="chip" data-fpreset="czb">Czarno-białe</button>
      <button class="chip" data-fpreset="cieple">Ciepłe</button>
      <button class="chip" data-fpreset="chlodne">Chłodne</button>
      <button class="chip" data-fpreset="vhs">Retro VHS</button>
    </div>`;
    html += `<div class="field"><label>Jasność <span>${f.brightness}%</span></label><input type="range" id="propBrightness" min="0" max="200" value="${f.brightness}"></div>`;
    html += `<div class="field"><label>Kontrast <span>${f.contrast}%</span></label><input type="range" id="propContrast" min="0" max="200" value="${f.contrast}"></div>`;
    html += `<div class="field"><label>Nasycenie <span>${f.saturate}%</span></label><input type="range" id="propSaturate" min="0" max="200" value="${f.saturate}"></div>`;
    html += `<p class="hint" style="color:var(--text-dim); font-size:11px;">💡 Nachodzące na siebie klipy na tej samej ścieżce (przeciągnij jeden na drugi) automatycznie tworzą przenikanie (crossfade).</p>`;
  }
  html += `<div class="row" style="margin-top:10px;">
    <button id="propDeleteBtn" class="chip" style="flex:1; color:var(--danger);">🗑️ Usuń</button>
    <button id="propRippleDeleteBtn" class="chip" style="flex:1;" title="Usuwa klip i zsuwa kolejne, żeby zamknąć lukę">🌊 Usuń i zsuń</button>
  </div>`;
  propsContent.innerHTML = html;

  const upd = fn=>{ fn(); renderTracks(); renderFrame(currentTime); };
  const ps = document.getElementById('propStart'), pd = document.getElementById('propDur'), pv = document.getElementById('propVolume');
  if(ps){ ps.oninput=e=>upd(()=>clip.start=+e.target.value); ps.onchange=()=>{renderProps();pushHistory();}; }
  if(pd){ pd.oninput=e=>upd(()=>clip.duration=+e.target.value); pd.onchange=()=>{renderProps();pushHistory();}; }
  if(pv){ pv.oninput=e=>upd(()=>clip.volume=+e.target.value); pv.onchange=()=>{renderProps();pushHistory();}; }
  const pb = document.getElementById('propBrightness'), pc = document.getElementById('propContrast'), psat = document.getElementById('propSaturate');
  if(pb){ pb.oninput=e=>upd(()=>clip.filters.brightness=+e.target.value); pb.onchange=()=>{renderProps();pushHistory();}; }
  if(pc){ pc.oninput=e=>upd(()=>clip.filters.contrast=+e.target.value); pc.onchange=()=>{renderProps();pushHistory();}; }
  if(psat){ psat.oninput=e=>upd(()=>clip.filters.saturate=+e.target.value); psat.onchange=()=>{renderProps();pushHistory();}; }
  propsContent.querySelectorAll('[data-fpreset]').forEach(b=>{
    b.onclick = ()=>{
      Object.assign(clip.filters, CLIP_FILTER_PRESETS[b.dataset.fpreset]);
      renderProps(); renderFrame(currentTime); pushHistory();
    };
  });
  document.getElementById('propDeleteBtn').onclick = ()=> deleteClip(clip.id);
  document.getElementById('propRippleDeleteBtn').onclick = ()=> rippleDeleteClip(clip.id);
}

function renderTextProps(clip){
  if(clip.bold===undefined) clip.bold=true;
  if(clip.italic===undefined) clip.italic=false;
  if(clip.opacity===undefined) clip.opacity=100;
  if(clip.bgEnabled===undefined) clip.bgEnabled=false;
  if(clip.bgColor===undefined) clip.bgColor='#000000';
  if(clip.bgOpacity===undefined) clip.bgOpacity=80;
  if(clip.bgPadding===undefined) clip.bgPadding=16;
  if(clip.fadeIn===undefined) clip.fadeIn=0;
  if(clip.fadeOut===undefined) clip.fadeOut=0;

  const fontOptions = (list)=> list.map(f=>{
    const css = txtFontCss(f);
    return `<option value='${css}' style="font-family:${css}" ${clip.fontFamily===css?'selected':''}>${f}</option>`;
  }).join('');
  let html = `
    <div class="field"><label>Treść</label><textarea id="propText" rows="3">${escapeHtml(clip.text)}</textarea></div>
    <div class="field"><label>Czcionka</label>
      <select id="propFont">
        <optgroup label="⭐ Wbudowane">${fontOptions(TXT_FONTS_EMBEDDED)}</optgroup>
        <optgroup label="Systemowe">${fontOptions(TXT_FONTS_SYSTEM)}</optgroup>
      </select>
    </div>
    <div class="field"><label>Rozmiar <span>${clip.fontSize}px</span></label><input type="range" id="propFontSize" min="12" max="200" value="${clip.fontSize}"></div>
    <div class="row">
      <div class="field"><label>Kolor</label><input type="color" id="propColor" value="${clip.color}"></div>
      <div class="field"><label>Obrys</label><input type="color" id="propStroke" value="${clip.strokeColor}"></div>
    </div>
    <div class="field"><label>Grubość obrysu <span>${clip.strokeWidth}</span></label><input type="range" id="propStrokeWidth" min="0" max="20" value="${clip.strokeWidth}"></div>
    <div class="field"><label>Styl</label><div class="chip-row">
      <button class="chip ${clip.bold?'active':''}" id="propBold">Pogrubienie</button>
      <button class="chip ${clip.italic?'active':''}" id="propItalic">Kursywa</button>
    </div></div>
    <div class="field"><label>Wyrównanie</label><div class="chip-row">
      <button class="chip ${clip.align==='left'?'active':''}" data-align="left">Lewo</button>
      <button class="chip ${clip.align==='center'?'active':''}" data-align="center">Środek</button>
      <button class="chip ${clip.align==='right'?'active':''}" data-align="right">Prawo</button>
    </div></div>
    <div class="field"><label>Przezroczystość <span>${clip.opacity}%</span></label><input type="range" id="propOpacity" min="0" max="100" value="${clip.opacity}"></div>
    <h3 style="margin-top:14px;">Tło pod tekstem</h3>
    <div class="field"><label>Włącz tło <input type="checkbox" id="propBgOn" ${clip.bgEnabled?'checked':''}></label></div>
    ${clip.bgEnabled ? `
    <div class="row">
      <div class="field"><label>Kolor tła</label><input type="color" id="propBgColor" value="${clip.bgColor}"></div>
      <div class="field"><label>Krycie <span>${clip.bgOpacity}%</span></label><input type="range" id="propBgOpacity" min="0" max="100" value="${clip.bgOpacity}"></div>
    </div>
    <div class="field"><label>Margines <span>${clip.bgPadding}px</span></label><input type="range" id="propBgPadding" min="0" max="50" value="${clip.bgPadding}"></div>
    ` : ''}
    <h3 style="margin-top:14px;">Animacja (jak w CapCut)</h3>
    <div class="row">
      <div class="field"><label>Pojawianie <span>${clip.fadeIn}s</span></label><input type="range" id="propFadeIn" min="0" max="2" step="0.05" value="${clip.fadeIn}"></div>
      <div class="field"><label>Znikanie <span>${clip.fadeOut}s</span></label><input type="range" id="propFadeOut" min="0" max="2" step="0.05" value="${clip.fadeOut}"></div>
    </div>
    <div class="row">
      <div class="field"><label>Pozycja X <span>${clip.x}%</span></label><input type="range" id="propX" min="0" max="100" value="${clip.x}"></div>
      <div class="field"><label>Pozycja Y <span>${clip.y}%</span></label><input type="range" id="propY" min="0" max="100" value="${clip.y}"></div>
    </div>
    <div class="field"><label>Start na osi <span>${clip.start.toFixed(2)}s</span></label><input type="range" id="propStart" min="0" max="${Math.max(30,projectDuration())}" step="0.05" value="${clip.start}"></div>
    <div class="field"><label>Długość <span>${clip.duration.toFixed(2)}s</span></label><input type="range" id="propDur" min="0.2" max="60" step="0.05" value="${clip.duration}"></div>
    <div class="row" style="margin-top:10px;">
      <button id="propDeleteBtn" class="chip" style="flex:1; color:var(--danger);">🗑️ Usuń</button>
      <button id="propRippleDeleteBtn" class="chip" style="flex:1;">🌊 Usuń i zsuń</button>
    </div>
  `;
  propsContent.innerHTML = html;
  const upd = fn=>{ fn(); renderTracks(); renderFrame(currentTime); };
  document.getElementById('propText').oninput = e=>upd(()=>clip.text=e.target.value);
  document.getElementById('propText').onblur = ()=>pushHistory();
  document.getElementById('propFont').onchange = e=>{ clip.fontFamily=e.target.value; renderFrame(currentTime); pushHistory(); };
  const fs = document.getElementById('propFontSize'), pc = document.getElementById('propColor'), psw = document.getElementById('propStroke'), pswW = document.getElementById('propStrokeWidth');
  fs.oninput=e=>upd(()=>clip.fontSize=+e.target.value); fs.onchange=()=>{renderProps();pushHistory();};
  pc.oninput=e=>upd(()=>clip.color=e.target.value); pc.onchange=()=>pushHistory();
  psw.oninput=e=>upd(()=>clip.strokeColor=e.target.value); psw.onchange=()=>pushHistory();
  pswW.oninput=e=>upd(()=>clip.strokeWidth=+e.target.value); pswW.onchange=()=>{renderProps();pushHistory();};
  document.getElementById('propBold').onclick = ()=>{ clip.bold=!clip.bold; renderProps(); renderFrame(currentTime); pushHistory(); };
  document.getElementById('propItalic').onclick = ()=>{ clip.italic=!clip.italic; renderProps(); renderFrame(currentTime); pushHistory(); };
  propsContent.querySelectorAll('[data-align]').forEach(b=>{
    b.onclick = ()=>{ clip.align=b.dataset.align; renderProps(); renderFrame(currentTime); pushHistory(); };
  });
  const po = document.getElementById('propOpacity');
  po.oninput=e=>upd(()=>clip.opacity=+e.target.value); po.onchange=()=>{renderProps();pushHistory();};
  document.getElementById('propBgOn').onchange = e=>{ clip.bgEnabled=e.target.checked; renderProps(); renderFrame(currentTime); pushHistory(); };
  const pbgc = document.getElementById('propBgColor'), pbgo = document.getElementById('propBgOpacity'), pbgp = document.getElementById('propBgPadding');
  if(pbgc){ pbgc.oninput=e=>upd(()=>clip.bgColor=e.target.value); pbgc.onchange=()=>pushHistory(); }
  if(pbgo){ pbgo.oninput=e=>upd(()=>clip.bgOpacity=+e.target.value); pbgo.onchange=()=>{renderProps();pushHistory();}; }
  if(pbgp){ pbgp.oninput=e=>upd(()=>clip.bgPadding=+e.target.value); pbgp.onchange=()=>{renderProps();pushHistory();}; }
  const pfi = document.getElementById('propFadeIn'), pfo = document.getElementById('propFadeOut');
  pfi.oninput=e=>upd(()=>clip.fadeIn=+e.target.value); pfi.onchange=()=>{renderProps();pushHistory();};
  pfo.oninput=e=>upd(()=>clip.fadeOut=+e.target.value); pfo.onchange=()=>{renderProps();pushHistory();};
  const px = document.getElementById('propX'), py = document.getElementById('propY');
  px.oninput=e=>upd(()=>clip.x=+e.target.value); px.onchange=()=>{renderProps();pushHistory();};
  py.oninput=e=>upd(()=>clip.y=+e.target.value); py.onchange=()=>{renderProps();pushHistory();};
  const ps = document.getElementById('propStart'), pd = document.getElementById('propDur');
  ps.oninput=e=>upd(()=>clip.start=+e.target.value); ps.onchange=()=>{renderProps();pushHistory();};
  pd.oninput=e=>upd(()=>clip.duration=+e.target.value); pd.onchange=()=>{renderProps();pushHistory();};
  document.getElementById('propDeleteBtn').onclick = ()=> deleteClip(clip.id);
  document.getElementById('propRippleDeleteBtn').onclick = ()=> rippleDeleteClip(clip.id);
}

// ---------- PASEK NARZĘDZI OSI CZASU ----------
document.getElementById('splitBtn').onclick = ()=>{ if(selectedClipId) splitClipAt(selectedClipId, currentTime); };
document.getElementById('deleteClipBtn').onclick = ()=>{ if(selectedClipId) deleteClip(selectedClipId); };
document.getElementById('addVideoTrackBtn').onclick = ()=>{ addTrack('visual'); pushHistory(); };
document.getElementById('addAudioTrackBtn').onclick = ()=>{ addTrack('audio'); pushHistory(); };
function computeMinZoom(){
  const availWidth = Math.max(100, timelineScroll.clientWidth - 80);
  const dur = Math.max(3, projectDuration());
  return Math.max(3, availWidth/dur);
}
document.getElementById('zoomInBtn').onclick = ()=>{ pxPerSec = Math.min(400, pxPerSec*1.3); renderTracks(); };
document.getElementById('zoomOutBtn').onclick = ()=>{ pxPerSec = Math.max(computeMinZoom(), pxPerSec/1.3); renderTracks(); };
document.getElementById('fitZoomBtn').onclick = ()=>{ pxPerSec = computeMinZoom(); renderTracks(); };

// klik na pusty obszar osi czasu = odznacz
tracksContainer.addEventListener('pointerdown', (e)=>{
  if(e.target===tracksContainer || e.target.classList.contains('track-row')){
    selectClip(null);
  }
});

// ---------- HISTORIA (UNDO/REDO) ----------
function pushHistory(){
  if(suppressHistory) return;
  history = history.slice(0, historyIndex+1);
  history.push(JSON.stringify(project));
  if(history.length>60) history.shift();
  historyIndex = history.length-1;
}
function undo(){
  if(historyIndex<=0) return;
  historyIndex--;
  suppressHistory = true;
  project = JSON.parse(history[historyIndex]);
  selectedClipId = null;
  renderTracks(); renderProps(); renderFrame(currentTime);
  suppressHistory = false;
}
function redo(){
  if(historyIndex>=history.length-1) return;
  historyIndex++;
  suppressHistory = true;
  project = JSON.parse(history[historyIndex]);
  selectedClipId = null;
  renderTracks(); renderProps(); renderFrame(currentTime);
  suppressHistory = false;
}
document.getElementById('undoBtn').onclick = undo;
document.getElementById('redoBtn').onclick = redo;
window.addEventListener('keydown', (e)=>{
  if((e.ctrlKey||e.metaKey) && e.key==='z' && !e.shiftKey){ e.preventDefault(); undo(); }
  if((e.ctrlKey||e.metaKey) && (e.key==='y' || (e.key==='z'&&e.shiftKey))){ e.preventDefault(); redo(); }
});

// ---------- ZAPIS / WCZYTANIE PROJEKTU ----------
document.getElementById('saveProjectBtn').onclick = ()=>{
  const data = {
    project,
    mediaMeta: mediaLibrary.map(m=>({id:m.id, name:m.name, type:m.type, duration:m.duration, width:m.width, height:m.height}))
  };
  const blob = new Blob([JSON.stringify(data)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'projekt-montaz.json';
  a.click();
  setTimeout(()=>URL.revokeObjectURL(url), 2000);
};

let pendingRelink = false;
document.getElementById('loadProjectBtn').onclick = ()=> projectInput.click();
projectInput.addEventListener('change', (e)=>{
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = (ev)=>{
    try{
      const data = JSON.parse(ev.target.result);
      project = data.project;
      mediaLibrary = (data.mediaMeta||[]).map(m=>({...m, file:null, url:null, el:null}));
      selectedClipId = null;
      renderMediaList(); renderTracks(); renderProps(); renderFrame(0);
      if(mediaLibrary.length>0){
        alert('Projekt wczytany. Teraz zaznacz oryginalne pliki mediów (Importuj media), żeby połączyć je z osią czasu — appka dopasuje je po nazwie pliku.');
        pendingRelink = true;
      }
      pushHistory();
    }catch(err){ alert('Nie udało się wczytać projektu — plik jest uszkodzony.'); }
  };
  reader.readAsText(file);
  projectInput.value = '';
});

// przy imporcie, jesli czekamy na relink, dopasuj po nazwie zamiast dodawac nowe wpisy
const _origImportFiles = importFiles;
importFiles = function(fileList){
  if(pendingRelink){
    Array.from(fileList).forEach(file=>{
      const placeholder = mediaLibrary.find(m=>m.name===file.name && !m.el);
      if(!placeholder) return;
      const url = URL.createObjectURL(file);
      placeholder.file = file; placeholder.url = url;
      if(placeholder.type==='video'){
        const v = document.createElement('video'); v.src=url; v.preload='metadata';
        v.onloadedmetadata = ()=>{ placeholder.el=v; renderMediaList(); };
      } else if(placeholder.type==='audio'){
        const a = document.createElement('audio'); a.src=url; a.preload='metadata';
        a.onloadedmetadata = ()=>{ placeholder.el=a; renderMediaList(); };
      } else if(placeholder.type==='image'){
        const img = new Image(); img.onload=()=>{ placeholder.el=img; renderMediaList(); }; img.src=url;
      }
    });
    renderMediaList();
    return;
  }
  _origImportFiles(fileList);
};

// ---------- PROPORCJE / ROZDZIELCZOŚĆ PROJEKTU ----------
document.getElementById('aspectSelect').onchange = (e)=>{
  const [w,h] = e.target.value.split('x').map(Number);
  project.width = w; project.height = h;
  previewCanvas.width = w; previewCanvas.height = h;
  renderFrame(currentTime);
  pushHistory();
};

// ---------- USTAWIENIA STANOWISKA (LOKALNE, TYLKO NA TYM KOMPUTERZE) ----------
const DEFAULT_WORKSPACE_SETTINGS = { accentColor:'#7c5cff', trackHeight:56, defaultZoom:60, autoplay:false };
let workspaceSettings = { ...DEFAULT_WORKSPACE_SETTINGS };

function loadWorkspaceSettings(){
  try{
    const raw = localStorage.getItem('montaz_workspace_settings');
    if(raw) workspaceSettings = { ...DEFAULT_WORKSPACE_SETTINGS, ...JSON.parse(raw) };
  }catch(e){}
  applyWorkspaceSettings();
}
function saveWorkspaceSettings(){
  localStorage.setItem('montaz_workspace_settings', JSON.stringify(workspaceSettings));
}
function applyWorkspaceSettings(){
  document.documentElement.style.setProperty('--accent', workspaceSettings.accentColor);
  document.documentElement.style.setProperty('--track-height', workspaceSettings.trackHeight+'px');
  document.documentElement.style.setProperty('--clip-height', Math.max(20,workspaceSettings.trackHeight-8)+'px');
  pxPerSec = workspaceSettings.defaultZoom;
}

const settingsModal = document.getElementById('settingsModal');
document.getElementById('settingsBtn').onclick = ()=>{
  document.getElementById('setAccentColor').value = workspaceSettings.accentColor;
  document.getElementById('setTrackHeight').value = workspaceSettings.trackHeight;
  document.getElementById('setTrackHeightLbl').textContent = workspaceSettings.trackHeight+'px';
  document.getElementById('setDefaultZoom').value = workspaceSettings.defaultZoom;
  document.getElementById('setZoomLbl').textContent = workspaceSettings.defaultZoom+'px/s';
  document.getElementById('setAutoplay').checked = workspaceSettings.autoplay;
  settingsModal.style.display = 'flex';
};
document.getElementById('settingsClose').onclick = ()=>{ settingsModal.style.display='none'; };
settingsModal.addEventListener('click', e=>{ if(e.target===settingsModal) settingsModal.style.display='none'; });
document.getElementById('setAccentColor').oninput = e=>{ workspaceSettings.accentColor=e.target.value; applyWorkspaceSettings(); saveWorkspaceSettings(); };
document.getElementById('setTrackHeight').oninput = e=>{
  workspaceSettings.trackHeight=+e.target.value;
  document.getElementById('setTrackHeightLbl').textContent = workspaceSettings.trackHeight+'px';
  applyWorkspaceSettings(); saveWorkspaceSettings(); renderTracks();
};
document.getElementById('setDefaultZoom').oninput = e=>{
  workspaceSettings.defaultZoom=+e.target.value;
  document.getElementById('setZoomLbl').textContent = workspaceSettings.defaultZoom+'px/s';
  saveWorkspaceSettings();
};
document.getElementById('setAutoplay').onchange = e=>{ workspaceSettings.autoplay=e.target.checked; saveWorkspaceSettings(); };
document.getElementById('settingsResetBtn').onclick = ()=>{
  workspaceSettings = { ...DEFAULT_WORKSPACE_SETTINGS };
  saveWorkspaceSettings(); applyWorkspaceSettings();
  document.getElementById('settingsBtn').click();
  renderTracks();
};

// ---------- TEKST NA WIDEO (fonty wspoldzielone z fonts.css) ----------
const TXT_FONTS_EMBEDDED = [
  'Anton','Bebas Neue','Archivo Black','Alfa Slab One','Russo One','Staatliches',
  'Bangers','Creepster','Shrikhand','Bungee','Righteous','Poppins Black',
  'Oswald','Orbitron','VT323','Press Start 2P','Fredoka','Permanent Marker',
  'Bad Script','Kalam','Caveat','Sacramento','Pacifico','Lobster',
  'Montserrat','Raleway','Poppins','Open Sans','Nunito','Rubik','Inter','Barlow',
  'Work Sans','Quicksand','Comfortaa','DM Sans','Manrope','Karla','Mukta','Ubuntu',
  'PT Sans','Lora','Playfair Display','Crimson Text','Cinzel','Abril Fatface',
  'Passion One','Rammetto One','Baloo 2','Titan One','Fjalla One'
];
const TXT_FONTS_SYSTEM = ['Arial','Arial Black','Verdana','Tahoma','Trebuchet MS','Georgia','Times New Roman','Impact','Segoe UI','Comic Sans MS','Calibri','Century Gothic'];
function txtFontCss(name){ return /[^A-Za-z0-9]/.test(name) ? `"${name}"` : name; }

document.getElementById('addTextBtn').onclick = ()=>{
  let track = visualTracks()[visualTracks().length-1];
  if(!track || track.clips.some(c=> currentTime>=c.start && currentTime<c.start+c.duration)){
    track = addTrack('visual');
  }
  const clip = {
    id: uidClip(), trackId: track.id, mediaId:null, type:'text',
    start: currentTime, duration: 3,
    sourceIn:0, sourceOut:3, volume:100,
    text:'Twój tekst', fontFamily:'Anton', fontSize:64, color:'#ffffff',
    strokeColor:'#000000', strokeWidth:6, align:'center', x:50, y:85,
    bold:true, italic:false, opacity:100,
    bgEnabled:false, bgColor:'#000000', bgOpacity:80, bgPadding:16,
    fadeIn:0, fadeOut:0
  };
  track.clips.push(clip);
  selectClip(clip.id);
  ensureWholeTimelineVisible();
  renderTracks();
  pushHistory();
};

// ---------- PRZYCIĘCIE MAGNETYCZNE (SNAPPING, jak w CapCut) ----------
const SNAP_PX = 10;
function collectSnapPoints(excludeClipId){
  const points = [0, currentTime];
  project.tracks.forEach(tr=> tr.clips.forEach(c=>{
    if(c.id===excludeClipId) return;
    points.push(c.start, c.start+c.duration);
  }));
  return points;
}
function snapTime(t, excludeClipId){
  const pxThreshold = SNAP_PX/pxPerSec;
  const points = collectSnapPoints(excludeClipId);
  let best = t, bestDist = pxThreshold;
  points.forEach(p=>{
    const d = Math.abs(p-t);
    if(d < bestDist){ bestDist = d; best = p; }
  });
  return best;
}

// ---------- RIPPLE DELETE (usuń i zsuń pozostałe klipy) ----------
function rippleDeleteClip(id){
  const found = getClipById(id);
  if(!found) return;
  const { clip, track } = found;
  const removedDur = clip.duration;
  const removedStart = clip.start;
  track.clips = track.clips.filter(c=>c.id!==id);
  track.clips.forEach(c=>{
    if(c.start >= removedStart+removedDur-0.001) c.start -= removedDur;
  });
  if(selectedClipId===id) selectedClipId=null;
  renderTracks(); renderProps(); pushHistory();
}

// ---------- FILTRY / PRZEJŚCIA (pierwsze efekty) ----------
const CLIP_FILTER_PRESETS = {
  naturalny:  {brightness:100, contrast:100, saturate:100},
  zywe:       {brightness:105, contrast:115, saturate:145},
  czb:        {brightness:100, contrast:110, saturate:0},
  cieple:     {brightness:105, contrast:100, saturate:115},
  chlodne:    {brightness:100, contrast:108, saturate:110},
  vhs:        {brightness:95,  contrast:120, saturate:80}
};

function activeClipsOnTrack(track, t){
  return track.clips.filter(c=> t>=c.start && t < c.start+c.duration).sort((a,b)=>a.start-b.start);
}

// ---------- AUTOMATYCZNE NAPISY (AI / Whisper) ----------
const captionsModal = document.getElementById('captionsModal');
const capClipSelect = document.getElementById('capClipSelect');
let capQuality = 'zbalansowany';

function listTranscribableClips(){
  const out = [];
  project.tracks.forEach(tr=>{
    tr.clips.forEach(c=>{
      if(c.type==='video' || c.type==='audio') out.push(c);
    });
  });
  return out;
}

document.getElementById('autoCaptionsBtn').onclick = ()=>{
  const clips = listTranscribableClips();
  if(clips.length===0){ alert('Najpierw dodaj na oś czasu jakiś klip wideo albo audio z dźwiękiem.'); return; }
  capClipSelect.innerHTML = clips.map(c=>{
    const media = getMediaById(c.mediaId);
    return `<option value="${c.id}">${escapeHtml(media?media.name:c.id)} (${fmtTime(c.start)} – ${fmtTime(c.start+c.duration)})</option>`;
  }).join('');
  document.getElementById('captionsSetupView').style.display = 'block';
  document.getElementById('captionsProgressView').style.display = 'none';
  captionsModal.style.display = 'flex';
};
document.getElementById('captionsClose').onclick = ()=>{ captionsModal.style.display='none'; };
captionsModal.addEventListener('click', e=>{ if(e.target===captionsModal) captionsModal.style.display='none'; });
document.querySelectorAll('#captionsSetupView [data-quality]').forEach(b=>{
  b.onclick = ()=>{
    document.querySelectorAll('#captionsSetupView [data-quality]').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');
    capQuality = b.dataset.quality;
  };
});

async function extractAudioForWhisper(clip){
  const media = getMediaById(clip.mediaId);
  if(!media || !media.file) throw new Error('Brak oryginalnego pliku dla tego klipu.');
  const arrayBuffer = await media.file.arrayBuffer();
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  const actx = new AudioCtx();
  const decoded = await actx.decodeAudioData(arrayBuffer);
  const startSample = Math.max(0, Math.floor(clip.sourceIn * decoded.sampleRate));
  const endSample = Math.min(decoded.length, Math.floor(clip.sourceOut * decoded.sampleRate));
  const length = Math.max(1, endSample-startSample);
  const channels = [];
  for(let c=0;c<decoded.numberOfChannels;c++) channels.push(decoded.getChannelData(c));
  const mono = new Float32Array(length);
  for(let i=0;i<length;i++){
    let sum=0;
    for(let c=0;c<channels.length;c++) sum += channels[c][startSample+i] || 0;
    mono[i] = sum/channels.length;
  }
  const targetRate = 16000;
  const offlineCtx = new OfflineAudioContext(1, Math.ceil(length*targetRate/decoded.sampleRate), targetRate);
  const buffer = offlineCtx.createBuffer(1, length, decoded.sampleRate);
  buffer.copyToChannel(mono, 0);
  const src = offlineCtx.createBufferSource();
  src.buffer = buffer;
  src.connect(offlineCtx.destination);
  src.start();
  const rendered = await offlineCtx.startRendering();
  actx.close();
  return rendered.getChannelData(0);
}

function setCapProgress(pct, text){
  document.getElementById('capProgressBar').style.width = Math.max(0,Math.min(100,pct))+'%';
  if(text) document.getElementById('capStatusText').textContent = text;
}

document.getElementById('capStartBtn').onclick = async ()=>{
  const clipId = capClipSelect.value;
  const found = getClipById(clipId);
  if(!found) return;
  const clip = found.clip;
  const language = document.getElementById('capLanguage').value;

  document.getElementById('captionsSetupView').style.display = 'none';
  document.getElementById('captionsProgressView').style.display = 'block';
  setCapProgress(2, 'Wyciągam ścieżkę dźwiękową z klipu...');

  try{
    if(!window.whisperEngine){
      await new Promise(res=>{
        if(window.whisperEngine) return res();
        window.addEventListener('whisper-ready', res, {once:true});
      });
    }
    const audio = await extractAudioForWhisper(clip);
    setCapProgress(8, 'Pobieram / ładuję model AI (jednorazowo)...');
    const segments = await window.whisperEngine.transcribe(audio, {
      quality: capQuality,
      language,
      onProgress: (p)=>{
        if(p && p.status==='progress' && p.file){
          const pct = 8 + Math.round((p.progress||0)*0.6);
          setCapProgress(pct, `Pobieram model AI: ${p.file} (${Math.round(p.progress||0)}%)`);
        } else if(p && p.status==='ready'){
          setCapProgress(70, 'Model gotowy — analizuję dźwięk...');
        }
      }
    });
    setCapProgress(92, 'Tworzę klipy z napisami...');

    let textTrack = project.tracks.find(t=>t.kind==='visual' && t.__isCaptionTrack);
    if(!textTrack){
      textTrack = addTrack('visual');
      textTrack.__isCaptionTrack = true;
    }
    segments.forEach(seg=>{
      textTrack.clips.push({
        id: uidClip(), trackId: textTrack.id, mediaId:null, type:'text',
        start: clip.start+seg.start, duration: Math.max(0.3, seg.end-seg.start),
        sourceIn:0, sourceOut: Math.max(0.3, seg.end-seg.start), volume:100,
        text: seg.text, fontFamily:'Anton', fontSize:48, color:'#ffffff',
        strokeColor:'#000000', strokeWidth:6, align:'center', x:50, y:88,
        bold:true, italic:false, opacity:100,
        bgEnabled:false, bgColor:'#000000', bgOpacity:80, bgPadding:16,
        fadeIn:0, fadeOut:0
      });
    });
    renderTracks(); renderFrame(currentTime); pushHistory();
    setCapProgress(100, `Gotowe! Dodano ${segments.length} napisów.`);
    setTimeout(()=>{ captionsModal.style.display='none'; }, 1200);
  }catch(err){
    setCapProgress(0, '❌ Błąd: '+(err.message||err));
  }
};

// ---------- EKSPORT WIDEO (przechwytywanie klatka po klatce + miks audio + ffmpeg) ----------
const exportModal = document.getElementById('exportModal');
let exportQuality = 'srednia';

document.getElementById('exportBtn').onclick = ()=>{
  if(projectDuration() < 0.1){ alert('Dodaj najpierw coś na oś czasu.'); return; }
  document.getElementById('exportSetupView').style.display = 'block';
  document.getElementById('exportProgressView').style.display = 'none';
  exportModal.style.display = 'flex';
};
document.getElementById('exportModalClose').onclick = ()=>{ exportModal.style.display='none'; };
document.querySelectorAll('#exportSetupView [data-exq]').forEach(b=>{
  b.onclick = ()=>{
    document.querySelectorAll('#exportSetupView [data-exq]').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');
    exportQuality = b.dataset.exq;
  };
});

function setExportProgress(pct, text){
  document.getElementById('exportProgressBar').style.width = Math.max(0,Math.min(100,pct))+'%';
  if(text) document.getElementById('exportStatusText').textContent = text;
}

function seekVideoPrecise(el, time){
  return new Promise(resolve=>{
    if(Math.abs(el.currentTime-time) < 0.01){ resolve(); return; }
    const onSeeked = ()=>{ el.removeEventListener('seeked', onSeeked); resolve(); };
    el.addEventListener('seeked', onSeeked);
    try{ el.currentTime = time; }catch(e){ resolve(); }
  });
}

async function captureFrameAt(t){
  const seekPromises = [];
  visualTracks().forEach(track=>{
    activeClipsOnTrack(track, t).forEach(clip=>{
      if(clip.type!=='video') return;
      const media = getMediaById(clip.mediaId);
      if(!media || !media.el) return;
      const srcTime = Math.max(0, clip.sourceIn + (t-clip.start));
      seekPromises.push(seekVideoPrecise(media.el, srcTime));
    });
  });
  await Promise.all(seekPromises);
  renderFrame(t);
  return new Promise(resolve=> previewCanvas.toBlob(resolve, 'image/png'));
}

// ---------- MIKS AUDIO (wszystkie sciezki, z automatycznym crossfade) ----------
function planTrackGains(track){
  const clips = [...track.clips].filter(c=>c.type==='video'||c.type==='audio').sort((a,b)=>a.start-b.start);
  const plan = new Map();
  clips.forEach(c=> plan.set(c.id, []));
  for(let i=0;i<clips.length;i++){
    const c = clips[i];
    const vol = (c.volume!==undefined?c.volume:100)/100;
    const next = clips[i+1];
    const prev = clips[i-1];
    const points = plan.get(c.id);
    if(prev && prev.start+prev.duration > c.start+0.001){
      points.push({time:c.start, value:0});
      points.push({time:prev.start+prev.duration, value:vol});
    } else {
      points.push({time:c.start, value:vol});
    }
    if(next && c.start+c.duration > next.start+0.001){
      points.push({time:next.start, value:vol});
      points.push({time:c.start+c.duration, value:0});
    } else {
      points.push({time:c.start+c.duration, value:vol});
    }
  }
  return plan;
}

async function mixdownAudio(duration, onProgress){
  const sampleRate = 44100;
  const offlineCtx = new OfflineAudioContext(2, Math.max(1,Math.ceil(duration*sampleRate)), sampleRate);
  const relevantTracks = [...visualTracks(), ...audioTracks()];
  const allEntries = [];
  relevantTracks.forEach(track=>{
    const gains = planTrackGains(track);
    track.clips.forEach(clip=>{
      if(clip.type!=='video' && clip.type!=='audio') return;
      allEntries.push({ clip, track, gainPoints: gains.get(clip.id)||[] });
    });
  });
  if(allEntries.length===0) return null;

  const decodedCache = new Map();
  let done = 0;
  for(const entry of allEntries){
    const media = getMediaById(entry.clip.mediaId);
    if(!media || !media.file || decodedCache.has(media.id)){ done++; continue; }
    try{
      const arrBuf = await media.file.arrayBuffer();
      const tmpCtx = new (window.AudioContext||window.webkitAudioContext)();
      const decoded = await tmpCtx.decodeAudioData(arrBuf);
      decodedCache.set(media.id, decoded);
      tmpCtx.close();
    }catch(e){ /* plik bez dzwieku albo blad dekodowania - pomijamy */ }
    done++;
    if(onProgress) onProgress(done/allEntries.length);
  }

  allEntries.forEach(entry=>{
    const media = getMediaById(entry.clip.mediaId);
    const decoded = media ? decodedCache.get(media.id) : null;
    if(!decoded) return;
    const src = offlineCtx.createBufferSource();
    src.buffer = decoded;
    const gainNode = offlineCtx.createGain();
    src.connect(gainNode); gainNode.connect(offlineCtx.destination);
    const pts = entry.gainPoints;
    if(pts.length>0){
      gainNode.gain.setValueAtTime(pts[0].value, Math.max(0,pts[0].time));
      for(let i=1;i<pts.length;i++) gainNode.gain.linearRampToValueAtTime(pts[i].value, Math.max(0,pts[i].time));
    }
    const dur = Math.min(entry.clip.duration, decoded.duration-entry.clip.sourceIn);
    if(dur>0) src.start(Math.max(0,entry.clip.start), Math.max(0,entry.clip.sourceIn), dur);
  });

  return offlineCtx.startRendering();
}

function audioBufferToWavBlob(buffer){
  const numCh = buffer.numberOfChannels;
  const len = buffer.length * numCh * 2 + 44;
  const arrBuf = new ArrayBuffer(len);
  const view = new DataView(arrBuf);
  const writeStr = (offset,str)=>{ for(let i=0;i<str.length;i++) view.setUint8(offset+i, str.charCodeAt(i)); };
  writeStr(0,'RIFF'); view.setUint32(4, 36+buffer.length*numCh*2, true); writeStr(8,'WAVE');
  writeStr(12,'fmt '); view.setUint32(16,16,true); view.setUint16(20,1,true);
  view.setUint16(22,numCh,true); view.setUint32(24,buffer.sampleRate,true);
  view.setUint32(28,buffer.sampleRate*numCh*2,true); view.setUint16(32,numCh*2,true); view.setUint16(34,16,true);
  writeStr(36,'data'); view.setUint32(40,buffer.length*numCh*2,true);
  let offset = 44;
  const chData = []; for(let c=0;c<numCh;c++) chData.push(buffer.getChannelData(c));
  for(let i=0;i<buffer.length;i++){
    for(let c=0;c<numCh;c++){
      const s = Math.max(-1, Math.min(1, chData[c][i]));
      view.setInt16(offset, s<0?s*0x8000:s*0x7FFF, true);
      offset += 2;
    }
  }
  return new Blob([arrBuf], {type:'audio/wav'});
}

document.getElementById('exportStartBtn').onclick = async ()=>{
  document.getElementById('exportSetupView').style.display = 'none';
  document.getElementById('exportProgressView').style.display = 'block';
  const wasPlaying = isPlaying;
  pause();

  try{
    if(!window.ffmpegEngine){
      setExportProgress(1, 'Ładuję silnik eksportu (jednorazowo)...');
      await new Promise(res=>{
        if(window.ffmpegEngine) return res();
        window.addEventListener('ffmpeg-ready', res, {once:true});
      });
    }
    await window.ffmpegEngine.ensureLoaded((p)=>{
      if(p.phase==='loading') setExportProgress(2, 'Ładuję silnik ffmpeg (jednorazowo, ~30MB)...');
    });
    await window.ffmpegEngine.resetSession();

    const fps = project.fps || 30;
    const duration = projectDuration();
    const totalFrames = Math.max(1, Math.ceil(duration*fps));

    setExportProgress(4, 'Miksuję dźwięk ze wszystkich ścieżek...');
    const mixedBuffer = await mixdownAudio(duration, (p)=> setExportProgress(4+p*8, 'Miksuję dźwięk ze wszystkich ścieżek...'));
    let audioBlob = null;
    if(mixedBuffer){
      audioBlob = audioBufferToWavBlob(mixedBuffer);
      await window.ffmpegEngine.writeAudio(audioBlob);
    }

    for(let i=0;i<totalFrames;i++){
      const t = i/fps;
      const blob = await captureFrameAt(t);
      await window.ffmpegEngine.writeFrame(i, blob);
      const pct = 12 + (i/totalFrames)*68;
      if(i%5===0) setExportProgress(pct, `Renderuję klatki: ${i+1}/${totalFrames}`);
    }

    setExportProgress(82, 'Koduję wideo (ffmpeg)...');
    const videoBlob = await window.ffmpegEngine.encode(fps, !!audioBlob, exportQuality);
    setExportProgress(98, 'Gotowe, zapisuję plik...');

    const url = URL.createObjectURL(videoBlob);
    const a = document.createElement('a');
    a.href = url; a.download = 'moj-montaz.mp4';
    a.click();
    setTimeout(()=>URL.revokeObjectURL(url), 4000);

    setExportProgress(100, '✅ Gotowe! Plik został pobrany.');
    setTimeout(()=>{ exportModal.style.display='none'; }, 1500);
  }catch(err){
    setExportProgress(0, '❌ Błąd eksportu: '+(err.message||err));
    console.error(err);
  } finally {
    if(wasPlaying) play();
  }
};

// ---------- INIT ----------

function init(){
  loadWorkspaceSettings();
  addTrack('visual');
  addTrack('audio');
  renderMediaList();
  renderTracks();
  renderProps();
  updateTimeDisplay();
  pushHistory();
}
init();
