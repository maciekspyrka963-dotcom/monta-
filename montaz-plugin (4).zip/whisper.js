// ============================================================
// MODUŁ AUTOMATYCZNYCH NAPISÓW (Whisper, dziala w 100% lokalnie
// w przegladarce po jednorazowym pobraniu modelu AI).
// Eksponuje window.whisperEngine z metoda transcribe().
// ============================================================
import { pipeline, env } from './lib/transformers.min.js';

// wskazujemy wbudowany, lokalny plik WASM (nie CDN) - zgodnie z zasada
// ze wtyczka musi byc samodzielna
env.backends.onnx.wasm.wasmPaths = './lib/';
// WAŻNE: wymuszamy pojedynczy watek i wylaczamy proxy-worker.
// Bez tego biblioteka czasem probuje uzyc watkowanego WASM (SharedArrayBuffer),
// co wymaga specjalnych naglowkow serwera (COOP/COEP) ktorych zwykly hosting
// plikow statycznych nie ma - i wtedy cicho/glosno sie wywala. To byl glowny
// powod "bugowania sie".
env.backends.onnx.wasm.numThreads = 1;
env.backends.onnx.wasm.proxy = false;
// modele AI (wagi) sa zbyt duze zeby dolaczac je na sztywno do wtyczki,
// wiec przy pierwszym uzyciu pobiora sie z internetu i zostana zapisane
// w lokalnym cache przegladarki (IndexedDB) - kolejne uzycia dzialaja offline.
env.allowLocalModels = false;
env.useBrowserCache = true;

let currentPipeline = null;
let currentModelId = null;
let loadingPromise = null;

const MODEL_MAP = {
  szybki: 'Xenova/whisper-tiny',
  zbalansowany: 'Xenova/whisper-base',
  dokladny: 'Xenova/whisper-small'
};

async function getPipeline(quality, onProgress){
  const modelId = MODEL_MAP[quality] || MODEL_MAP.zbalansowany;
  if(currentPipeline && currentModelId===modelId) return currentPipeline;
  // jesli juz trwa ladowanie (np. user kliknal dwa razy), nie zaczynaj od nowa
  if(loadingPromise && currentModelId===modelId) return loadingPromise;
  currentModelId = modelId;
  loadingPromise = pipeline('automatic-speech-recognition', modelId, {
    progress_callback: (p)=>{
      try{ if(onProgress) onProgress(p); }catch(e){}
    }
  }).then(p=>{ currentPipeline = p; loadingPromise = null; return p; })
    .catch(err=>{ loadingPromise=null; currentModelId=null; throw err; });
  return loadingPromise;
}

// audioFloat32: Float32Array mono @ 16000Hz (patrz extractAudioForWhisper w script.js)
async function transcribe(audioFloat32, opts){
  opts = opts || {};
  const quality = opts.quality || 'zbalansowany';
  const language = opts.language || 'polish';
  const onProgress = opts.onProgress;

  if(!audioFloat32 || audioFloat32.length < 800){
    throw new Error('Ten fragment jest za krótki albo pusty (brak dźwięku do transkrypcji).');
  }

  let pipe;
  try{
    pipe = await getPipeline(quality, onProgress);
  }catch(err){
    throw new Error('Nie udało się załadować modelu AI (sprawdź połączenie z internetem przy pierwszym użyciu): '+(err.message||err));
  }

  let result;
  try{
    result = await pipe(audioFloat32, {
      language,
      task: 'transcribe',
      return_timestamps: true,
      chunk_length_s: 30,
      stride_length_s: 5
    });
  }catch(err){
    throw new Error('Błąd podczas analizy dźwięku: '+(err.message||err));
  }

  const chunks = (result && result.chunks) || [];
  const segments = chunks.map(ch=>{
    const ts = ch.timestamp || [0,null];
    const start = typeof ts[0]==='number' ? ts[0] : 0;
    const end = typeof ts[1]==='number' ? ts[1] : start+2;
    return { text: (ch.text||'').trim(), start, end: Math.max(end, start+0.2) };
  }).filter(s=>s.text.length>0);

  if(segments.length===0 && result && result.text){
    // model nie zwrocil znacznikow czasu (rzadkie), ale mamy caly tekst -
    // dodaj go jako jeden segment na caly czas trwania nagrania
    segments.push({ text: result.text.trim(), start:0, end: audioFloat32.length/16000 });
  }
  return segments;
}

window.whisperEngine = { transcribe };
window.dispatchEvent(new Event('whisper-ready'));

