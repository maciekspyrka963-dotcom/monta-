// ============================================================
// MODUŁ AUTOMATYCZNYCH NAPISÓW (Whisper, dziala w 100% lokalnie
// w przegladarce po jednorazowym pobraniu modelu AI).
// Eksponuje window.whisperEngine z metoda transcribe().
// ============================================================
import { pipeline, env } from './lib/transformers.min.js';

// wskazujemy wbudowany, lokalny plik WASM (nie CDN) - zgodnie z zasada
// ze wtyczka musi byc samodzielna
env.backends.onnx.wasm.wasmPaths = './lib/';
// modele AI (wagi) sa zbyt duze zeby dolaczac je na sztywno do wtyczki,
// wiec przy pierwszym uzyciu pobiora sie z internetu i zostana zapisane
// w lokalnym cache przegladarki (IndexedDB) - kolejne uzycia dzialaja offline.
env.allowLocalModels = false;
env.useBrowserCache = true;

let currentPipeline = null;
let currentModelId = null;

const MODEL_MAP = {
  szybki: 'Xenova/whisper-tiny',
  zbalansowany: 'Xenova/whisper-base',
  dokladny: 'Xenova/whisper-small'
};

async function getPipeline(quality, onProgress){
  const modelId = MODEL_MAP[quality] || MODEL_MAP.zbalansowany;
  if(currentPipeline && currentModelId===modelId) return currentPipeline;
  currentPipeline = await pipeline('automatic-speech-recognition', modelId, {
    progress_callback: (p)=>{
      if(onProgress) onProgress(p);
    }
  });
  currentModelId = modelId;
  return currentPipeline;
}

// audioFloat32: Float32Array mono @ 16000Hz (patrz extractAudioForWhisper w script.js)
async function transcribe(audioFloat32, opts){
  opts = opts || {};
  const quality = opts.quality || 'zbalansowany';
  const language = opts.language || 'polish';
  const onProgress = opts.onProgress;
  const pipe = await getPipeline(quality, onProgress);
  const result = await pipe(audioFloat32, {
    language,
    task: 'transcribe',
    return_timestamps: true,
    chunk_length_s: 30,
    stride_length_s: 5
  });
  // result.chunks = [{text, timestamp:[start,end]}, ...]
  const segments = (result.chunks || []).map(ch=>({
    text: (ch.text||'').trim(),
    start: ch.timestamp[0],
    end: ch.timestamp[1] !== null ? ch.timestamp[1] : (ch.timestamp[0]+2)
  })).filter(s=>s.text.length>0);
  return segments;
}

window.whisperEngine = { transcribe };
window.dispatchEvent(new Event('whisper-ready'));
