// ============================================================
// MODUŁ AUTOMATYCZNYCH NAPISÓW (Whisper, dziala w 100% lokalnie
// w przegladarce po jednorazowym pobraniu modelu AI).
// Eksponuje window.whisperEngine z metoda transcribe().
// ============================================================
import { pipeline, env } from './lib/transformers.min.js';

// wskazujemy wbudowany, lokalny plik WASM (nie CDN) - zgodnie z zasada
// ze wtyczka musi byc samodzielna
env.backends.onnx.wasm.wasmPaths = './lib/';
// WAŻNE: wymuszamy pojedynczy watek i wylaczamy proxy-worker.
// Bez tego biblioteka czasem probuje uzyc watkowanego WASM (SharedArrayBuffer),
// co wymaga specjalnych naglowkow serwera (COOP/COEP) ktorych zwykly hosting
// plikow statycznych nie ma - i wtedy cicho/glosno sie wywala.
env.backends.onnx.wasm.numThreads = 1;
env.backends.onnx.wasm.proxy = false;
// modele AI (wagi) sa zbyt duze zeby dolaczac je na sztywno do wtyczki,
// wiec przy pierwszym uzyciu pobiora sie z internetu i zostana zapisane
// w lokalnym cache przegladarki (IndexedDB) - kolejne uzycia dzialaja offline.
env.allowLocalModels = false;
env.useBrowserCache = true;

const pipelines = new Map();   // modelId -> gotowy pipeline
const loading = new Map();     // modelId -> promise (w trakcie ladowania)
const readyStatus = new Map(); // modelId -> {progress, ready}

const MODEL_MAP = {
  szybki: 'Xenova/whisper-tiny',
  zbalansowany: 'Xenova/whisper-base',
  dokladny: 'Xenova/whisper-small'
};
// kolejnosc awaryjna: jesli wybrany model padnie (np. za malo pamieci na WASM),
// probujemy automatycznie lzejszym modelem zamiast po prostu pokazac blad
const FALLBACK_CHAIN = ['dokladny','zbalansowany','szybki'];

function modelIdFor(quality){ return MODEL_MAP[quality] || MODEL_MAP.zbalansowany; }

async function loadModel(modelId, onProgress){
  if(pipelines.has(modelId)) return pipelines.get(modelId);
  if(loading.has(modelId)) return loading.get(modelId);
  readyStatus.set(modelId, {progress:0, ready:false});
  const p = pipeline('automatic-speech-recognition', modelId, {
    progress_callback: (info)=>{
      try{
        if(info && info.status==='progress'){
          readyStatus.set(modelId, {progress: info.progress||0, ready:false});
        }
        if(onProgress) onProgress(info);
      }catch(e){}
    }
  }).then(p=>{
    pipelines.set(modelId, p);
    readyStatus.set(modelId, {progress:100, ready:true});
    loading.delete(modelId);
    return p;
  }).catch(err=>{
    loading.delete(modelId);
    readyStatus.delete(modelId);
    throw err;
  });
  loading.set(modelId, p);
  return p;
}

// Wgrywa najlzejszy model ("szybki") z wyprzedzeniem, w tle, zaraz po
// otwarciu aplikacji - dzieki temu tryb "Szybki" jest juz gotowy zanim
// user w ogole kliknie "Generuj napisy".
function preloadFastModel(){
  loadModel(MODEL_MAP.szybki).catch(()=>{ /* cicho - to tylko wstepne, nieblokujace ladowanie */ });
}
setTimeout(preloadFastModel, 1500);

function isModelReady(quality){
  const st = readyStatus.get(modelIdFor(quality));
  return !!(st && st.ready);
}

// audioFloat32: Float32Array mono @ 16000Hz (patrz extractAudioForWhisper w script.js)
async function transcribeWithModel(audioFloat32, modelId, language, useBeamSearch, onProgress){
  const pipe = await loadModel(modelId, onProgress);
  const genOpts = {
    language,
    task: 'transcribe',
    return_timestamps: true,
    chunk_length_s: 30,
    stride_length_s: 5,
    temperature: 0
  };
  if(useBeamSearch){ genOpts.num_beams = 3; }
  return pipe(audioFloat32, genOpts);
}

async function transcribe(audioFloat32, opts){
  opts = opts || {};
  const quality = opts.quality || 'zbalansowany';
  const language = opts.language || 'polish';
  const onProgress = opts.onProgress;

  if(!audioFloat32 || audioFloat32.length < 800){
    throw new Error('Ten fragment jest za krótki albo pusty (brak dźwięku do transkrypcji).');
  }

  const startIndex = FALLBACK_CHAIN.indexOf(quality);
  const chain = startIndex>=0 ? FALLBACK_CHAIN.slice(startIndex) : [quality];

  let result = null, lastErr = null;
  for(let i=0;i<chain.length;i++){
    const tryQuality = chain[i];
    const modelId = modelIdFor(tryQuality);
    try{
      if(i>0 && onProgress) onProgress({status:'fallback', message:`Próbuję lżejszym modelem (${tryQuality})...`});
      result = await transcribeWithModel(audioFloat32, modelId, language, tryQuality==='dokladny', onProgress);
      lastErr = null;
      break;
    }catch(err){
      lastErr = err;
      // sprobuj kolejnego, lzejszego modelu w lancuchu zamiast od razu przerywac
      continue;
    }
  }
  if(!result){
    throw new Error('Nie udało się rozpoznać mowy żadnym z dostępnych modeli: '+(lastErr && (lastErr.message||lastErr)));
  }

  const chunks = (result && result.chunks) || [];
  const segments = chunks.map(ch=>{
    const ts = ch.timestamp || [0,null];
    const start = typeof ts[0]==='number' ? ts[0] : 0;
    const end = typeof ts[1]==='number' ? ts[1] : start+2;
    return { text: (ch.text||'').trim(), start, end: Math.max(end, start+0.2) };
  }).filter(s=>s.text.length>0);

  if(segments.length===0 && result && result.text){
    // model nie zwrocil znacznikow czasu (rzadkie), ale mamy caly tekst -
    // dodaj go jako jeden segment na caly czas trwania nagrania
    segments.push({ text: result.text.trim(), start:0, end: audioFloat32.length/16000 });
  }
  return segments;
}

window.whisperEngine = { transcribe, preloadFastModel, isModelReady };
window.dispatchEvent(new Event('whisper-ready'));


