// ============================================================
// MODUŁ EKSPORTU WIDEO (ffmpeg.wasm, dziala w 100% lokalnie
// w przegladarce/aplikacji, bez wysylania czegokolwiek na serwer).
// Eksponuje window.ffmpegEngine z metodami do zapisu klatek i
// finalnego zakodowania do MP4.
// ============================================================
import { FFmpeg } from './lib/ffmpeg/index.js';
import { toBlobURL } from './lib/ffmpeg-util/index.js';

let ffmpeg = null;
let loaded = false;
let frameCount = 0;

async function ensureLoaded(onProgress){
  if(loaded) return;
  ffmpeg = new FFmpeg();
  ffmpeg.on('log', ({message})=>{ /* mozna wypisac do konsoli w razie debugowania */ });
  ffmpeg.on('progress', ({progress})=>{
    if(onProgress) onProgress({ phase:'encode', progress: Math.max(0,Math.min(1,progress)) });
  });
  const baseURL = './lib/ffmpeg-core';
  if(onProgress) onProgress({ phase:'loading', progress:0 });
  await ffmpeg.load({
    coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
    wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
  });
  loaded = true;
}

async function resetSession(){
  frameCount = 0;
}

async function writeFrame(index, blob){
  const name = `frame_${String(index).padStart(6,'0')}.png`;
  const buf = new Uint8Array(await blob.arrayBuffer());
  await ffmpeg.writeFile(name, buf);
  frameCount = Math.max(frameCount, index+1);
}

async function writeAudio(wavBlob){
  const buf = new Uint8Array(await wavBlob.arrayBuffer());
  await ffmpeg.writeFile('audio.wav', buf);
}

async function encode(fps, hasAudio, opts){
  opts = opts || {};
  const quality = opts.quality || 'srednia';
  const preset = quality==='wysoka' ? 'slow' : quality==='niska' ? 'ultrafast' : 'veryfast';
  const args = ['-framerate', String(fps), '-i', 'frame_%06d.png'];
  if(hasAudio) args.push('-i', 'audio.wav');
  args.push('-c:v','libx264','-pix_fmt','yuv420p','-preset',preset);
  if(opts.width && opts.height){
    args.push('-vf', `scale=${opts.width}:${opts.height}`);
  }
  if(opts.bitrate){
    args.push('-b:v', `${opts.bitrate}k`, '-maxrate', `${opts.bitrate}k`, '-bufsize', `${opts.bitrate*2}k`);
  } else {
    args.push('-crf', quality==='wysoka'?'18':quality==='niska'?'28':'22');
  }
  if(hasAudio) args.push('-c:a','aac','-b:a','192k','-shortest');
  args.push('-movflags','+faststart','output.mp4');
  await ffmpeg.exec(args);
  const data = await ffmpeg.readFile('output.mp4');
  const blob = new Blob([data.buffer], {type:'video/mp4'});
  // sprzatanie plikow tymczasowych z wirtualnego systemu plikow ffmpeg
  try{
    for(let i=0;i<frameCount;i++){
      await ffmpeg.deleteFile(`frame_${String(i).padStart(6,'0')}.png`).catch(()=>{});
    }
    if(hasAudio) await ffmpeg.deleteFile('audio.wav').catch(()=>{});
    await ffmpeg.deleteFile('output.mp4').catch(()=>{});
  }catch(e){}
  return blob;
}

window.ffmpegEngine = { ensureLoaded, resetSession, writeFrame, writeAudio, encode };
window.dispatchEvent(new Event('ffmpeg-ready'));
