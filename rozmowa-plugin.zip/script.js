// ===========================================================
// ROZMOWA — frontend wtyczki
// Cała komunikacja idzie przez window.sigmanek.chat.*
// Dopasowane 1:1 do prawdziwego api_rooms.php:
//   - list_rooms zwraca TYLKO pokoje, w których już jesteś
//   - role to: owner / admin / member
//   - create_room zwraca { room_id, invite_code } (bez nazwy!)
//   - join_room zwraca tylko { room_id }
//   - room_info zwraca 'room' z polem 'role' w środku (moja ranga)
//   - tylko owner/admin mogą kasować wiadomości i banować
//   - set_role przyjmuje tylko 'admin' albo 'member'
// ===========================================================

const POLL_INTERVAL_MS = 2500;

let myUserId = null;
let currentRoom = null; // { id, name, invite_code, role, room_limit }
let lastMessageId = 0;
let pollTimer = null;

const el = (id) => document.getElementById(id);

init();

async function init() {
  await loadMyIdentity();
  // Uzupełnia users_cache w bazie wiadomości - BEZ TEGO nicki w czacie
  // pokazywałyby się jako "Nieznany". Wymaga chat:syncUser w main.js/preload.js.
  try { await window.sigmanek.chat.syncUser?.(); } catch (e) { console.warn('syncUser nieudany:', e); }

  await refreshLobby();

  el('btn-create-room').addEventListener('click', onCreateRoom);
  el('btn-join-room').addEventListener('click', onJoinRoom);
  el('btn-back').addEventListener('click', leaveRoomView);
  el('room-code').addEventListener('click', copyRoomCode);
  el('btn-members').addEventListener('click', () => { el('members-panel').classList.remove('hidden'); refreshMembers(); });
  el('btn-close-members').addEventListener('click', () => el('members-panel').classList.add('hidden'));
  el('form-send').addEventListener('submit', onSendMessage);
}

async function loadMyIdentity() {
  try {
    const status = await window.sigmanek.account.status();
    const data = status?.data || status;
    myUserId = data?.id ?? data?.user_id ?? null;
  } catch (e) {
    console.error('Nie udało się pobrać konta:', e);
  }
}

// -----------------------------------------------------------
// LOBBY ("Twoje pokoje" - nie ma publicznej listy, dołączasz kodem)
// -----------------------------------------------------------
async function refreshLobby() {
  const list = el('rooms-list');
  const res = await window.sigmanek.chat.listRooms();
  if (!res || res.success === false) {
    list.innerHTML = `<p class="muted">Błąd wczytywania pokoi${res?.message ? ': ' + escapeHtml(res.message) : ''}.</p>`;
    return;
  }
  const rooms = res.rooms || [];
  if (rooms.length === 0) {
    list.innerHTML = `<p class="muted">Nie jesteś jeszcze w żadnym pokoju. Stwórz nowy albo dołącz kodem od kogoś!</p>`;
    return;
  }
  list.innerHTML = rooms.map(r => `
    <div class="room-card" data-id="${r.id}">
      <div>
        <div class="room-card-name">${escapeHtml(r.name)}</div>
        <div class="room-card-meta">Kod: ${escapeHtml(r.invite_code)} · ${r.members_count}${r.room_limit ? '/' + r.room_limit : ''} osób · ${roleLabel(r.role)}</div>
      </div>
      <button class="btn btn-primary">Otwórz</button>
    </div>
  `).join('');

  list.querySelectorAll('.room-card').forEach(card => {
    card.querySelector('button').addEventListener('click', () => enterRoom({ id: parseInt(card.dataset.id, 10) }));
  });
}

async function onCreateRoom() {
  const values = await showModal('Nowy pokój', `
    <label>Nazwa pokoju</label>
    <input id="f-name" type="text" maxlength="100" placeholder="np. Kumple z klasy">
    <label>Limit osób (puste = bez limitu)</label>
    <input id="f-limit" type="number" min="1" placeholder="bez limitu">
  `);
  if (!values) return;
  const name = values['f-name']?.trim();
  if (!name) return alert('Podaj nazwę pokoju.');
  const limit = values['f-limit']?.trim() || '';

  const res = await window.sigmanek.chat.createRoom(name, limit);
  if (!res || res.success === false) return alert(res?.message || 'Nie udało się stworzyć pokoju.');
  await enterRoom({ id: res.room_id });
}

async function onJoinRoom() {
  const values = await showModal('Dołącz do pokoju', `
    <label>Kod zaproszenia</label>
    <input id="f-code" type="text" placeholder="wklej kod od znajomego">
  `);
  if (!values) return;
  const code = values['f-code']?.trim();
  if (!code) return;

  const res = await window.sigmanek.chat.joinRoom(code);
  if (!res || res.success === false) return alert(res?.message || 'Nie udało się dołączyć do pokoju.');
  await enterRoom({ id: res.room_id });
}

// -----------------------------------------------------------
// POKÓJ / CZAT
// -----------------------------------------------------------
async function enterRoom({ id }) {
  const info = await window.sigmanek.chat.roomInfo(id);
  if (!info || info.success === false) return alert(info?.message || 'Brak dostępu do pokoju.');

  currentRoom = {
    id: info.room.id,
    name: info.room.name,
    invite_code: info.room.invite_code,
    role: info.room.role,
    room_limit: info.room.room_limit,
  };
  lastMessageId = 0;

  el('screen-lobby').classList.remove('active');
  el('screen-room').classList.add('active');
  el('room-name').textContent = currentRoom.name;
  el('room-code').textContent = 'Kod: ' + currentRoom.invite_code;
  el('messages').innerHTML = '';

  await refreshMembers();
  await pollMessages();
  clearInterval(pollTimer);
  pollTimer = setInterval(pollMessages, POLL_INTERVAL_MS);
}

function leaveRoomView() {
  clearInterval(pollTimer);
  pollTimer = null;
  currentRoom = null;
  el('members-panel').classList.add('hidden');
  el('screen-room').classList.remove('active');
  el('screen-lobby').classList.add('active');
  refreshLobby();
}

function copyRoomCode() {
  if (!currentRoom) return;
  navigator.clipboard?.writeText(currentRoom.invite_code).then(() => {
    const original = el('room-code').textContent;
    el('room-code').textContent = 'Skopiowano!';
    setTimeout(() => { el('room-code').textContent = original; }, 1200);
  });
}

async function pollMessages() {
  if (!currentRoom) return;
  const res = await window.sigmanek.chat.getMessages(currentRoom.id, lastMessageId);
  if (!res || res.success === false || !res.messages?.length) return;

  const box = el('messages');
  const wasAtBottom = box.scrollTop + box.clientHeight >= box.scrollHeight - 40;
  const canModerate = currentRoom.role === 'owner' || currentRoom.role === 'admin';

  for (const m of res.messages) {
    lastMessageId = Math.max(lastMessageId, m.id);
    const mine = myUserId !== null && String(m.user_id) === String(myUserId);
    const div = document.createElement('div');
    div.className = 'msg' + (mine ? ' mine' : '');
    const badgeClass = m.sender_role === 'owner' ? 'badge-owner' : (m.sender_role === 'admin' ? 'badge-moderator' : '');
    div.innerHTML = `
      ${mine ? '' : `<div class="msg-nick ${badgeClass}">${escapeHtml(m.nick)}</div>`}
      <div class="msg-bubble">
        ${escapeHtml(m.text)}
        ${canModerate ? `<button class="msg-del" data-id="${m.id}" title="Usuń wiadomość">×</button>` : ''}
      </div>
      <div class="msg-time">${formatTime(m.created_at)}</div>
    `;
    box.appendChild(div);
  }
  if (wasAtBottom) box.scrollTop = box.scrollHeight;

  box.querySelectorAll('.msg-del').forEach(btn => {
    btn.onclick = async () => {
      if (!confirm('Usunąć tę wiadomość?')) return;
      const res = await window.sigmanek.chat.deleteMessage(btn.dataset.id);
      if (!res || res.success === false) alert(res?.message || 'Nie udało się usunąć wiadomości.');
      btn.closest('.msg')?.remove();
    };
  });
}

async function onSendMessage(e) {
  e.preventDefault();
  const input = el('input-text');
  const text = input.value.trim();
  if (!text || !currentRoom) return;
  input.value = '';
  const res = await window.sigmanek.chat.sendMessage(currentRoom.id, text);
  if (!res || res.success === false) {
    alert(res?.message || 'Nie udało się wysłać wiadomości.');
    return;
  }
  await pollMessages();
}

// -----------------------------------------------------------
// CZŁONKOWIE / RANGI
// -----------------------------------------------------------
async function refreshMembers() {
  if (!currentRoom) return;
  const res = await window.sigmanek.chat.listMembers(currentRoom.id);
  const list = el('members-list');
  if (!res || res.success === false) {
    list.innerHTML = `<p class="muted">Błąd wczytywania członków.</p>`;
    return;
  }
  const members = (res.members || []).filter(m => !m.banned);
  const bannedMembers = (res.members || []).filter(m => m.banned);
  el('member-count').textContent = members.length;

  const rows = members.map(m => renderMemberRow(m, false)).join('');
  const bannedRows = bannedMembers.length
    ? `<h3 class="members-subheader">Zbanowani</h3>` + bannedMembers.map(m => renderMemberRow(m, true)).join('')
    : '';

  list.innerHTML = rows + bannedRows;
  bindMemberActions(list);
}

function renderMemberRow(m, isBanned) {
  const badgeClass = m.role === 'owner' ? 'badge-owner' : (m.role === 'admin' ? 'badge-moderator' : '');
  const isMe = String(m.user_id) === String(myUserId);

  let actions = '';
  if (!isMe) {
    if (isBanned) {
      if (currentRoom.role === 'owner' || currentRoom.role === 'admin') {
        actions = `<button data-action="unban" data-user="${m.user_id}">Odbanuj</button>`;
      }
    } else {
      if (currentRoom.role === 'owner') {
        actions += `
          <select data-action="role" data-user="${m.user_id}">
            <option value="member" ${m.role === 'member' ? 'selected' : ''}>Członek</option>
            <option value="admin" ${m.role === 'admin' ? 'selected' : ''}>Admin</option>
          </select>`;
      }
      const canBan = m.role !== 'owner' && (currentRoom.role === 'owner' || (currentRoom.role === 'admin' && m.role !== 'admin'));
      if (canBan) actions += `<button data-action="ban" data-user="${m.user_id}">Wyrzuć</button>`;
    }
  }

  return `
    <div class="member-row ${isBanned ? 'member-banned' : ''}">
      <span class="member-name ${badgeClass}">${escapeHtml(m.nick)} <small>(${roleLabel(m.role)})</small></span>
      <span class="member-actions">${actions}</span>
    </div>
  `;
}

function bindMemberActions(list) {
  list.querySelectorAll('[data-action="role"]').forEach(sel => {
    sel.addEventListener('change', async () => {
      const res = await window.sigmanek.chat.setRole(currentRoom.id, sel.dataset.user, sel.value);
      if (!res || res.success === false) alert(res?.message || 'Nie udało się zmienić rangi.');
      await refreshMembers();
    });
  });
  list.querySelectorAll('[data-action="ban"]').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm('Na pewno wyrzucić tego użytkownika z pokoju?')) return;
      const res = await window.sigmanek.chat.banMember(currentRoom.id, btn.dataset.user);
      if (!res || res.success === false) alert(res?.message || 'Nie udało się wyrzucić użytkownika.');
      await refreshMembers();
    });
  });
  list.querySelectorAll('[data-action="unban"]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const res = await window.sigmanek.chat.unbanMember(currentRoom.id, btn.dataset.user);
      if (!res || res.success === false) alert(res?.message || 'Nie udało się odbanować użytkownika.');
      await refreshMembers();
    });
  });
}

function roleLabel(role) {
  return { owner: 'Właściciel', admin: 'Admin', member: 'Członek' }[role] || role;
}

// -----------------------------------------------------------
// Pomocnicze
// -----------------------------------------------------------
function escapeHtml(str) {
  const d = document.createElement('div');
  d.textContent = str ?? '';
  return d.innerHTML;
}

function formatTime(dateStr) {
  try {
    const d = new Date(dateStr.replace(' ', 'T'));
    return d.toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' });
  } catch { return ''; }
}

function showModal(title, bodyHtml) {
  return new Promise(resolve => {
    el('modal-title').textContent = title;
    el('modal-body').innerHTML = bodyHtml;
    el('modal-overlay').classList.remove('hidden');

    const cleanup = () => {
      el('modal-overlay').classList.add('hidden');
      el('modal-confirm').removeEventListener('click', onConfirm);
      el('modal-cancel').removeEventListener('click', onCancel);
    };
    const onConfirm = () => {
      const inputs = el('modal-body').querySelectorAll('input');
      const values = {};
      inputs.forEach(i => values[i.id] = i.value);
      cleanup();
      resolve(values);
    };
    const onCancel = () => { cleanup(); resolve(null); };

    el('modal-confirm').addEventListener('click', onConfirm);
    el('modal-cancel').addEventListener('click', onCancel);
  });
}
