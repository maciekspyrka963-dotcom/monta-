<?php
// ============================================================
// SIGMANEK — api_rooms.php
// UWAGA: plik NIE może nazywać się "api_chat.php" - InfinityFree
// blokuje (403) każdy URL zawierający słowo "chat"!
// Wgraj obok index.php.
// ============================================================

session_start();
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/config-chat.php';

header('Content-Type: application/json; charset=utf-8');

function out($data) { echo json_encode($data); exit; }

$user = currentUser();
if (!$user) {
    http_response_code(401);
    out(['success' => false, 'message' => 'Musisz być zalogowany.']);
}

$action = $_REQUEST['action'] ?? '';

switch ($action) {

    case 'sync_user':
        db_chat()->prepare('
            INSERT INTO users_cache (id, nick, avatar, updated_at) VALUES (?,?,?,NOW())
            ON DUPLICATE KEY UPDATE nick = VALUES(nick), avatar = VALUES(avatar), updated_at = NOW()
        ')->execute([$user['id'], $user['nick'], $user['avatar'] ?? null]);
        out(['success' => true]);
        break;

    case 'list_rooms':
        $s = db()->prepare('
            SELECT r.*, m.role,
                (SELECT COUNT(*) FROM chat_room_members mm WHERE mm.room_id = r.id AND mm.banned = 0) AS members_count
            FROM chat_rooms r
            INNER JOIN chat_room_members m ON m.room_id = r.id AND m.user_id = ? AND m.banned = 0
            ORDER BY r.created_at DESC
        ');
        $s->execute([$user['id']]);
        out(['success' => true, 'rooms' => $s->fetchAll()]);
        break;

    case 'create_room':
        $name  = trim($_POST['name'] ?? '');
        $limit = ($_POST['limit'] ?? '') !== '' ? (int)$_POST['limit'] : null;
        if (!$name) out(['success' => false, 'message' => 'Podaj nazwę pokoju.']);
        if (mb_strlen($name) > 100) out(['success' => false, 'message' => 'Nazwa zbyt długa.']);

        $invite = bin2hex(random_bytes(6));
        db()->prepare('INSERT INTO chat_rooms (name, owner_id, room_limit, invite_code, created_at) VALUES (?,?,?,?,NOW())')
            ->execute([$name, $user['id'], $limit, $invite]);
        $roomId = db()->lastInsertId();
        db()->prepare('INSERT INTO chat_room_members (room_id, user_id, role) VALUES (?,?,"owner")')
            ->execute([$roomId, $user['id']]);
        out(['success' => true, 'room_id' => (int)$roomId, 'invite_code' => $invite]);
        break;

    case 'join_room':
        $code = trim($_POST['code'] ?? '');
        $r = db()->prepare('SELECT * FROM chat_rooms WHERE invite_code = ?');
        $r->execute([$code]);
        $room = $r->fetch();
        if (!$room) out(['success' => false, 'message' => 'Nieprawidłowy kod zaproszenia.']);

        $cnt = db()->prepare('SELECT COUNT(*) FROM chat_room_members WHERE room_id = ? AND banned = 0');
        $cnt->execute([$room['id']]);
        if ($room['room_limit'] && (int)$cnt->fetchColumn() >= (int)$room['room_limit']) {
            out(['success' => false, 'message' => 'Pokój jest pełny.']);
        }

        $ex = db()->prepare('SELECT * FROM chat_room_members WHERE room_id = ? AND user_id = ?');
        $ex->execute([$room['id'], $user['id']]);
        $mem = $ex->fetch();
        if ($mem && $mem['banned']) out(['success' => false, 'message' => 'Zostałeś zbanowany w tym pokoju.']);

        if (!$mem) {
            db()->prepare('INSERT INTO chat_room_members (room_id, user_id, role) VALUES (?,?,"member")')
                ->execute([$room['id'], $user['id']]);
        }
        out(['success' => true, 'room_id' => (int)$room['id']]);
        break;

    case 'room_info':
        $roomId = (int)($_GET['room_id'] ?? 0);
        $s = db()->prepare('
            SELECT r.*, m.role FROM chat_rooms r
            INNER JOIN chat_room_members m ON m.room_id = r.id AND m.user_id = ? AND m.banned = 0
            WHERE r.id = ?
        ');
        $s->execute([$user['id'], $roomId]);
        $room = $s->fetch();
        if (!$room) out(['success' => false, 'message' => 'Brak dostępu do pokoju.']);
        out(['success' => true, 'room' => $room]);
        break;

    case 'get_messages':
        $roomId  = (int)($_GET['room_id'] ?? 0);
        $afterId = (int)($_GET['after_id'] ?? 0);

        $mem = db()->prepare('SELECT * FROM chat_room_members WHERE room_id = ? AND user_id = ? AND banned = 0');
        $mem->execute([$roomId, $user['id']]);
        if (!$mem->fetch()) out(['success' => false, 'message' => 'Brak dostępu do pokoju.']);

        $s = db_chat()->prepare('SELECT id, room_id, user_id, text, created_at FROM chat_messages WHERE room_id = ? AND id > ? ORDER BY id ASC LIMIT 200');
        $s->execute([$roomId, $afterId]);
        $messages = $s->fetchAll();

        if (empty($messages)) out(['success' => true, 'messages' => []]);

        $userIds = array_unique(array_column($messages, 'user_id'));
        $placeholders = implode(',', array_fill(0, count($userIds), '?'));
        $uc = db_chat()->prepare("SELECT id, nick, avatar FROM users_cache WHERE id IN ($placeholders)");
        $uc->execute($userIds);
        $usersById = [];
        foreach ($uc->fetchAll() as $u) { $usersById[$u['id']] = $u; }

        $rolesStmt = db()->prepare("SELECT user_id, role FROM chat_room_members WHERE room_id = ? AND user_id IN ($placeholders)");
        $rolesStmt->execute(array_merge([$roomId], $userIds));
        $rolesByUser = [];
        foreach ($rolesStmt->fetchAll() as $r) { $rolesByUser[$r['user_id']] = $r['role']; }

        foreach ($messages as &$m) {
            $m['nick'] = $usersById[$m['user_id']]['nick'] ?? 'Nieznany';
            $m['avatar'] = $usersById[$m['user_id']]['avatar'] ?? null;
            $m['sender_role'] = $rolesByUser[$m['user_id']] ?? 'member';
        }
        out(['success' => true, 'messages' => $messages]);
        break;

    case 'send_message':
        $roomId = (int)($_POST['room_id'] ?? 0);
        $text   = trim($_POST['text'] ?? '');
        if (!$text) out(['success' => false, 'message' => 'Pusta wiadomość.']);
        if (mb_strlen($text) > 1000) out(['success' => false, 'message' => 'Wiadomość zbyt długa.']);

        $mem = db()->prepare('SELECT * FROM chat_room_members WHERE room_id = ? AND user_id = ? AND banned = 0');
        $mem->execute([$roomId, $user['id']]);
        if (!$mem->fetch()) out(['success' => false, 'message' => 'Brak dostępu do pokoju.']);

        db_chat()->prepare('INSERT INTO chat_messages (room_id, user_id, text, created_at) VALUES (?,?,?,NOW())')
            ->execute([$roomId, $user['id'], $text]);
        out(['success' => true]);
        break;

    case 'delete_message':
        $msgId = (int)($_POST['message_id'] ?? 0);
        $m = db_chat()->prepare('SELECT * FROM chat_messages WHERE id = ?');
        $m->execute([$msgId]);
        $msg = $m->fetch();
        if (!$msg) out(['success' => false, 'message' => 'Wiadomość nie istnieje.']);

        $mem = db()->prepare('SELECT * FROM chat_room_members WHERE room_id = ? AND user_id = ?');
        $mem->execute([$msg['room_id'], $user['id']]);
        $me = $mem->fetch();
        if (!$me || !in_array($me['role'], ['owner', 'admin'])) out(['success' => false, 'message' => 'Brak uprawnień.']);

        db_chat()->prepare('DELETE FROM chat_messages WHERE id = ?')->execute([$msgId]);
        out(['success' => true]);
        break;

    case 'list_members':
        $roomId = (int)($_GET['room_id'] ?? 0);
        $mem = db()->prepare('SELECT * FROM chat_room_members WHERE room_id = ? AND user_id = ?');
        $mem->execute([$roomId, $user['id']]);
        if (!$mem->fetch()) out(['success' => false, 'message' => 'Brak dostępu.']);

        $s = db()->prepare('
            SELECT m.role, m.banned, u.id AS user_id, u.nick, u.handle, u.avatar
            FROM chat_room_members m
            INNER JOIN users u ON u.id = m.user_id
            WHERE m.room_id = ?
            ORDER BY FIELD(m.role, "owner","admin","member"), u.nick ASC
        ');
        $s->execute([$roomId]);
        out(['success' => true, 'members' => $s->fetchAll()]);
        break;

    case 'set_role':
        $roomId = (int)($_POST['room_id'] ?? 0);
        $targetUserId = (int)($_POST['user_id'] ?? 0);
        $role = $_POST['role'] ?? 'member';
        if (!in_array($role, ['admin', 'member'])) out(['success' => false, 'message' => 'Nieprawidłowa ranga.']);

        $mem = db()->prepare('SELECT * FROM chat_room_members WHERE room_id = ? AND user_id = ?');
        $mem->execute([$roomId, $user['id']]);
        $me = $mem->fetch();
        if (!$me || $me['role'] !== 'owner') out(['success' => false, 'message' => 'Tylko właściciel może nadawać rangi.']);
        if ($targetUserId === $user['id']) out(['success' => false, 'message' => 'Nie możesz zmienić własnej rangi.']);

        db()->prepare('UPDATE chat_room_members SET role = ? WHERE room_id = ? AND user_id = ?')
            ->execute([$role, $roomId, $targetUserId]);
        out(['success' => true]);
        break;

    case 'ban_member':
        $roomId = (int)($_POST['room_id'] ?? 0);
        $targetUserId = (int)($_POST['user_id'] ?? 0);
        $mem = db()->prepare('SELECT * FROM chat_room_members WHERE room_id = ? AND user_id = ?');
        $mem->execute([$roomId, $user['id']]);
        $me = $mem->fetch();
        if (!$me || !in_array($me['role'], ['owner', 'admin'])) out(['success' => false, 'message' => 'Brak uprawnień.']);

        $target = db()->prepare('SELECT * FROM chat_room_members WHERE room_id = ? AND user_id = ?');
        $target->execute([$roomId, $targetUserId]);
        $t = $target->fetch();
        if ($t && $t['role'] === 'owner') out(['success' => false, 'message' => 'Nie można zbanować właściciela.']);
        if ($me['role'] === 'admin' && $t && $t['role'] === 'admin') out(['success' => false, 'message' => 'Admin nie może banować innego admina.']);

        db()->prepare('UPDATE chat_room_members SET banned = 1 WHERE room_id = ? AND user_id = ?')
            ->execute([$roomId, $targetUserId]);
        out(['success' => true]);
        break;

    case 'unban_member':
        $roomId = (int)($_POST['room_id'] ?? 0);
        $targetUserId = (int)($_POST['user_id'] ?? 0);
        $mem = db()->prepare('SELECT * FROM chat_room_members WHERE room_id = ? AND user_id = ?');
        $mem->execute([$roomId, $user['id']]);
        $me = $mem->fetch();
        if (!$me || !in_array($me['role'], ['owner', 'admin'])) out(['success' => false, 'message' => 'Brak uprawnień.']);

        db()->prepare('UPDATE chat_room_members SET banned = 0 WHERE room_id = ? AND user_id = ?')
            ->execute([$roomId, $targetUserId]);
        out(['success' => true]);
        break;

    default:
        http_response_code(400);
        out(['success' => false, 'message' => 'Nieznana akcja.']);
}
