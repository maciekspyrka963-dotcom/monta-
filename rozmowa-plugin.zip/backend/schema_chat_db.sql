-- ============================================================
-- Wklej w OSOBNEJ bazie na wiadomości (tej, do której łączy się db_chat())
-- Brak FOREIGN KEY do room/users - to inna baza, MySQL nie pozwala na
-- FK między różnymi bazami (a już na pewno nie na InfinityFree).
-- ============================================================

CREATE TABLE IF NOT EXISTS chat_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    user_id INT NOT NULL,
    text VARCHAR(1000) NOT NULL,
    created_at DATETIME DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_chat_messages_room ON chat_messages(room_id, id);

-- Lokalna "kopia" nicku/avatara użytkownika, uzupełniana przez
-- action=sync_user (wywoływane z frontendu przy starcie wtyczki),
-- żeby dało się wyświetlić nick przy wiadomości bez JOIN-a między bazami.
CREATE TABLE IF NOT EXISTS users_cache (
    id INT PRIMARY KEY,
    nick VARCHAR(64) NOT NULL,
    avatar VARCHAR(255) DEFAULT NULL,
    updated_at DATETIME DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
