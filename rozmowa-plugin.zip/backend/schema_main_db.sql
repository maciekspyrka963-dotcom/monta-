-- ============================================================
-- Wklej w GŁÓWNEJ bazie (tej samej co `users`)
-- ============================================================

CREATE TABLE IF NOT EXISTS chat_rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    owner_id INT NOT NULL,
    room_limit INT DEFAULT NULL,
    invite_code VARCHAR(20) NOT NULL UNIQUE,
    created_at DATETIME DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS chat_room_members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    user_id INT NOT NULL,
    role ENUM('owner','admin','member') NOT NULL DEFAULT 'member',
    banned TINYINT(1) NOT NULL DEFAULT 0,
    joined_at DATETIME DEFAULT NOW(),
    UNIQUE KEY uniq_room_user (room_id, user_id),
    CONSTRAINT fk_crm_room FOREIGN KEY (room_id) REFERENCES chat_rooms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_crm_room ON chat_room_members(room_id);
