<?php
// config-chat.php
// POMIŃ TEN PLIK jeśli już masz gdzieś zdefiniowaną funkcję db_chat()
// (skoro api_rooms.php jej używa, może już istnieć w Twoim projekcie -
// sprawdź najpierw, żeby nie mieć dwóch definicji tej samej funkcji).
//
// To połączenie do OSOBNEJ bazy danych (tylko wiadomości + cache nicków),
// osobnej od głównej bazy z `users`. Uzupełnij danymi z panelu hostingu.

function db_chat() {
    static $pdo = null;
    if ($pdo === null) {
        $host = 'sqlXXX.infinityfree.com'; // <-- zmień
        $db   = 'if0_XXXXXXX_chat';        // <-- zmień (nazwa DRUGIEJ bazy)
        $user = 'if0_XXXXXXX';             // <-- zmień
        $pass = 'twoje_haslo_do_bazy';     // <-- zmień

        $pdo = new PDO(
            "mysql:host=$host;dbname=$db;charset=utf8mb4",
            $user,
            $pass,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
    }
    return $pdo;
}
