// ============================================================
// MODUŁ AUTOMATYCZNYCH NAPISÓW (Whisper) — chunkowane, odporne
// na długie nagrania i błędy w połowie.
// ============================================================
import { pipeline, env } from './lib/transformers.min.js';

env.backends.onnx.wasm.wasmPaths = './lib/';
env.backends.onnx.wasm.numThreads = 1;
env.backends.onnx.wasm.proxy = false;
env.allowLocalModels = false;
env.useBrowserCache = true;

const pipelines = new Map();
const loading = new Map();
const readyStatus = new Map();

const MODEL_MAP = {
  szybki: 'Xenova/whisper-tiny',
  zbalansowany: 'Xenova/whisper-base',
  dokladny: 'Xenova/whisper-small'
};
const FALLBACK_CHAIN = ['dokladny', 'zbalansowany', 'szybki'];

// ~25 s @ 16 kHz — bezpieczny rozmiar dla WASM w przeglądarce
const CHUNK_SAMPLES = 16_000 * 25;
const CHUNK_OVERLAP = 16_000 * 1; // 1 s overlap, żeby nie ucinać słów

function modelIdFor(quality){ return MODEL_MAP[quality] || MODEL_MAP.zbalansowany; }

async function loadModel(modelId, onProgress){
  if(pipelines.has(modelId)) return pipelines.get(modelId);
  if(loading.has(modelId)) return loading.get(modelId);
  readyStatus.set(modelId, {progress:0, ready:false});
  const p = pipeline('automatic-speech-recognition', modelId, {
    progress_callback: (info)=>{
      try{
        if(info && info.status==='progress'){
          readyStatus.set(modelId, {progress: info.progress||0, ready:false});
        }
        if(onProgress) onProgress(info);
      }catch(e){}
    }
  }).then(pipe=>{
    pipelines.set(modelId, pipe);
    readyStatus.set(modelId, {progress:100, ready:true});
    loading.delete(modelId);
    return pipe;
  }).catch(err=>{
    loading.delete(modelId);
    throw err;
  });
  loading.set(modelId, p);
  return p;
}

function isModelReady(quality){
  const id = modelIdFor(quality);
  const s = readyStatus.get(id);
  return !!(s && s.ready);
}

async function preloadFastModel(){
  try{ await loadModel(MODEL_MAP.szybki); }catch(e){ console.warn('preload whisper-tiny:', e); }
}

/** Rozbij audio na kawałki z lekkim overlapem */
function splitAudioChunks(audioFloat32){
  const chunks = [];
  if(audioFloat32.length <= CHUNK_SAMPLES){
    chunks.push({ data: audioFloat32, offsetSec: 0 });
    return chunks;
  }
  let start = 0;
  while(start < audioFloat32.length){
    const end = Math.min(audioFloat32.length, start + CHUNK_SAMPLES);
    chunks.push({
      data: audioFloat32.subarray(start, end),
      offsetSec: start / 16000
    });
    if(end >= audioFloat32.length) break;
    start = end - CHUNK_OVERLAP;
  }
  return chunks;
}

/** Parsuj wynik Whisper (segmenty lub słowa) → płaska lista {text,start,end} */
function resultToWords(result, timeOffset){
  const words = [];
  const chunks = (result && result.chunks) || [];

  if(chunks.length > 0){
    chunks.forEach(ch=>{
      const ts = ch.timestamp || [0, null];
      const start = (typeof ts[0]==='number' ? ts[0] : 0) + timeOffset;
      let end = (typeof ts[1]==='number' ? ts[1] : start + 0.35) + timeOffset;
      if(end <= start) end = start + 0.15;
      const raw = (ch.text || '').trim();
      if(!raw) return;
      // chunk może być całym segmentem (kilka słów) albo jednym słowem
      const parts = raw.split(/\s+/).filter(Boolean);
      if(parts.length === 1){
        words.push({ text: parts[0], start, end });
      } else {
        const dur = end - start;
        const per = dur / parts.length;
        parts.forEach((w, i)=>{
          words.push({
            text: w,
            start: start + i * per,
            end: start + (i + 1) * per
          });
        });
      }
    });
    return words;
  }

  // tylko sam tekst bez timestampów
  if(result && result.text){
    const rawWords = result.text.trim().split(/\s+/).filter(Boolean);
    // bez długości chunka zakładamy 0.3 s / słowo
    rawWords.forEach((w, i)=>{
      const s = timeOffset + i * 0.3;
      words.push({ text: w, start: s, end: s + 0.28 });
    });
  }
  return words;
}

async function transcribeChunk(pipe, audioChunk, language, preferWordTs){
  const baseOpts = {
    language,
    task: 'transcribe',
    // bez beam search — dużo stabilniejsze i mniej RAM
    chunk_length_s: 30,
    stride_length_s: 5
  };

  // 1) spróbuj word timestamps
  if(preferWordTs){
    try{
      return await pipe(audioChunk, { ...baseOpts, return_timestamps: 'word' });
    }catch(e){
      console.warn('word timestamps failed, fallback segment:', e);
    }
  }
  // 2) segment timestamps (stabilniejsze)
  try{
    return await pipe(audioChunk, { ...baseOpts, return_timestamps: true });
  }catch(e){
    console.warn('segment timestamps failed, plain text:', e);
  }
  // 3) bez timestampów
  return await pipe(audioChunk, { ...baseOpts, return_timestamps: false });
}

async function transcribeWithModel(audioFloat32, modelId, language, onProgress){
  const pipe = await loadModel(modelId, onProgress);
  const chunks = splitAudioChunks(audioFloat32);
  const allWords = [];
  let failedChunks = 0;

  for(let i = 0; i < chunks.length; i++){
    const ch = chunks[i];
    if(onProgress){
      onProgress({
        status: 'transcribing',
        chunk: i + 1,
        totalChunks: chunks.length,
        progress: (i / chunks.length) * 100,
        message: `Analizuję fragment ${i + 1}/${chunks.length}…`
      });
    }
    // oddaj wątek UI między kawałkami
    await new Promise(r => setTimeout(r, 0));

    try{
      // za krótkie fragmenty pomijamy
      if(ch.data.length < 1600) continue; // <0.1 s
      const result = await transcribeChunk(pipe, ch.data, language, true);
      const words = resultToWords(result, ch.offsetSec);
      allWords.push(...words);
    }catch(err){
      failedChunks++;
      console.warn(`Chunk ${i + 1}/${chunks.length} failed:`, err);
      if(onProgress){
        onProgress({
          status: 'chunk_error',
          chunk: i + 1,
          totalChunks: chunks.length,
          message: `Fragment ${i + 1} pominięty (błąd) — kontynuuję…`
        });
      }
      // kontynuuj kolejne kawałki zamiast wywalać całość
    }
  }

  if(allWords.length === 0){
    throw new Error(
      failedChunks > 0
        ? 'Nie udało się rozpoznać mowy w żadnym fragmencie (możliwy brak dźwięku lub za mało pamięci).'
        : 'Model nie zwrócił żadnych słów.'
    );
  }

  // posortuj i zdejmij duplikaty z overlapu (to samo słowo w podobnym czasie)
  allWords.sort((a, b) => a.start - b.start);
  const deduped = [];
  for(const w of allWords){
    const prev = deduped[deduped.length - 1];
    if(prev && prev.text === w.text && Math.abs(prev.start - w.start) < 0.35){
      // zostaw dłuższy end
      prev.end = Math.max(prev.end, w.end);
      continue;
    }
    deduped.push(w);
  }

  if(onProgress){
    onProgress({
      status: 'done',
      progress: 100,
      message: failedChunks
        ? `Gotowe (pominięto ${failedChunks} fragm.) — ${deduped.length} słów`
        : `Gotowe — ${deduped.length} słów`
    });
  }
  return deduped;
}

async function transcribe(audioFloat32, opts){
  opts = opts || {};
  const quality = opts.quality || 'zbalansowany';
  const language = opts.language || 'polish';
  const onProgress = opts.onProgress;

  if(!audioFloat32 || audioFloat32.length < 800){
    throw new Error('Ten fragment jest za krótki albo pusty (brak dźwięku do transkrypcji).');
  }

  // dla bardzo długich nagrań wymuś lżejszy model (mniej OOM)
  const durationSec = audioFloat32.length / 16000;
  let effectiveQuality = quality;
  if(durationSec > 90 && quality === 'dokladny'){
    effectiveQuality = 'zbalansowany';
    if(onProgress) onProgress({ status: 'info', message: 'Długie nagranie — używam lżejszego modelu (stabilniej).' });
  }
  if(durationSec > 180 && quality !== 'szybki'){
    effectiveQuality = 'szybki';
    if(onProgress) onProgress({ status: 'info', message: 'Bardzo długie nagranie — model „szybki” (mniej pamięci).' });
  }

  const startIndex = FALLBACK_CHAIN.indexOf(effectiveQuality);
  const chain = startIndex >= 0 ? FALLBACK_CHAIN.slice(startIndex) : [effectiveQuality];

  let result = null, lastErr = null;
  for(let i = 0; i < chain.length; i++){
    const tryQuality = chain[i];
    const modelId = modelIdFor(tryQuality);
    try{
      if(i > 0 && onProgress){
        onProgress({ status: 'fallback', message: `Próbuję lżejszym modelem (${tryQuality})…` });
      }
      result = await transcribeWithModel(audioFloat32, modelId, language, onProgress);
      lastErr = null;
      break;
    }catch(err){
      lastErr = err;
      console.warn('Model failed:', tryQuality, err);
      // zwolnij pipeline przy OOM, spróbuj lżejszego
      try{ pipelines.delete(modelId); }catch(e){}
      continue;
    }
  }
  if(!result){
    throw new Error('Nie udało się rozpoznać mowy: ' + (lastErr && (lastErr.message || lastErr)));
  }
  return result;
}

window.whisperEngine = { transcribe, preloadFastModel, isModelReady };
window.dispatchEvent(new Event('whisper-ready'));
