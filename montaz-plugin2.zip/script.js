/* ============================================================
   PROSTY MONTAŻ — silnik edytora wideo (Faza 1)
   Import mediow, oś czasu wielościeżkowa, ciecie/przycinanie,
   podglad na zywo. (Teksty/przejscia/filtry/audio-mix/eksport
   dochodza w kolejnych fazach.)
   ============================================================ */

// ---------- STAN PROJEKTU ----------
let project = {
  fps: 30,
  width: 1280,
  height: 720,
  tracks: [] // {id, kind:'visual'|'audio', type:'video'|'image'|'text'|'audio-track', clips:[]}
};

let mediaLibrary = []; // {id, name, type, file, url, duration, el, width, height}
let mediaCounter = 0;
let clipCounter = 0;
let trackCounter = 0;

let selectedClipId = null;
let selectedClipIds = new Set();
let currentTime = 0;
let isPlaying = false;
let pxPerSec = 60; // poziom przybliżenia osi czasu

let history = [];
let historyIndex = -1;
let suppressHistory = false;

// ---------- DOM ----------
const previewCanvas = document.getElementById('previewCanvas');
const pctx = previewCanvas.getContext('2d');
const mediaList = document.getElementById('mediaList');
const tracksContainer = document.getElementById('tracksContainer');
const timelineRuler = document.getElementById('timelineRuler');
const timelineScroll = document.getElementById('timelineScroll');
const propsContent = document.getElementById('propsContent');
const fileInput = document.getElementById('fileInput');
const projectInput = document.getElementById('projectInput'); // opcjonalne (stary import JSON)
const timeDisplay = document.getElementById('timeDisplay');

function uidMedia(){ return 'M'+(++mediaCounter); }
function uidClip(){ return 'C'+(++clipCounter); }
function uidTrack(){ return 'T'+(++trackCounter); }

function fmtTime(t){
  if(!isFinite(t) || t<0) t=0;
  const m = Math.floor(t/60);
  const s = t-m*60;
  return `${String(m).padStart(2,'0')}:${s.toFixed(1).padStart(4,'0')}`;
}

function projectDuration(){
  let max = 0;
  project.tracks.forEach(tr=> tr.clips.forEach(c=> { max = Math.max(max, c.start+c.duration); }));
  return max;
}

// ---------- IMPORT MEDIÓW ----------
function isGifFile(file){
  if(!file) return false;
  if(file.type === 'image/gif') return true;
  return /\.gif$/i.test(file.name||'');
}

async function convertGifItem(item){
  // Konwersja animowanego GIF → MP4 przez ffmpeg (działa w podglądzie i eksporcie)
  try{
    if(!window.ffmpegEngine){
      await new Promise(res=>{
        if(window.ffmpegEngine) return res();
        window.addEventListener('ffmpeg-ready', res, {once:true});
      });
    }
    await window.ffmpegEngine.ensureLoaded();
    const mp4Blob = await window.ffmpegEngine.convertGifToMp4(item.file);
    if(item.url) URL.revokeObjectURL(item.url);
    const url = URL.createObjectURL(mp4Blob);
    item.url = url;
    item.file = new File([mp4Blob], (item.name||'gif').replace(/\.gif$/i,'.mp4'), {type:'video/mp4'});
    item.type = 'video';
    item.isGif = true;
    const v = document.createElement('video');
    v.src = url; v.preload='metadata'; v.muted=false; v.loop=false;
    await new Promise((resolve,reject)=>{
      v.onloadedmetadata = ()=> resolve();
      v.onerror = ()=> reject(new Error('Nie udało się wczytać skonwertowanego GIF'));
    });
    item.duration = v.duration || 5;
    item.width = v.videoWidth || 0;
    item.height = v.videoHeight || 0;
    item.el = v;
    maybeSetSizeFromMedia(item);
    renderMediaList();
  }catch(err){
    console.warn('Konwersja GIF nieudana, używam statycznego obrazu:', err);
    // fallback: statyczny obraz (pierwsza klatka)
    const img = new Image();
    img.onload = ()=>{ item.duration=5; item.width=img.width; item.height=img.height; item.el=img; item.type='image'; renderMediaList(); };
    img.src = item.url;
  }
}

function importFiles(fileList){
  Array.from(fileList).forEach(file=>{
    const url = URL.createObjectURL(file);
    let type = 'video';
    if(isGifFile(file)) type = 'gif';
    else if(file.type.startsWith('image/')) type = 'image';
    else if(file.type.startsWith('audio/')) type = 'audio';
    else if(file.type.startsWith('video/')) type = 'video';

    const item = { id: uidMedia(), name:file.name, type, file, url, duration:0, el:null, width:0, height:0, isGif: type==='gif' };
    mediaLibrary.push(item);

    if(type==='gif'){
      // najpierw pokaż placeholder, potem skonwertuj w tle
      item.duration = 5;
      const img = new Image();
      img.onload = ()=>{ item.width=img.width; item.height=img.height; item.el=img; renderMediaList(); };
      img.src = url;
      convertGifItem(item);
    } else if(type==='video'){
      const v = document.createElement('video');
      v.src = url; v.preload='metadata'; v.muted=false;
      v.onloadedmetadata = ()=>{
        item.duration = v.duration; item.width=v.videoWidth; item.height=v.videoHeight; item.el=v;
        maybeSetSizeFromMedia(item);
        renderMediaList();
      };
    } else if(type==='audio'){
      const a = document.createElement('audio');
      a.src = url; a.preload='metadata';
      a.onloadedmetadata = ()=>{ item.duration=a.duration; item.el=a; renderMediaList(); };
    } else if(type==='image'){
      const img = new Image();
      img.onload = ()=>{ item.duration=5; item.width=img.width; item.height=img.height; item.el=img; maybeSetSizeFromMedia(item); renderMediaList(); };
      img.src = url;
    }
  });
  renderMediaList();
}

function renderMediaList(){
  if(mediaLibrary.length===0){
    mediaList.innerHTML = '<div class="media-empty">Brak mediów — zaimportuj wideo, zdjęcia, GIF albo muzykę.</div>';
    return;
  }
  mediaList.innerHTML = '';
  mediaLibrary.forEach(item=>{
    const div = document.createElement('div');
    div.className = 'media-item';
    div.draggable = true;
    div.dataset.mediaId = item.id;
    const icon = (item.type==='video' || item.isGif) ? (item.isGif ? '👾' : '🎞️') : item.type==='image' ? '🖼️' : '🎵';
    div.innerHTML = `<div class="thumb">${icon}</div>
      <div class="meta"><div class="name">${escapeHtml(item.name)}</div><div class="dur">${item.duration? fmtTime(item.duration):'...'}</div></div>`;
    div.addEventListener('dragstart', (e)=>{
      e.dataTransfer.setData('text/media-id', item.id);
    });
    div.addEventListener('dblclick', ()=>{
      // szybkie dodanie na koniec pierwszej pasujacej sciezki (lub nowej)
      addClipFromMedia(item, findOrCreateTrackFor(item), null);
    });
    mediaList.appendChild(div);
  });
}

function escapeHtml(s){ return (s||'').replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

document.getElementById('importBtn').onclick = ()=> fileInput.click();
document.getElementById('importTopBtn').onclick = ()=> fileInput.click();
fileInput.addEventListener('change', (e)=>{ if(e.target.files.length) importFiles(e.target.files); fileInput.value=''; });

// drag & drop plikow z systemu na panel biblioteki
const mediaPanel = document.getElementById('mediaPanel');
mediaPanel.addEventListener('dragover', e=>{ e.preventDefault(); });
mediaPanel.addEventListener('drop', e=>{
  e.preventDefault();
  if(e.dataTransfer.files && e.dataTransfer.files.length) importFiles(e.dataTransfer.files);
});

// ---------- ŚCIEŻKI ----------
function addTrack(kind){
  const track = { id: uidTrack(), kind, type: kind==='visual'?'video':'audio-track', clips: [] };
  if(kind==='visual') project.tracks.push(track); // wizualne: na koncu tablicy = na wierzchu kompozycji
  else project.tracks.push(track);
  renderTracks();
  return track;
}

function findOrCreateTrackFor(mediaItem){
  const wantKind = mediaItem.type==='audio' ? 'audio' : 'visual';
  let track = [...project.tracks].reverse().find(t=>t.kind===wantKind);
  if(!track) track = addTrack(wantKind);
  return track;
}

function visualTracks(){ return project.tracks.filter(t=>t.kind==='visual'); }
function audioTracks(){ return project.tracks.filter(t=>t.kind==='audio'); }

// ---------- KLIPY ----------
function addClipFromMedia(mediaItem, track, startTime){
  const dur = mediaItem.duration || 5;
  const start = startTime!==null && startTime!==undefined ? startTime : trackEndTime(track);
  // gif po konwersji staje się video; przed konwersją też traktujemy jak video
  let clipType = mediaItem.type;
  if(clipType === 'gif' || mediaItem.isGif) clipType = 'video';
  const clip = {
    id: uidClip(),
    trackId: track.id,
    mediaId: mediaItem.id,
    type: clipType, // 'video'|'image'|'audio'
    start, duration: clipType==='image' ? 5 : dur,
    sourceIn: 0, sourceOut: dur,
    volume: 100, muted:false, speed:1,
    filters: { brightness:100, contrast:100, saturate:100, hueRotate:0, grayscale:0, sepia:0, invert:0, blur:0 },
    transform: { scale:100, x:50, y:50, rotation:0 }
  };
  track.clips.push(clip);
  if(workspaceSettings.magnetic !== false){
    // CapCut: na pustej ścieżce od razu od 0:00, potem pakuj
    if(track.clips.length === 1) clip.start = 0;
    packTrack(track);
  }
  selectClip(clip.id);
  ensureWholeTimelineVisible();
  renderTracks();
  pushHistory();
  return clip;
}

// Jeśli po dodaniu/wydłużeniu klipu cały montaż nie mieści się już w widoku,
// automatycznie dopasuj przybliżenie tak, żeby zawsze było widać wszystko.
function ensureWholeTimelineVisible(){
  const availWidth = Math.max(100, timelineScroll.clientWidth - 80);
  const neededWidth = projectDuration() * pxPerSec;
  if(neededWidth > availWidth){
    pxPerSec = computeMinZoom();
  }
}

function trackEndTime(track){
  let max = 0;
  track.clips.forEach(c=> max = Math.max(max, c.start+c.duration));
  return max;
}

function getClipById(id){
  for(const tr of project.tracks){
    const c = tr.clips.find(cl=>cl.id===id);
    if(c) return {clip:c, track:tr};
  }
  return null;
}

function getMediaById(id){ return mediaLibrary.find(m=>m.id===id); }

function selectClip(id, addToSelection){
  if(id===null){
    selectedClipId = null; selectedClipIds = new Set();
  } else if(addToSelection){
    selectedClipIds.add(id);
    selectedClipId = id;
  } else {
    selectedClipId = id;
    selectedClipIds = new Set([id]);
  }
  renderTracks();
  renderProps();
}

function selectMultipleClips(ids){
  selectedClipIds = new Set(ids);
  selectedClipId = ids.length ? ids[ids.length-1] : null;
  renderTracks();
  renderProps();
}

function deleteClip(id, skipHistory){
  const found = getClipById(id);
  if(!found) return;
  found.track.clips = found.track.clips.filter(c=>c.id!==id);
  if(selectedClipId===id) selectedClipId = null;
  selectedClipIds.delete(id);
  renderTracks(); renderProps();
  if(!skipHistory) pushHistory();
}

function splitClipAt(id, atTime){
  const found = getClipById(id);
  if(!found) return;
  const { clip, track } = found;
  if(atTime <= clip.start || atTime >= clip.start+clip.duration) return;
  const offsetIntoClip = atTime - clip.start;
  const newClip = JSON.parse(JSON.stringify(clip));
  newClip.id = uidClip();
  newClip.start = atTime;
  newClip.duration = clip.duration - offsetIntoClip;
  newClip.sourceIn = clip.sourceIn + offsetIntoClip;
  clip.duration = offsetIntoClip;
  clip.sourceOut = clip.sourceIn + offsetIntoClip;
  track.clips.push(newClip);
  renderTracks(); pushHistory();
}

// ---------- RENDEROWANIE OSI CZASU ----------
const TRACK_COLORS = {
  video: 'linear-gradient(180deg,#3b5bdb,#2740a0)',
  image: 'linear-gradient(180deg,#2f9e44,#1c6b28)',
  audio: 'linear-gradient(180deg,#e8590c,#a83c0c)',
  text: 'linear-gradient(180deg,#ae3ec9,#7b1fa2)'
};

function renderRuler(){
  const dur = Math.max(5, projectDuration()+2);
  const w = dur*pxPerSec;
  timelineRuler.style.width = w+'px';
  timelineRuler.innerHTML = '';
  const stepSec = pxPerSec<40 ? 5 : pxPerSec<90 ? 2 : 1;
  for(let t=0; t<=dur; t+=stepSec){
    const tick = document.createElement('div');
    tick.style.cssText = `position:absolute; left:${t*pxPerSec+70}px; top:0; height:100%; border-left:1px solid #333a4d; padding-left:3px; font-size:9px; color:#8890a3; display:flex; align-items:center;`;
    tick.textContent = fmtTime(t);
    timelineRuler.appendChild(tick);
  }
  const ph = document.createElement('div');
  ph.id = 'rulerPlayhead';
  ph.style.cssText = `position:absolute; left:${currentTime*pxPerSec+70}px; top:0; bottom:0; width:2px; background:#ff5c7a;`;
  timelineRuler.appendChild(ph);
  timelineRuler.onclick = (e)=>{
    const rect = timelineRuler.getBoundingClientRect();
    const x = e.clientX - rect.left - 70;
    seekTo(Math.max(0, x/pxPerSec));
  };
}

function renderTracks(){
  const dur = Math.max(5, projectDuration()+2);
  const w = dur*pxPerSec;
  tracksContainer.innerHTML = '';
  tracksContainer.style.width = (w+70)+'px';

  // wizualne od gory (ostatnia w tablicy = pierwszy wiersz = na wierzchu kompozycji)
  const vTracks = [...visualTracks()].reverse();
  vTracks.forEach(track=> tracksContainer.appendChild(buildTrackRow(track, w)));
  audioTracks().forEach(track=> tracksContainer.appendChild(buildTrackRow(track, w)));

  const ph = document.createElement('div');
  ph.id = 'playhead';
  ph.style.left = (currentTime*pxPerSec+70)+'px';
  ph.style.height = tracksContainer.scrollHeight+'px';
  tracksContainer.appendChild(ph);

  renderRuler();
}

function buildTrackRow(track, totalWidth){
  const row = document.createElement('div');
  row.className = 'track-row' + (track.kind==='audio' ? ' audio':'');
  row.style.width = totalWidth+'px';
  row.dataset.trackId = track.id;

  const label = document.createElement('div');
  label.className = 'track-label';
  label.textContent = track.kind==='audio' ? '🎵' : '🎞️';
  row.appendChild(label);

  track.clips.forEach(clip=>{
    row.appendChild(buildClipEl(clip));
  });

  row.addEventListener('dragover', e=> e.preventDefault());
  row.addEventListener('drop', e=>{
    e.preventDefault();
    const mediaId = e.dataTransfer.getData('text/media-id');
    if(!mediaId) return;
    const media = getMediaById(mediaId);
    if(!media) return;
    const isAudioTrack = track.kind==='audio';
    if(isAudioTrack && media.type!=='audio') return;
    if(!isAudioTrack && media.type==='audio') return;
    const rect = row.getBoundingClientRect();
    const x = e.clientX - rect.left - 70;
    addClipFromMedia(media, track, Math.max(0, x/pxPerSec));
  });

  return row;
}

function buildClipEl(clip){
  const media = getMediaById(clip.mediaId);
  const label = clip.type==='text' ? ('🔤 '+(clip.text||'').slice(0,20)) : (media? media.name : '');
  const el = document.createElement('div');
  el.className = `clip type-${clip.type}` + (selectedClipIds.has(clip.id) ? ' selected':'');
  el.style.left = (clip.start*pxPerSec+70)+'px';
  el.style.width = Math.max(6, clip.duration*pxPerSec)+'px';
  el.dataset.clipId = clip.id;
  el.innerHTML = `<div class="clip-label">${escapeHtml(label)}</div>
    <div class="trim-handle left"></div><div class="trim-handle right"></div>`;

  el.addEventListener('pointerdown', (e)=>{
    if(e.target.classList.contains('trim-handle')) return; // obsluga osobno
    e.stopPropagation();
    if(!(selectedClipIds.size>1 && selectedClipIds.has(clip.id))){
      selectClip(clip.id);
    }
    startClipDrag(e, clip);
  });
  el.querySelector('.trim-handle.left').addEventListener('pointerdown', (e)=>{
    e.stopPropagation(); selectClip(clip.id); startClipTrim(e, clip, 'left');
  });
  el.querySelector('.trim-handle.right').addEventListener('pointerdown', (e)=>{
    e.stopPropagation(); selectClip(clip.id); startClipTrim(e, clip, 'right');
  });
  return el;
}

// ---------- PRZECIĄGANIE / PRZYCINANIE KLIPÓW ----------
let dragState = null; // {mode:'move'|'trim-left'|'trim-right', clip, startX, origStart, origDur, origIn, origOut}

function startClipDrag(e, clip){
  const isGroup = selectedClipIds.size>1 && selectedClipIds.has(clip.id);
  const groupClips = isGroup ? [...selectedClipIds].map(id=>getClipById(id)).filter(Boolean).map(f=>f.clip) : null;
  dragState = {
    mode:'move', clip, startX:e.clientX, origStart:clip.start,
    groupClips, groupOrigStarts: groupClips ? groupClips.map(c=>c.start) : null
  };
  window.addEventListener('pointermove', onClipDragMove);
  window.addEventListener('pointerup', onClipDragEnd);
}
function startClipTrim(e, clip, side){
  dragState = { mode: side==='left'?'trim-left':'trim-right', clip, startX:e.clientX,
    origStart:clip.start, origDur:clip.duration, origIn:clip.sourceIn, origOut:clip.sourceOut };
  window.addEventListener('pointermove', onClipDragMove);
  window.addEventListener('pointerup', onClipDragEnd);
}

function onClipDragMove(e){
  if(!dragState) return;
  const dx = e.clientX - dragState.startX;
  const dt = dx / pxPerSec;
  const clip = dragState.clip;
  const media = getMediaById(clip.mediaId);
  const maxDur = media ? (media.type==='image' ? 3600 : media.duration) : 3600;

  if(dragState.mode==='move'){
    let newStart = Math.max(0, dragState.origStart + dt);
    // snapowanie: probujemy dopasowac zarowno poczatek jak i koniec klipu do punktow snap
    const snappedStart = snapTime(newStart, clip.id);
    const snappedEnd = snapTime(newStart+clip.duration, clip.id) - clip.duration;
    if(Math.abs(snappedStart-newStart) <= Math.abs(snappedEnd-newStart)) newStart = snappedStart;
    else newStart = snappedEnd;
    newStart = Math.max(0, newStart);
    if(dragState.groupClips){
      const delta = newStart - dragState.origStart;
      dragState.groupClips.forEach((c,i)=>{
        c.start = Math.max(0, dragState.groupOrigStarts[i] + delta);
      });
    } else {
      clip.start = newStart;
    }
  } else if(dragState.mode==='trim-left'){
    const speed = clip.speed || 1;
    let newStart = dragState.origStart + dt;
    newStart = snapTime(Math.max(0,newStart), clip.id);
    const delta = newStart - dragState.origStart;
    let newIn = dragState.origIn + delta*speed;
    newIn = Math.max(0, newIn);
    const newDur = dragState.origDur - delta;
    if(newDur > 0.1 && newIn >= 0){
      clip.start = newStart; clip.sourceIn = newIn; clip.duration = newDur;
    }
  } else if(dragState.mode==='trim-right'){
    const speed = clip.speed || 1;
    let newEnd = dragState.origStart + dragState.origDur + dt;
    newEnd = snapTime(newEnd, clip.id);
    let newDur = newEnd - dragState.origStart;
    let newOut = dragState.origOut + (newDur - dragState.origDur)*speed;
    if(newDur > 0.1 && newOut <= maxDur+0.001){
      clip.duration = newDur; clip.sourceOut = newOut;
    }
  }
  renderTracks();
}
function onClipDragEnd(){
  window.removeEventListener('pointermove', onClipDragMove);
  window.removeEventListener('pointerup', onClipDragEnd);
  if(dragState){
    if(workspaceSettings.magnetic !== false && dragState.clip){
      const found = getClipById(dragState.clip.id);
      if(found) packTrack(found.track);
    }
    ensureWholeTimelineVisible(); renderTracks(); pushHistory();
  }
  dragState = null;
}

// ---------- ODTWARZANIE / PODGLĄD ----------
function seekTo(t){
  currentTime = Math.max(0, Math.min(t, projectDuration()));
  renderRuler();
  const ph = document.getElementById('playhead');
  if(ph) ph.style.left = (currentTime*pxPerSec+70)+'px';
  renderFrame(currentTime);
  updateTimeDisplay();
}

function updateTimeDisplay(){
  timeDisplay.textContent = `${fmtTime(currentTime)} / ${fmtTime(projectDuration())}`;
}

function renderFrame(t){
  pctx.fillStyle = '#000';
  pctx.fillRect(0,0,previewCanvas.width, previewCanvas.height);
  visualTracks().forEach(track=>{
    const active = activeClipsOnTrack(track, t);
    if(active.length===0) return;
    if(active.length===1){
      drawVisualClip(active[0], t, 1);
    } else {
      // dwa nakladajace sie klipy = przenikanie (crossfade)
      const [a,b] = active; // a zaczal sie wczesniej
      const overlapStart = b.start;
      const overlapEnd = a.start+a.duration;
      const overlapDur = Math.max(0.001, overlapEnd-overlapStart);
      const progress = Math.max(0, Math.min(1, (t-overlapStart)/overlapDur));
      drawVisualClip(a, t, 1-progress);
      drawVisualClip(b, t, progress);
    }
  });
}

function drawVisualClip(clip, t, alpha){
  pctx.save();
  pctx.globalAlpha = Math.max(0, Math.min(1, alpha));
  if(clip.type==='text'){
    drawTextClip(clip, t);
    pctx.restore();
    return;
  }
  const media = getMediaById(clip.mediaId);
  if(!media || !media.el){ pctx.restore(); return; }
  const speed = clip.speed || 1;
  const srcTime = clip.sourceIn + (t - clip.start) * speed;
  const f = clip.filters || DEFAULT_FILTERS;
  pctx.filter = buildFilterString(f);
  if(media.type==='video'){
    if(Math.abs(media.el.currentTime - srcTime) > 0.25 && !isPlaying){
      try{ media.el.currentTime = srcTime; }catch(e){}
    }
    drawTransformed(pctx, media.el, media.width, media.height, clip.transform);
  } else if(media.type==='image'){
    drawTransformed(pctx, media.el, media.width, media.height, clip.transform);
  }
  pctx.restore();
}

const DEFAULT_FILTERS = { brightness:100, contrast:100, saturate:100, hueRotate:0, grayscale:0, sepia:0, invert:0, blur:0 };
function buildFilterString(f){
  f = f || DEFAULT_FILTERS;
  return `brightness(${f.brightness!==undefined?f.brightness:100}%) contrast(${f.contrast!==undefined?f.contrast:100}%) saturate(${f.saturate!==undefined?f.saturate:100}%) hue-rotate(${f.hueRotate||0}deg) grayscale(${f.grayscale||0}%) sepia(${f.sepia||0}%) invert(${f.invert||0}%) blur(${f.blur||0}px)`;
}

const DEFAULT_TRANSFORM = { scale:100, x:50, y:50, rotation:0 };
// Rysuje obraz/wideo z uwzglednieniem skali "widocznosci" (100% = normalny widok
// wypelniajacy kadr, 1% = 100x mniejszy, 1000% = 10x wiekszy), pozycji i rotacji.
function drawTransformed(c, el, iw, ih, transform){
  const cw = previewCanvas.width, ch = previewCanvas.height;
  const tr = transform || DEFAULT_TRANSFORM;
  const baseScale = Math.max(cw/iw, ch/ih); // bazowe "cover" wypelnienie kadru
  const finalScale = baseScale * ((tr.scale!==undefined?tr.scale:100)/100);
  const dw = iw*finalScale, dh = ih*finalScale;
  const cx = cw*((tr.x!==undefined?tr.x:50)/100);
  const cy = ch*((tr.y!==undefined?tr.y:50)/100);
  c.save();
  c.translate(cx, cy);
  if(tr.rotation) c.rotate(tr.rotation*Math.PI/180);
  c.drawImage(el, -dw/2, -dh/2, dw, dh);
  c.restore();
}

function drawTextClip(clip, t){
  const w = previewCanvas.width, h = previewCanvas.height;
  const cssFont = txtFontCss(clip.fontFamily||'Anton');
  const styleParts = [];
  if(clip.italic) styleParts.push('italic');
  if(clip.bold) styleParts.push('bold');
  pctx.font = `${styleParts.join(' ')} ${clip.fontSize||64}px ${cssFont}`.trim();
  pctx.textAlign = clip.align||'center';
  pctx.textBaseline = 'middle';

  // plynne pojawianie/znikanie (fade in/out) na podstawie pozycji w czasie klipu
  let fadeAlpha = 1;
  const localElapsed = t - clip.start;
  const localRemaining = (clip.start+clip.duration) - t;
  const fadeIn = clip.fadeIn||0, fadeOut = clip.fadeOut||0;
  if(fadeIn>0 && localElapsed < fadeIn) fadeAlpha *= Math.max(0, localElapsed/fadeIn);
  if(fadeOut>0 && localRemaining < fadeOut) fadeAlpha *= Math.max(0, localRemaining/fadeOut);
  pctx.globalAlpha *= Math.max(0, Math.min(1, fadeAlpha)) * ((clip.opacity!==undefined?clip.opacity:100)/100);

  const x = w*((clip.x!==undefined?clip.x:50)/100);
  const y0 = h*((clip.y!==undefined?clip.y:85)/100);

  // animacja wejscia (pierwsze 0.35s trwania klipu)
  const animDur = 0.35;
  const animProgress = Math.max(0, Math.min(1, localElapsed/animDur));
  let animScale = 1, animYOffset = 0, animXOffset = 0;
  if(clip.animation==='pop' || clip.animation==='zoomin') animScale = 0.5 + 0.5*animProgress;
  if(clip.animation==='slideup') animYOffset = (1-animProgress)*40;
  if(clip.animation==='shake' && animProgress < 1){
    animXOffset = (Math.random()-0.5)*10;
    animYOffset = (Math.random()-0.5)*8;
  }
  if(clip.animation==='fadein'){
    pctx.globalAlpha *= animProgress;
  }

  pctx.save();
  pctx.translate(x+animXOffset, y0+animYOffset);
  pctx.scale(animScale, animScale);
  pctx.translate(-(x+animXOffset), -(y0+animYOffset));
  const y = y0+animYOffset;
  const lines = (clip.text||'').split('\n');
  const lineH = (clip.fontSize||64)*1.2;
  const startY = y - (lineH*(lines.length-1))/2;

  if(clip.bgEnabled){
    let maxW = 0;
    lines.forEach(line=>{ maxW = Math.max(maxW, pctx.measureText(line).width); });
    const pad = clip.bgPadding!==undefined ? clip.bgPadding : 16;
    const boxW = maxW + pad*2;
    const boxH = lineH*lines.length + pad*1.2;
    let boxX = x - boxW/2;
    if(clip.align==='left') boxX = x - pad;
    if(clip.align==='right') boxX = x - boxW + pad;
    const boxY = startY - lineH/2 - pad*0.6;
    pctx.save();
    pctx.globalAlpha *= (clip.bgOpacity!==undefined?clip.bgOpacity:80)/100;
    pctx.fillStyle = clip.bgColor||'#000000';
    const r = 10;
    pctx.beginPath();
    pctx.moveTo(boxX+r, boxY);
    pctx.arcTo(boxX+boxW, boxY, boxX+boxW, boxY+boxH, r);
    pctx.arcTo(boxX+boxW, boxY+boxH, boxX, boxY+boxH, r);
    pctx.arcTo(boxX, boxY+boxH, boxX, boxY, r);
    pctx.arcTo(boxX, boxY, boxX+boxW, boxY, r);
    pctx.closePath();
    pctx.fill();
    pctx.restore();
  }

  const hasKaraokeWords = clip.karaoke && Array.isArray(clip.words) && clip.words.length>0;

  if(hasKaraokeWords){
    clip.words.forEach((lineWords, i)=>{
      const ly = startY + i*lineH;
      const spaceW = pctx.measureText(' ').width;
      let totalW = 0;
      lineWords.forEach((wd,idx)=>{ totalW += pctx.measureText(wd.text).width; if(idx<lineWords.length-1) totalW += spaceW; });
      let startX;
      if(clip.align==='left') startX = x;
      else if(clip.align==='right') startX = x - totalW;
      else startX = x - totalW/2;
      const prevAlign = pctx.textAlign;
      pctx.textAlign = 'left';
      let cx = startX;
      lineWords.forEach((wd,idx)=>{
        const active = t >= wd.start && t <= wd.end;
        if(clip.strokeWidth>0){
          pctx.lineWidth = clip.strokeWidth;
          pctx.strokeStyle = clip.strokeColor||'#000000';
          pctx.lineJoin = 'round';
          pctx.strokeText(wd.text, cx, ly);
        }
        pctx.fillStyle = active ? (clip.highlightColor||'#ffd400') : (clip.color||'#ffffff');
        pctx.fillText(wd.text, cx, ly);
        cx += pctx.measureText(wd.text).width;
        if(idx<lineWords.length-1) cx += spaceW;
      });
      pctx.textAlign = prevAlign;
    });
  } else {
    lines.forEach((line,i)=>{
      const ly = startY + i*lineH;
      if(clip.strokeWidth>0){
        pctx.lineWidth = clip.strokeWidth;
        pctx.strokeStyle = clip.strokeColor||'#000000';
        pctx.lineJoin = 'round';
        pctx.strokeText(line, x, ly);
      }
      pctx.fillStyle = clip.color||'#ffffff';
      pctx.fillText(line, x, ly);
    });
  }
  pctx.restore();
}

// ---------- PĘTLA ODTWARZANIA ----------
let lastFrameTs = 0;
let rafId = null;

function play(){
  if(isPlaying) return;
  if(currentTime >= projectDuration()) currentTime = 0;
  isPlaying = true;
  lastFrameTs = performance.now();
  document.getElementById('playPauseBtn').textContent = '⏸';
  rafId = requestAnimationFrame(playbackTick);
}
function pause(){
  isPlaying = false;
  document.getElementById('playPauseBtn').textContent = '▶️';
  if(rafId) cancelAnimationFrame(rafId);
  mediaLibrary.forEach(m=>{ if(m.el && m.el.pause) m.el.pause(); });
}
function togglePlay(){ isPlaying ? pause() : play(); }

let _playheadAcc = 0;
function playbackTick(ts){
  if(!isPlaying) return;
  const dt = (ts - lastFrameTs)/1000;
  lastFrameTs = ts;
  currentTime += dt;
  const dur = projectDuration();
  if(currentTime >= dur){
    currentTime = dur;
    pause();
    renderFrame(currentTime);
    updateTimeDisplayAndPlayhead();
    return;
  }
  syncMediaPlayback(currentTime);
  renderFrame(currentTime);
  // rzadziej aktualizuj DOM playheada (co ~50ms) — mniej layout thrashing
  _playheadAcc += dt;
  if(_playheadAcc >= 0.05){
    _playheadAcc = 0;
    updateTimeDisplayAndPlayhead();
  }
  rafId = requestAnimationFrame(playbackTick);
}

function updateTimeDisplayAndPlayhead(){
  updateTimeDisplay();
  const ph = document.getElementById('playhead');
  if(ph) ph.style.left = (currentTime*pxPerSec+70)+'px';
  const rph = document.getElementById('rulerPlayhead');
  if(rph) rph.style.left = (currentTime*pxPerSec+70)+'px';
}

function syncMediaPlayback(t){
  const activeMediaIds = new Set();
  [...visualTracks(), ...audioTracks()].forEach(track=>{
    const clips = activeClipsOnTrack(track, t);
    let fadeMul = {};
    if(clips.length===2){
      const [a,b] = clips;
      const overlapStart = b.start, overlapEnd = a.start+a.duration;
      const overlapDur = Math.max(0.001, overlapEnd-overlapStart);
      const progress = Math.max(0, Math.min(1, (t-overlapStart)/overlapDur));
      fadeMul[a.id] = 1-progress; fadeMul[b.id] = progress;
    }
    clips.forEach(clip=>{
      if(clip.type==='text') return;
      const media = getMediaById(clip.mediaId);
      if(!media || !media.el) return;
      if(media.type==='image') return;
      activeMediaIds.add(media.id);
      const speed = clip.speed || 1;
      const srcTime = clip.sourceIn + (t - clip.start) * speed;
      const mul = fadeMul[clip.id]!==undefined ? fadeMul[clip.id] : 1;
      const muted = !!clip.muted;
      media.el.volume = muted ? 0 : Math.max(0, Math.min(1,(clip.volume!==undefined?clip.volume:100)/100 * mul));
      if(media.el.playbackRate !== speed) media.el.playbackRate = speed;
      // większy próg seeku = mniej lagów przy odtwarzaniu
      if(media.el.paused){
        try{ media.el.currentTime = srcTime; }catch(e){}
        media.el.play().catch(()=>{});
      } else if(Math.abs(media.el.currentTime - srcTime) > 0.35){
        try{ media.el.currentTime = srcTime; }catch(e){}
      }
    });
  });
  // zatrzymaj media ktore nie sa juz aktywne
  mediaLibrary.forEach(m=>{
    if(m.el && m.type!=='image' && !activeMediaIds.has(m.id) && !m.el.paused){
      m.el.pause();
    }
  });
}

document.getElementById('playPauseBtn').onclick = togglePlay;
document.getElementById('skipBackBtn').onclick = ()=> seekTo(currentTime-1);
document.getElementById('skipFwdBtn').onclick = ()=> seekTo(currentTime+1);

// ---------- PRZECIĄGANIE TEKSTU NA PODGLĄDZIE ----------
let previewDrag = null; // {clipId, startX, startY, origX, origY}
function canvasToPercent(clientX, clientY){
  const rect = previewCanvas.getBoundingClientRect();
  const x = ((clientX - rect.left) / rect.width) * 100;
  const y = ((clientY - rect.top) / rect.height) * 100;
  return { x: Math.max(0, Math.min(100, x)), y: Math.max(0, Math.min(100, y)) };
}
function hitTestTextClip(clientX, clientY){
  // od góry (ostatnie ścieżki wizualne = na wierzchu)
  const tracks = visualTracks().slice().reverse();
  for(const track of tracks){
    const clips = activeClipsOnTrack(track, currentTime).slice().reverse();
    for(const clip of clips){
      if(clip.type !== 'text') continue;
      const cx = clip.x !== undefined ? clip.x : 50;
      const cy = clip.y !== undefined ? clip.y : 88;
      const rect = previewCanvas.getBoundingClientRect();
      const px = ((clientX - rect.left) / rect.width) * 100;
      const py = ((clientY - rect.top) / rect.height) * 100;
      // prosty hitbox wokół pozycji tekstu
      if(Math.abs(px - cx) < 18 && Math.abs(py - cy) < 12) return clip;
    }
  }
  return null;
}
previewCanvas.addEventListener('pointerdown', (e)=>{
  if(e.button !== 0) return;
  const clip = hitTestTextClip(e.clientX, e.clientY);
  if(!clip) return;
  e.preventDefault();
  selectClip(clip.id);
  previewDrag = {
    clipId: clip.id,
    startX: e.clientX, startY: e.clientY,
    origX: clip.x !== undefined ? clip.x : 50,
    origY: clip.y !== undefined ? clip.y : 88
  };
  previewCanvas.classList.add('dragging-text');
  previewCanvas.setPointerCapture(e.pointerId);
});
previewCanvas.addEventListener('pointermove', (e)=>{
  if(!previewDrag){
    const hit = hitTestTextClip(e.clientX, e.clientY);
    previewCanvas.classList.toggle('can-drag-text', !!hit);
    return;
  }
  const rect = previewCanvas.getBoundingClientRect();
  const dx = ((e.clientX - previewDrag.startX) / rect.width) * 100;
  const dy = ((e.clientY - previewDrag.startY) / rect.height) * 100;
  const found = getClipById(previewDrag.clipId);
  if(!found) return;
  found.clip.x = Math.max(0, Math.min(100, previewDrag.origX + dx));
  found.clip.y = Math.max(0, Math.min(100, previewDrag.origY + dy));
  renderFrame(currentTime);
  // odśwież suwaki pozycji jeśli otwarte
  const px = document.getElementById('propX'), py = document.getElementById('propY');
  if(px){ px.value = found.clip.x; }
  if(py){ py.value = found.clip.y; }
});
previewCanvas.addEventListener('pointerup', (e)=>{
  if(!previewDrag) return;
  previewDrag = null;
  previewCanvas.classList.remove('dragging-text');
  renderProps();
  pushHistory();
});
window.addEventListener('keydown', (e)=>{
  const tag=(e.target.tagName||'').toLowerCase();
  if(tag==='input'||tag==='textarea') return;
  if(e.code==='Space'){ e.preventDefault(); togglePlay(); }
  if(e.key==='Delete' && selectedClipIds.size>0){
    [...selectedClipIds].forEach(id=> deleteClip(id, true));
    selectClip(null);
    pushHistory();
  }
});

// ---------- PANEL WŁAŚCIWOŚCI ----------
function renderProps(){
  if(selectedClipIds.size > 1){
    const clips = [...selectedClipIds].map(id=>getClipById(id)).filter(Boolean).map(f=>f.clip);
    const textClips = clips.filter(c=>c.type==='text');
    const allText = textClips.length === clips.length && textClips.length>0;
    let bulkHtml = `
      <p style="color:var(--text-dim); font-size:12px; margin-bottom:12px;">Zaznaczono <b style="color:var(--text);">${selectedClipIds.size}</b> klipów${allText?` (tekst: ${textClips.length})`:''}.</p>
      <div class="row">
        <button id="bulkDeleteBtn" class="chip" style="flex:1; color:var(--danger);">🗑️ Usuń wszystkie</button>
        <button id="bulkDuplicateBtn" class="chip" style="flex:1;">⧉ Duplikuj wszystkie</button>
      </div>`;
    if(textClips.length){
      const sample = textClips[0];
      bulkHtml += `
      <h3 style="margin-top:14px;">Masowa edycja tekstu (${textClips.length})</h3>
      <div class="field"><label>Rozmiar <span id="bulkSizeLbl">${sample.fontSize||48}px</span></label>
        <input type="range" id="bulkFontSize" min="12" max="200" value="${sample.fontSize||48}"></div>
      <div class="row">
        <div class="field"><label>Kolor</label><input type="color" id="bulkColor" value="${sample.color||'#ffffff'}"></div>
        <div class="field"><label>Obrys</label><input type="color" id="bulkStroke" value="${sample.strokeColor||'#000000'}"></div>
      </div>
      <div class="field"><label>Grubość obrysu <span id="bulkSwLbl">${sample.strokeWidth||6}</span></label>
        <input type="range" id="bulkStrokeW" min="0" max="20" value="${sample.strokeWidth||6}"></div>
      <div class="field"><label>Pozycja X <span id="bulkXLbl">${sample.x!==undefined?sample.x:50}%</span></label>
        <input type="range" id="bulkX" min="0" max="100" value="${sample.x!==undefined?sample.x:50}"></div>
      <div class="field"><label>Pozycja Y <span id="bulkYLbl">${sample.y!==undefined?sample.y:88}%</span></label>
        <input type="range" id="bulkY" min="0" max="100" value="${sample.y!==undefined?sample.y:88}"></div>
      <div class="field"><label>Czcionka</label>
        <select id="bulkFont">
          ${[...TXT_FONTS_EMBEDDED.slice(0,20), ...TXT_FONTS_SYSTEM.slice(0,15)].map(f=>{
            const css=txtFontCss(f);
            return `<option value='${css}' ${sample.fontFamily===css?'selected':''}>${f}</option>`;
          }).join('')}
        </select>
      </div>
      <div class="chip-row" style="margin-top:8px;">
        <button class="chip" id="bulkBold">Pogrubienie</button>
        <button class="chip" id="bulkCenter">Wyśrodkuj</button>
      </div>`;
    }
    bulkHtml += `<p class="hint" style="margin-top:10px;">💡 Przeciągnij dowolny zaznaczony klip, żeby przesunąć całą grupę.</p>`;
    propsContent.innerHTML = bulkHtml;
    document.getElementById('bulkDeleteBtn').onclick = ()=>{
      [...selectedClipIds].forEach(id=> deleteClip(id, true));
      selectClip(null);
      pushHistory();
    };
    document.getElementById('bulkDuplicateBtn').onclick = ()=>{
      [...selectedClipIds].forEach(id=> duplicateClip(id, true));
      pushHistory();
    };
    const applyText = (fn)=>{
      textClips.forEach(fn);
      renderFrame(currentTime);
    };
    const bfs = document.getElementById('bulkFontSize');
    if(bfs){
      bfs.oninput = e=>{ const v=+e.target.value; document.getElementById('bulkSizeLbl').textContent=v+'px'; applyText(c=>c.fontSize=v); };
      bfs.onchange = ()=>pushHistory();
    }
    const bc = document.getElementById('bulkColor');
    if(bc){ bc.oninput=e=>applyText(c=>c.color=e.target.value); bc.onchange=()=>pushHistory(); }
    const bs = document.getElementById('bulkStroke');
    if(bs){ bs.oninput=e=>applyText(c=>c.strokeColor=e.target.value); bs.onchange=()=>pushHistory(); }
    const bsw = document.getElementById('bulkStrokeW');
    if(bsw){
      bsw.oninput=e=>{ const v=+e.target.value; document.getElementById('bulkSwLbl').textContent=v; applyText(c=>c.strokeWidth=v); };
      bsw.onchange=()=>pushHistory();
    }
    const bx = document.getElementById('bulkX');
    if(bx){
      bx.oninput=e=>{ const v=+e.target.value; document.getElementById('bulkXLbl').textContent=v+'%'; applyText(c=>c.x=v); };
      bx.onchange=()=>pushHistory();
    }
    const by = document.getElementById('bulkY');
    if(by){
      by.oninput=e=>{ const v=+e.target.value; document.getElementById('bulkYLbl').textContent=v+'%'; applyText(c=>c.y=v); };
      by.onchange=()=>pushHistory();
    }
    const bf = document.getElementById('bulkFont');
    if(bf){ bf.onchange=e=>{ applyText(c=>c.fontFamily=e.target.value); pushHistory(); }; }
    const bb = document.getElementById('bulkBold');
    if(bb){ bb.onclick=()=>{ applyText(c=>c.bold=!c.bold); pushHistory(); }; }
    const bctr = document.getElementById('bulkCenter');
    if(bctr){ bctr.onclick=()=>{ applyText(c=>{ c.x=50; c.align='center'; }); pushHistory(); renderProps(); }; }
    return;
  }

  const found = selectedClipId ? getClipById(selectedClipId) : null;
  if(!found){
    propsContent.innerHTML = '<p class="props-empty">Kliknij klip na osi czasu, żeby go edytować. Przeciągnij po pustym miejscu, żeby zaznaczyć wiele naraz.</p>';
    return;
  }
  const { clip } = found;

  if(clip.type==='text'){
    renderTextProps(clip);
    return;
  }

  if(!clip.filters) clip.filters = {...DEFAULT_FILTERS};
  if(!clip.transform) clip.transform = {...DEFAULT_TRANSFORM};
  if(clip.speed===undefined) clip.speed = 1;
  if(clip.muted===undefined) clip.muted = false;

  const media = getMediaById(clip.mediaId);
  const f = clip.filters;
  const tr = clip.transform;
  let html = `<div class="field"><label>Plik</label><div style="font-size:12px; color:var(--text-dim);">${media?escapeHtml(media.name):''}</div></div>`;
  html += `<div class="field"><label>Start na osi <span>${clip.start.toFixed(2)}s</span></label><input type="range" id="propStart" min="0" max="${Math.max(30,projectDuration())}" step="0.05" value="${clip.start}"></div>`;
  html += `<div class="field"><label>Długość <span>${clip.duration.toFixed(2)}s</span></label><input type="range" id="propDur" min="0.1" max="${media?(media.type==='image'?60:media.duration*4):60}" step="0.05" value="${clip.duration}"></div>`;
  if(clip.type!=='image'){
    html += `<div class="row">
      <div class="field"><label>Głośność <span>${clip.volume}%</span></label><input type="range" id="propVolume" min="0" max="100" value="${clip.volume}"></div>
      <div class="field" style="flex:0 0 auto; display:flex; align-items:flex-end; padding-bottom:8px;">
        <label style="display:flex; align-items:center; gap:5px;"><input type="checkbox" id="propMuted" ${clip.muted?'checked':''}> Wycisz</label>
      </div>
    </div>`;
    html += `<div class="field"><label>Prędkość odtwarzania <span>${clip.speed}x</span></label><input type="range" id="propSpeed" min="0.25" max="4" step="0.05" value="${clip.speed}"></div>`;
  }

  html += `<h3 style="margin-top:14px;">Widoczność / skala obrazu</h3>`;
  html += `<div class="field"><label>Skala <span>${tr.scale}%</span> <span style="color:var(--text-dim);">(100% = normalny widok, 1% = 100x mniejszy, 1000% = 10x większy)</span></label><input type="range" id="propScale" min="1" max="1000" value="${tr.scale}"></div>`;
  html += `<div class="row">
    <div class="field"><label>Pozycja X <span>${tr.x}%</span></label><input type="range" id="propTX" min="-50" max="150" value="${tr.x}"></div>
    <div class="field"><label>Pozycja Y <span>${tr.y}%</span></label><input type="range" id="propTY" min="-50" max="150" value="${tr.y}"></div>
  </div>`;
  html += `<div class="field"><label>Obrót <span>${tr.rotation}°</span></label><input type="range" id="propRotation" min="-180" max="180" value="${tr.rotation}"></div>`;
  html += `<button id="propResetTransform" class="chip" style="width:100%; margin-bottom:6px;">↺ Zresetuj widoczność (100%, środek)</button>`;

  if(clip.type==='video' || clip.type==='image'){
    html += `<h3 style="margin-top:14px;">Filtry / efekty</h3>`;
    html += `<div class="chip-row" style="margin-bottom:10px;">
      <button class="chip" data-fpreset="naturalny">Naturalny</button>
      <button class="chip" data-fpreset="zywe">Żywe kolory</button>
      <button class="chip" data-fpreset="czb">Czarno-białe</button>
      <button class="chip" data-fpreset="cieple">Ciepłe</button>
      <button class="chip" data-fpreset="chlodne">Chłodne</button>
      <button class="chip" data-fpreset="vhs">Retro VHS</button>
      <button class="chip" data-fpreset="sepia">Sepia</button>
      <button class="chip" data-fpreset="negatyw">Negatyw</button>
      <button class="chip" data-fpreset="cyberpunk">Cyberpunk</button>
      <button class="chip" data-fpreset="mroczny">Mroczny kinowy</button>
      <button class="chip" data-fpreset="marzycielski">Marzycielski</button>
      <button class="chip" data-fpreset="starekino">Stare kino</button>
    </div>`;
    html += `<div class="field"><label>Jasność <span>${f.brightness}%</span></label><input type="range" id="propBrightness" min="0" max="200" value="${f.brightness}"></div>`;
    html += `<div class="field"><label>Kontrast <span>${f.contrast}%</span></label><input type="range" id="propContrast" min="0" max="200" value="${f.contrast}"></div>`;
    html += `<div class="field"><label>Nasycenie <span>${f.saturate}%</span></label><input type="range" id="propSaturate" min="0" max="200" value="${f.saturate}"></div>`;
    html += `<div class="field"><label>Obrót odcienia <span>${f.hueRotate}°</span></label><input type="range" id="propHue" min="0" max="360" value="${f.hueRotate}"></div>`;
    html += `<div class="field"><label>Czarno-białe <span>${f.grayscale}%</span></label><input type="range" id="propGrayscale" min="0" max="100" value="${f.grayscale}"></div>`;
    html += `<div class="field"><label>Sepia <span>${f.sepia}%</span></label><input type="range" id="propSepia" min="0" max="100" value="${f.sepia}"></div>`;
    html += `<div class="field"><label>Negatyw <span>${f.invert}%</span></label><input type="range" id="propInvert" min="0" max="100" value="${f.invert}"></div>`;
    html += `<div class="field"><label>Rozmycie <span>${f.blur}px</span></label><input type="range" id="propBlur" min="0" max="20" step="0.5" value="${f.blur}"></div>`;
    html += `<p class="hint" style="color:var(--text-dim); font-size:11px;">💡 Nachodzące na siebie klipy na tej samej ścieżce (przeciągnij jeden na drugi) automatycznie tworzą przenikanie (crossfade).</p>`;
  }
  html += `<div class="row" style="margin-top:10px;">
    <button id="propDuplicateBtn" class="chip" style="flex:1;">⧉ Duplikuj</button>
    <button id="propDeleteBtn" class="chip" style="flex:1; color:var(--danger);">🗑️ Usuń</button>
  </div>
  <button id="propRippleDeleteBtn" class="chip" style="width:100%; margin-top:6px;" title="Usuwa klip i zsuwa kolejne, żeby zamknąć lukę">🌊 Usuń i zsuń</button>`;
  propsContent.innerHTML = html;

  const upd = fn=>{ fn(); renderTracks(); renderFrame(currentTime); };
  const ps = document.getElementById('propStart'), pd = document.getElementById('propDur'), pv = document.getElementById('propVolume');
  if(ps){ ps.oninput=e=>upd(()=>clip.start=+e.target.value); ps.onchange=()=>{renderProps();pushHistory();}; }
  if(pd){ pd.oninput=e=>upd(()=>clip.duration=+e.target.value); pd.onchange=()=>{renderProps();pushHistory();}; }
  if(pv){ pv.oninput=e=>upd(()=>clip.volume=+e.target.value); pv.onchange=()=>{renderProps();pushHistory();}; }
  const pmuted = document.getElementById('propMuted');
  if(pmuted) pmuted.onchange = e=>{ clip.muted=e.target.checked; pushHistory(); };
  const pspeed = document.getElementById('propSpeed');
  if(pspeed){
    pspeed.oninput = e=>{
      const newSpeed = +e.target.value;
      const sourceSpan = clip.duration*(clip.speed||1); // ile materialu zrodlowego obejmuje klip
      clip.speed = newSpeed;
      clip.duration = Math.max(0.1, sourceSpan/newSpeed);
      renderTracks(); renderFrame(currentTime);
    };
    pspeed.onchange = ()=>{ renderProps(); pushHistory(); };
  }

  const pscale = document.getElementById('propScale'), ptx = document.getElementById('propTX'), pty = document.getElementById('propTY'), prot = document.getElementById('propRotation');
  pscale.oninput=e=>upd(()=>tr.scale=+e.target.value); pscale.onchange=()=>{renderProps();pushHistory();};
  ptx.oninput=e=>upd(()=>tr.x=+e.target.value); ptx.onchange=()=>{renderProps();pushHistory();};
  pty.oninput=e=>upd(()=>tr.y=+e.target.value); pty.onchange=()=>{renderProps();pushHistory();};
  prot.oninput=e=>upd(()=>tr.rotation=+e.target.value); prot.onchange=()=>{renderProps();pushHistory();};
  document.getElementById('propResetTransform').onclick = ()=>{
    clip.transform = {...DEFAULT_TRANSFORM};
    renderProps(); renderFrame(currentTime); pushHistory();
  };

  const pb = document.getElementById('propBrightness'), pc = document.getElementById('propContrast'), psat = document.getElementById('propSaturate');
  if(pb){ pb.oninput=e=>upd(()=>clip.filters.brightness=+e.target.value); pb.onchange=()=>{renderProps();pushHistory();}; }
  if(pc){ pc.oninput=e=>upd(()=>clip.filters.contrast=+e.target.value); pc.onchange=()=>{renderProps();pushHistory();}; }
  if(psat){ psat.oninput=e=>upd(()=>clip.filters.saturate=+e.target.value); psat.onchange=()=>{renderProps();pushHistory();}; }
  const phue = document.getElementById('propHue'), pgray = document.getElementById('propGrayscale'), psep = document.getElementById('propSepia'), pinv = document.getElementById('propInvert'), pblur = document.getElementById('propBlur');
  if(phue){ phue.oninput=e=>upd(()=>clip.filters.hueRotate=+e.target.value); phue.onchange=()=>{renderProps();pushHistory();}; }
  if(pgray){ pgray.oninput=e=>upd(()=>clip.filters.grayscale=+e.target.value); pgray.onchange=()=>{renderProps();pushHistory();}; }
  if(psep){ psep.oninput=e=>upd(()=>clip.filters.sepia=+e.target.value); psep.onchange=()=>{renderProps();pushHistory();}; }
  if(pinv){ pinv.oninput=e=>upd(()=>clip.filters.invert=+e.target.value); pinv.onchange=()=>{renderProps();pushHistory();}; }
  if(pblur){ pblur.oninput=e=>upd(()=>clip.filters.blur=+e.target.value); pblur.onchange=()=>{renderProps();pushHistory();}; }
  propsContent.querySelectorAll('[data-fpreset]').forEach(b=>{
    b.onclick = ()=>{
      Object.assign(clip.filters, CLIP_FILTER_PRESETS[b.dataset.fpreset]);
      renderProps(); renderFrame(currentTime); pushHistory();
    };
  });
  document.getElementById('propDuplicateBtn').onclick = ()=> duplicateClip(clip.id);
  document.getElementById('propDeleteBtn').onclick = ()=> deleteClip(clip.id);
  document.getElementById('propRippleDeleteBtn').onclick = ()=> rippleDeleteClip(clip.id);
}

function duplicateClip(id, skipHistory){
  const found = getClipById(id);
  if(!found) return;
  const { clip, track } = found;
  const copy = JSON.parse(JSON.stringify(clip));
  copy.id = uidClip();
  copy.start = clip.start + clip.duration;
  track.clips.push(copy);
  if(!skipHistory) selectClip(copy.id);
  ensureWholeTimelineVisible();
  renderTracks();
  if(!skipHistory) pushHistory();
}

function renderTextProps(clip){
  if(clip.bold===undefined) clip.bold=true;
  if(clip.italic===undefined) clip.italic=false;
  if(clip.opacity===undefined) clip.opacity=100;
  if(clip.bgEnabled===undefined) clip.bgEnabled=false;
  if(clip.bgColor===undefined) clip.bgColor='#000000';
  if(clip.bgOpacity===undefined) clip.bgOpacity=80;
  if(clip.bgPadding===undefined) clip.bgPadding=16;
  if(clip.fadeIn===undefined) clip.fadeIn=0;
  if(clip.fadeOut===undefined) clip.fadeOut=0;
  if(clip.animation===undefined) clip.animation='none';
  if(clip.highlightColor===undefined) clip.highlightColor='#ffd400';

  const curFont = clip.fontFamily || 'Anton';
  const fontOptions = (list)=> list.map(f=>{
    const css = txtFontCss(f);
    const sel = (curFont===css || curFont===f) ? 'selected' : '';
    return `<option value='${css}' style="font-family:${css}" ${sel}>${f}</option>`;
  }).join('');
  let html = `
    <div class="field"><label>Treść</label><textarea id="propText" rows="3">${escapeHtml(clip.text)}</textarea></div>
    <div class="field"><label>Czcionka</label>
      <input type="search" id="propFontSearch" placeholder="Szukaj czcionki…" style="width:100%; margin-bottom:6px; background:#12141b; color:#eef0f6; border:1px solid #2a2f3d; border-radius:6px; padding:6px 8px;">
      <select id="propFont" size="6" style="width:100%; height:120px;">
        <optgroup label="⭐ Wbudowane">${fontOptions(TXT_FONTS_EMBEDDED)}</optgroup>
        <optgroup label="💻 Z komputera (${TXT_FONTS_SYSTEM.length})">${fontOptions(TXT_FONTS_SYSTEM)}</optgroup>
      </select>
      <button type="button" id="propLoadLocalFonts" class="chip" style="width:100%; margin-top:6px; font-size:11px;">📥 Wczytaj czcionki z komputera</button>
    </div>
    <div class="field"><label>Rozmiar <span>${clip.fontSize}px</span></label><input type="range" id="propFontSize" min="12" max="200" value="${clip.fontSize}"></div>
    <div class="row">
      <div class="field"><label>Kolor</label><input type="color" id="propColor" value="${clip.color}"></div>
      <div class="field"><label>Obrys</label><input type="color" id="propStroke" value="${clip.strokeColor}"></div>
    </div>
    <div class="field"><label>Grubość obrysu <span>${clip.strokeWidth}</span></label><input type="range" id="propStrokeWidth" min="0" max="20" value="${clip.strokeWidth}"></div>
    <div class="field"><label>Styl</label><div class="chip-row">
      <button class="chip ${clip.bold?'active':''}" id="propBold">Pogrubienie</button>
      <button class="chip ${clip.italic?'active':''}" id="propItalic">Kursywa</button>
    </div></div>
    <div class="field"><label>Wyrównanie</label><div class="chip-row">
      <button class="chip ${clip.align==='left'?'active':''}" data-align="left">Lewo</button>
      <button class="chip ${clip.align==='center'?'active':''}" data-align="center">Środek</button>
      <button class="chip ${clip.align==='right'?'active':''}" data-align="right">Prawo</button>
    </div></div>
    <div class="field"><label>Przezroczystość <span>${clip.opacity}%</span></label><input type="range" id="propOpacity" min="0" max="100" value="${clip.opacity}"></div>
    <h3 style="margin-top:14px;">Tło pod tekstem</h3>
    <div class="field"><label>Włącz tło <input type="checkbox" id="propBgOn" ${clip.bgEnabled?'checked':''}></label></div>
    ${clip.bgEnabled ? `
    <div class="row">
      <div class="field"><label>Kolor tła</label><input type="color" id="propBgColor" value="${clip.bgColor}"></div>
      <div class="field"><label>Krycie <span>${clip.bgOpacity}%</span></label><input type="range" id="propBgOpacity" min="0" max="100" value="${clip.bgOpacity}"></div>
    </div>
    <div class="field"><label>Margines <span>${clip.bgPadding}px</span></label><input type="range" id="propBgPadding" min="0" max="50" value="${clip.bgPadding}"></div>
    ` : ''}
    <h3 style="margin-top:14px;">Animacja (jak w CapCut)</h3>
    <div class="field"><label>Efekt wejścia</label><div class="chip-row">
      <button class="chip ${(!clip.animation||clip.animation==='none')?'active':''}" data-anim="none">Brak</button>
      <button class="chip ${clip.animation==='pop'?'active':''}" data-anim="pop">Powiększenie</button>
      <button class="chip ${clip.animation==='slideup'?'active':''}" data-anim="slideup">Wjazd z dołu</button>
    </div></div>
    <div class="row">
      <div class="field"><label>Pojawianie <span>${clip.fadeIn}s</span></label><input type="range" id="propFadeIn" min="0" max="2" step="0.05" value="${clip.fadeIn}"></div>
      <div class="field"><label>Znikanie <span>${clip.fadeOut}s</span></label><input type="range" id="propFadeOut" min="0" max="2" step="0.05" value="${clip.fadeOut}"></div>
    </div>
    ${Array.isArray(clip.words) && clip.words.length>0 ? `
    <h3 style="margin-top:14px;">Karaoke (podświetlanie słów)</h3>
    <div class="field"><label>Włącz podświetlanie <input type="checkbox" id="propKaraokeOn" ${clip.karaoke?'checked':''}></label></div>
    ${clip.karaoke ? `<div class="field"><label>Kolor podświetlenia</label><input type="color" id="propHighlightColor" value="${clip.highlightColor}"></div>` : ''}
    ` : ''}
    <div class="row">
      <div class="field"><label>Pozycja X <span>${clip.x}%</span></label><input type="range" id="propX" min="0" max="100" value="${clip.x}"></div>
      <div class="field"><label>Pozycja Y <span>${clip.y}%</span></label><input type="range" id="propY" min="0" max="100" value="${clip.y}"></div>
    </div>
    <div class="field"><label>Start na osi <span>${clip.start.toFixed(2)}s</span></label><input type="range" id="propStart" min="0" max="${Math.max(30,projectDuration())}" step="0.05" value="${clip.start}"></div>
    <div class="field"><label>Długość <span>${clip.duration.toFixed(2)}s</span></label><input type="range" id="propDur" min="0.2" max="60" step="0.05" value="${clip.duration}"></div>
    <div class="row" style="margin-top:10px;">
      <button id="propDeleteBtn" class="chip" style="flex:1; color:var(--danger);">🗑️ Usuń</button>
      <button id="propRippleDeleteBtn" class="chip" style="flex:1;">🌊 Usuń i zsuń</button>
    </div>
  `;
  propsContent.innerHTML = html;
  const upd = fn=>{ fn(); renderTracks(); renderFrame(currentTime); };
  document.getElementById('propText').oninput = e=>upd(()=>clip.text=e.target.value);
  document.getElementById('propText').onblur = ()=>pushHistory();
  document.getElementById('propFont').onchange = e=>{ clip.fontFamily=e.target.value; renderFrame(currentTime); pushHistory(); };
  const fontSearch = document.getElementById('propFontSearch');
  if(fontSearch){
    fontSearch.oninput = ()=>{
      const q = fontSearch.value.trim().toLowerCase();
      const sel = document.getElementById('propFont');
      const all = allFontNames().filter(f=> !q || f.toLowerCase().includes(q));
      const emb = all.filter(f=> TXT_FONTS_EMBEDDED.includes(f));
      const sys = all.filter(f=> !TXT_FONTS_EMBEDDED.includes(f));
      const opt = (list)=> list.map(f=>{
        const css = txtFontCss(f);
        const selA = (clip.fontFamily===css || clip.fontFamily===f) ? 'selected' : '';
        return `<option value='${css}' style="font-family:${css}" ${selA}>${f}</option>`;
      }).join('');
      sel.innerHTML = `<optgroup label="⭐ Wbudowane">${opt(emb)}</optgroup><optgroup label="💻 Z komputera">${opt(sys)}</optgroup>`;
    };
  }
  const loadBtn = document.getElementById('propLoadLocalFonts');
  if(loadBtn){
    loadBtn.onclick = async ()=>{
      loadBtn.textContent = 'Ładuję…';
      localFontsLoaded = false;
      await loadLocalFonts();
      renderProps();
      renderFrame(currentTime);
    };
  }
  const fs = document.getElementById('propFontSize'), pc = document.getElementById('propColor'), psw = document.getElementById('propStroke'), pswW = document.getElementById('propStrokeWidth');
  fs.oninput=e=>upd(()=>clip.fontSize=+e.target.value); fs.onchange=()=>{renderProps();pushHistory();};
  pc.oninput=e=>upd(()=>clip.color=e.target.value); pc.onchange=()=>pushHistory();
  psw.oninput=e=>upd(()=>clip.strokeColor=e.target.value); psw.onchange=()=>pushHistory();
  pswW.oninput=e=>upd(()=>clip.strokeWidth=+e.target.value); pswW.onchange=()=>{renderProps();pushHistory();};
  document.getElementById('propBold').onclick = ()=>{ clip.bold=!clip.bold; renderProps(); renderFrame(currentTime); pushHistory(); };
  document.getElementById('propItalic').onclick = ()=>{ clip.italic=!clip.italic; renderProps(); renderFrame(currentTime); pushHistory(); };
  propsContent.querySelectorAll('[data-align]').forEach(b=>{
    b.onclick = ()=>{ clip.align=b.dataset.align; renderProps(); renderFrame(currentTime); pushHistory(); };
  });
  const po = document.getElementById('propOpacity');
  po.oninput=e=>upd(()=>clip.opacity=+e.target.value); po.onchange=()=>{renderProps();pushHistory();};
  document.getElementById('propBgOn').onchange = e=>{ clip.bgEnabled=e.target.checked; renderProps(); renderFrame(currentTime); pushHistory(); };
  const pbgc = document.getElementById('propBgColor'), pbgo = document.getElementById('propBgOpacity'), pbgp = document.getElementById('propBgPadding');
  if(pbgc){ pbgc.oninput=e=>upd(()=>clip.bgColor=e.target.value); pbgc.onchange=()=>pushHistory(); }
  if(pbgo){ pbgo.oninput=e=>upd(()=>clip.bgOpacity=+e.target.value); pbgo.onchange=()=>{renderProps();pushHistory();}; }
  if(pbgp){ pbgp.oninput=e=>upd(()=>clip.bgPadding=+e.target.value); pbgp.onchange=()=>{renderProps();pushHistory();}; }
  const pfi = document.getElementById('propFadeIn'), pfo = document.getElementById('propFadeOut');
  pfi.oninput=e=>upd(()=>clip.fadeIn=+e.target.value); pfi.onchange=()=>{renderProps();pushHistory();};
  pfo.oninput=e=>upd(()=>clip.fadeOut=+e.target.value); pfo.onchange=()=>{renderProps();pushHistory();};
  propsContent.querySelectorAll('[data-anim]').forEach(b=>{
    b.onclick = ()=>{ clip.animation=b.dataset.anim; renderProps(); renderFrame(currentTime); pushHistory(); };
  });
  const pkOn = document.getElementById('propKaraokeOn');
  if(pkOn) pkOn.onchange = e=>{ clip.karaoke=e.target.checked; renderProps(); renderFrame(currentTime); pushHistory(); };
  const pHl = document.getElementById('propHighlightColor');
  if(pHl){ pHl.oninput=e=>upd(()=>clip.highlightColor=e.target.value); pHl.onchange=()=>pushHistory(); }
  const px = document.getElementById('propX'), py = document.getElementById('propY');
  px.oninput=e=>upd(()=>clip.x=+e.target.value); px.onchange=()=>{renderProps();pushHistory();};
  py.oninput=e=>upd(()=>clip.y=+e.target.value); py.onchange=()=>{renderProps();pushHistory();};
  const ps = document.getElementById('propStart'), pd = document.getElementById('propDur');
  ps.oninput=e=>upd(()=>clip.start=+e.target.value); ps.onchange=()=>{renderProps();pushHistory();};
  pd.oninput=e=>upd(()=>clip.duration=+e.target.value); pd.onchange=()=>{renderProps();pushHistory();};
  document.getElementById('propDeleteBtn').onclick = ()=> deleteClip(clip.id);
  document.getElementById('propRippleDeleteBtn').onclick = ()=> rippleDeleteClip(clip.id);
}

// ---------- PASEK NARZĘDZI OSI CZASU ----------
document.getElementById('splitBtn').onclick = ()=>{ if(selectedClipId) splitClipAt(selectedClipId, currentTime); };
document.getElementById('deleteClipBtn').onclick = ()=>{
  if(selectedClipIds.size===0) return;
  [...selectedClipIds].forEach(id=> deleteClip(id, true));
  selectClip(null);
  pushHistory();
};
document.getElementById('addVideoTrackBtn').onclick = ()=>{ addTrack('visual'); pushHistory(); };
document.getElementById('addAudioTrackBtn').onclick = ()=>{ addTrack('audio'); pushHistory(); };
function computeMinZoom(){
  const availWidth = Math.max(100, timelineScroll.clientWidth - 80);
  const dur = Math.max(3, projectDuration());
  return Math.max(3, availWidth/dur);
}
document.getElementById('zoomInBtn').onclick = ()=>{ pxPerSec = Math.min(400, pxPerSec*1.3); renderTracks(); };
document.getElementById('zoomOutBtn').onclick = ()=>{ pxPerSec = Math.max(computeMinZoom(), pxPerSec/1.3); renderTracks(); };
document.getElementById('fitZoomBtn').onclick = ()=>{ pxPerSec = computeMinZoom(); renderTracks(); };

// zaznaczanie masowe (marquee) - przeciagniecie lewym po pustym obszarze osi czasu
let marqueeBox = null;
let marqueeStart = null;

tracksContainer.addEventListener('pointerdown', (e)=>{
  if(e.target===tracksContainer || e.target.classList.contains('track-row')){
    marqueeStart = { x: e.clientX, y: e.clientY };
    marqueeBox = document.createElement('div');
    marqueeBox.style.cssText = `position:fixed; left:${e.clientX}px; top:${e.clientY}px; width:0; height:0;
      border:1.5px dashed var(--accent); background:rgba(124,92,255,0.15); z-index:50; pointer-events:none;`;
    document.body.appendChild(marqueeBox);
    window.addEventListener('pointermove', onMarqueeMove);
    window.addEventListener('pointerup', onMarqueeUp);
  }
});

function onMarqueeMove(e){
  if(!marqueeBox || !marqueeStart) return;
  const x0 = Math.min(marqueeStart.x, e.clientX), x1 = Math.max(marqueeStart.x, e.clientX);
  const y0 = Math.min(marqueeStart.y, e.clientY), y1 = Math.max(marqueeStart.y, e.clientY);
  marqueeBox.style.left = x0+'px'; marqueeBox.style.top = y0+'px';
  marqueeBox.style.width = (x1-x0)+'px'; marqueeBox.style.height = (y1-y0)+'px';
}

function onMarqueeUp(e){
  window.removeEventListener('pointermove', onMarqueeMove);
  window.removeEventListener('pointerup', onMarqueeUp);
  if(!marqueeBox){ marqueeStart=null; return; }
  const rect = marqueeBox.getBoundingClientRect();
  const dragDistance = Math.hypot(e.clientX-marqueeStart.x, e.clientY-marqueeStart.y);
  marqueeBox.remove();
  marqueeBox = null; marqueeStart = null;

  if(dragDistance < 4){
    selectClip(null);
    return;
  }
  const found = [];
  tracksContainer.querySelectorAll('.clip').forEach(el=>{
    const r = el.getBoundingClientRect();
    const intersects = r.left < rect.right && r.right > rect.left && r.top < rect.bottom && r.bottom > rect.top;
    if(intersects) found.push(el.dataset.clipId);
  });
  selectMultipleClips(found);
}

// ---------- HISTORIA (UNDO/REDO) ----------
function pushHistory(){
  if(suppressHistory) return;
  history = history.slice(0, historyIndex+1);
  history.push(JSON.stringify(project));
  if(history.length>60) history.shift();
  historyIndex = history.length-1;
  scheduleAutoSave();
}
function undo(){
  if(historyIndex<=0) return;
  historyIndex--;
  suppressHistory = true;
  project = JSON.parse(history[historyIndex]);
  selectedClipId = null; selectedClipIds = new Set();
  renderTracks(); renderProps(); renderFrame(currentTime);
  suppressHistory = false;
}
function redo(){
  if(historyIndex>=history.length-1) return;
  historyIndex++;
  suppressHistory = true;
  project = JSON.parse(history[historyIndex]);
  selectedClipId = null; selectedClipIds = new Set();
  renderTracks(); renderProps(); renderFrame(currentTime);
  suppressHistory = false;
}
document.getElementById('undoBtn').onclick = undo;
document.getElementById('redoBtn').onclick = redo;
window.addEventListener('keydown', (e)=>{
  if((e.ctrlKey||e.metaKey) && e.key==='z' && !e.shiftKey){ e.preventDefault(); undo(); }
  if((e.ctrlKey||e.metaKey) && (e.key==='y' || (e.key==='z'&&e.shiftKey))){ e.preventDefault(); redo(); }
});

// ---------- PROJEKTY (IndexedDB) + MENU GŁÓWNE + AUTOZAPIS ----------
const DB_NAME = 'prosty-montaz-db';
const DB_VER = 1;
let currentProjectId = null;
let currentProjectName = 'Bez nazwy';
let autoSaveTimer = null;
let autoSaveDirty = false;

function openDB(){
  return new Promise((resolve, reject)=>{
    const req = indexedDB.open(DB_NAME, DB_VER);
    req.onupgradeneeded = ()=>{
      const db = req.result;
      if(!db.objectStoreNames.contains('projects')){
        db.createObjectStore('projects', { keyPath: 'id' });
      }
      if(!db.objectStoreNames.contains('media')){
        db.createObjectStore('media', { keyPath: 'key' }); // key = projectId + '::' + mediaId
      }
    };
    req.onsuccess = ()=> resolve(req.result);
    req.onerror = ()=> reject(req.error);
  });
}
function idbReq(req){
  return new Promise((resolve, reject)=>{
    req.onsuccess = ()=> resolve(req.result);
    req.onerror = ()=> reject(req.error);
  });
}

async function listProjects(){
  const db = await openDB();
  const tx = db.transaction('projects', 'readonly');
  const all = await idbReq(tx.objectStore('projects').getAll());
  all.sort((a,b)=> (b.updatedAt||0) - (a.updatedAt||0));
  return all;
}

async function deleteProject(id){
  const db = await openDB();
  const tx = db.transaction(['projects','media'], 'readwrite');
  await idbReq(tx.objectStore('projects').delete(id));
  // usuń media tego projektu
  const allMedia = await idbReq(tx.objectStore('media').getAll());
  for(const m of allMedia){
    if(m.key && m.key.startsWith(id+'::')) await idbReq(tx.objectStore('media').delete(m.key));
  }
  await new Promise(r=>{ tx.oncomplete = r; });
}

function uidProject(){ return 'P'+Date.now().toString(36)+Math.random().toString(36).slice(2,7); }

function setAutoSaveStatus(txt){
  const el = document.getElementById('autoSaveStatus');
  if(el) el.textContent = txt;
}

function scheduleAutoSave(){
  if(!currentProjectId) return;
  autoSaveDirty = true;
  setAutoSaveStatus('💾 …');
  if(autoSaveTimer) clearTimeout(autoSaveTimer);
  autoSaveTimer = setTimeout(()=>{ autoSaveNow(); }, 1200);
}

async function captureThumb(){
  try{
    const c = previewCanvas;
    if(!c || c.width < 2) return null;
    // mała miniatura JPEG
    const off = document.createElement('canvas');
    off.width = 320; off.height = Math.round(320 * (c.height/Math.max(1,c.width)));
    off.getContext('2d').drawImage(c, 0, 0, off.width, off.height);
    return off.toDataURL('image/jpeg', 0.7);
  }catch(e){ return null; }
}

async function autoSaveNow(){
  if(!currentProjectId || !autoSaveDirty) return;
  autoSaveDirty = false;
  setAutoSaveStatus('💾 zapisuję…');
  try{
    const thumb = await captureThumb();
    const data = {
      project,
      mediaMeta: mediaLibrary.map(m=>({
        id:m.id, name:m.name, type:m.type, duration:m.duration,
        width:m.width, height:m.height, isGif:!!m.isGif
      }))
    };
    const db = await openDB();
    const tx = db.transaction(['projects','media'], 'readwrite');
    const rec = {
      id: currentProjectId,
      name: currentProjectName || 'Bez nazwy',
      updatedAt: Date.now(),
      thumb,
      data
    };
    await idbReq(tx.objectStore('projects').put(rec));
    // zapisz / zaktualizuj pliki mediów (blob) — tylko te które mają File
    for(const m of mediaLibrary){
      if(!m.file) continue;
      const key = currentProjectId + '::' + m.id;
      await idbReq(tx.objectStore('media').put({
        key,
        projectId: currentProjectId,
        mediaId: m.id,
        name: m.name,
        type: m.type || m.file.type,
        blob: m.file
      }));
    }
    await new Promise(r=>{ tx.oncomplete = r; });
    setAutoSaveStatus('💾 zapisano');
  }catch(err){
    console.warn('autosave', err);
    setAutoSaveStatus('⚠️ błąd zapisu');
    autoSaveDirty = true;
  }
}

// zapis przy zamykaniu / ukryciu wtyczki
window.addEventListener('pagehide', ()=>{ if(autoSaveDirty) autoSaveNow(); });
window.addEventListener('beforeunload', ()=>{ if(autoSaveDirty) autoSaveNow(); });
document.addEventListener('visibilitychange', ()=>{
  if(document.visibilityState === 'hidden' && autoSaveDirty) autoSaveNow();
});

function showHome(){
  pause();
  if(autoSaveDirty) autoSaveNow();
  document.getElementById('app').style.display = 'none';
  const home = document.getElementById('homeScreen');
  home.classList.remove('hidden');
  home.style.display = '';
  refreshHomeList();
}
function showEditor(){
  document.getElementById('homeScreen').style.display = 'none';
  document.getElementById('homeScreen').classList.add('hidden');
  document.getElementById('app').style.display = '';
}

async function refreshHomeList(){
  const grid = document.getElementById('homeProjects');
  grid.innerHTML = '<div class="home-empty">Ładowanie…</div>';
  try{
    const projects = await listProjects();
    grid.innerHTML = '';
    // karta "nowy"
    const neu = document.createElement('div');
    neu.className = 'home-card home-card-new';
    neu.innerHTML = '＋<br>Nowy projekt';
    neu.onclick = ()=> createNewProject();
    grid.appendChild(neu);
    if(!projects.length){
      const empty = document.createElement('div');
      empty.className = 'home-empty';
      empty.textContent = 'Brak projektów — kliknij „Nowy projekt”, żeby zacząć.';
      grid.appendChild(empty);
      return;
    }
    projects.forEach(p=>{
      const card = document.createElement('div');
      card.className = 'home-card';
      const date = p.updatedAt ? new Date(p.updatedAt).toLocaleString('pl-PL') : '';
      card.innerHTML = `
        <div class="home-card-thumb">${p.thumb ? `<img src="${p.thumb}" alt="">` : '🎬'}</div>
        <div class="home-card-body">
          <div class="home-card-title">${escapeHtml(p.name||'Bez nazwy')}</div>
          <div class="home-card-meta">${date}</div>
        </div>
        <div class="home-card-actions">
          <button type="button" data-del="${p.id}">Usuń</button>
        </div>`;
      card.querySelector('.home-card-thumb').onclick = ()=> openProject(p.id);
      card.querySelector('.home-card-body').onclick = ()=> openProject(p.id);
      card.querySelector('[data-del]').onclick = async (e)=>{
        e.stopPropagation();
        if(!confirm('Usunąć projekt „'+(p.name||'')+'”?')) return;
        await deleteProject(p.id);
        refreshHomeList();
      };
      grid.appendChild(card);
    });
  }catch(err){
    grid.innerHTML = '<div class="home-empty">Nie udało się wczytać listy projektów.</div>';
    console.error(err);
  }
}

async function createNewProject(){
  currentProjectId = uidProject();
  currentProjectName = 'Projekt '+new Date().toLocaleString('pl-PL', {day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});
  project = { fps:30, width:1280, height:720, tracks:[] };
  mediaLibrary = [];
  mediaCounter = 0; clipCounter = 0; trackCounter = 0;
  selectedClipId = null; selectedClipIds = new Set();
  currentTime = 0; isPlaying = false;
  history = []; historyIndex = -1;
  sizeFromFirstDone = false;
  addTrack('visual');
  addTrack('audio');
  applyProjectSize(1280, 720, false);
  renderMediaList(); renderTracks(); renderProps(); renderFrame(0); updateTimeDisplay();
  pushHistory();
  autoSaveDirty = true;
  await autoSaveNow();
  showEditor();
  // zapytaj o nazwę
  const n = prompt('Nazwa projektu:', currentProjectName);
  if(n && n.trim()){ currentProjectName = n.trim(); autoSaveDirty = true; scheduleAutoSave(); }
}

async function openProject(id){
  const db = await openDB();
  const tx = db.transaction(['projects','media'], 'readonly');
  const rec = await idbReq(tx.objectStore('projects').get(id));
  if(!rec || !rec.data){ alert('Nie znaleziono projektu.'); return; }
  currentProjectId = id;
  currentProjectName = rec.name || 'Bez nazwy';
  project = rec.data.project;
  const meta = rec.data.mediaMeta || [];
  mediaLibrary = [];
  mediaCounter = 0; clipCounter = 0; trackCounter = 0;
  // przywróć media z IDB
  for(const m of meta){
    const key = id + '::' + m.id;
    let blobRec = null;
    try{ blobRec = await idbReq(tx.objectStore('media').get(key)); }catch(e){}
    const item = {
      id: m.id, name: m.name, type: m.type, duration: m.duration||0,
      width: m.width||0, height: m.height||0, isGif: !!m.isGif,
      file: null, url: null, el: null
    };
    // liczniki
    const num = parseInt(String(m.id).replace(/\D/g,''),10);
    if(num > mediaCounter) mediaCounter = num;
    if(blobRec && blobRec.blob){
      item.file = blobRec.blob instanceof File ? blobRec.blob : new File([blobRec.blob], m.name, {type: blobRec.type||blobRec.blob.type||''});
      item.url = URL.createObjectURL(item.file);
      if(item.type==='video' || item.isGif){
        const v = document.createElement('video');
        v.src = item.url; v.preload='metadata'; v.muted=false;
        v.onloadedmetadata = ()=>{
          item.duration = v.duration || item.duration;
          item.width = v.videoWidth || item.width;
          item.height = v.videoHeight || item.height;
          item.el = v; item.type = 'video';
          renderMediaList();
        };
      } else if(item.type==='audio'){
        const a = document.createElement('audio');
        a.src = item.url; a.preload='metadata';
        a.onloadedmetadata = ()=>{ item.duration=a.duration; item.el=a; renderMediaList(); };
      } else {
        const img = new Image();
        img.onload = ()=>{ item.el=img; item.width=img.width; item.height=img.height; renderMediaList(); };
        img.src = item.url;
      }
    }
    mediaLibrary.push(item);
  }
  // odtwórz liczniki klipów/ścieżek
  project.tracks.forEach(tr=>{
    const tn = parseInt(String(tr.id).replace(/\D/g,''),10);
    if(tn > trackCounter) trackCounter = tn;
    (tr.clips||[]).forEach(c=>{
      const cn = parseInt(String(c.id).replace(/\D/g,''),10);
      if(cn > clipCounter) clipCounter = cn;
    });
  });
  selectedClipId = null; selectedClipIds = new Set();
  currentTime = 0;
  history = []; historyIndex = -1;
  applyProjectSize(project.width||1280, project.height||720, false);
  renderMediaList(); renderTracks(); renderProps(); renderFrame(0); updateTimeDisplay();
  pushHistory();
  autoSaveDirty = false;
  setAutoSaveStatus('💾 zapisano');
  showEditor();
}

document.getElementById('homeNewBtn').onclick = ()=> createNewProject();
document.getElementById('homeBtn').onclick = ()=> showHome();
document.getElementById('homeSettingsBtn').onclick = ()=> document.getElementById('settingsBtn').click();

// przy imporcie — jeśli jest placeholder bez pliku, podłącz po nazwie
let pendingRelink = false;
const _origImportFiles = importFiles;
importFiles = function(fileList){
  // zawsze: spróbuj dopasować brakujące media po nazwie
  let linked = 0;
  Array.from(fileList).forEach(file=>{
    const placeholder = mediaLibrary.find(m=>m.name===file.name && !m.el);
    if(!placeholder) return;
    const url = URL.createObjectURL(file);
    placeholder.file = file; placeholder.url = url;
    if(placeholder.type==='video' || placeholder.isGif){
      const v = document.createElement('video'); v.src=url; v.preload='metadata';
      v.onloadedmetadata = ()=>{ placeholder.el=v; placeholder.duration=v.duration; placeholder.width=v.videoWidth; placeholder.height=v.videoHeight; placeholder.type='video'; renderMediaList(); };
    } else if(placeholder.type==='audio'){
      const a = document.createElement('audio'); a.src=url; a.preload='metadata';
      a.onloadedmetadata = ()=>{ placeholder.el=a; placeholder.duration=a.duration; renderMediaList(); };
    } else {
      const img = new Image(); img.onload=()=>{ placeholder.el=img; placeholder.width=img.width; placeholder.height=img.height; renderMediaList(); }; img.src=url;
    }
    linked++;
  });
  if(linked > 0){
    renderMediaList();
    scheduleAutoSave();
    // jeśli wszystkie pliki z importu poszły na relink — nie dodawaj duplikatów
    if(linked === fileList.length) return;
  }
  _origImportFiles(fileList);
  scheduleAutoSave();
};

// ---------- PROPORCJE / ROZDZIELCZOŚĆ PROJEKTU ----------
function applyProjectSize(w, h, pushHist){
  w = Math.max(16, Math.round(w));
  h = Math.max(16, Math.round(h));
  // yuv420 / eksport wymaga parzystych wymiarów
  if(w % 2) w++;
  if(h % 2) h++;
  project.width = w;
  project.height = h;
  previewCanvas.width = w;
  previewCanvas.height = h;
  // zsynchronizuj select jeśli pasuje do presetu
  const sel = document.getElementById('aspectSelect');
  const key = w+'x'+h;
  let matched = false;
  if(sel){
    for(const opt of sel.options){
      if(opt.value === key){ sel.value = key; matched = true; break; }
    }
    if(!matched){
      sel.value = 'custom';
      const wrap = document.getElementById('customSizeWrap');
      if(wrap) wrap.style.display = 'inline-flex';
      const cw = document.getElementById('customW');
      const ch = document.getElementById('customH');
      if(cw) cw.value = w;
      if(ch) ch.value = h;
    } else {
      const wrap = document.getElementById('customSizeWrap');
      if(wrap) wrap.style.display = 'none';
    }
  }
  renderFrame(currentTime);
  if(pushHist) pushHistory();
}

document.getElementById('aspectSelect').onchange = (e)=>{
  const val = e.target.value;
  const wrap = document.getElementById('customSizeWrap');
  if(val === 'custom'){
    if(wrap) wrap.style.display = 'inline-flex';
    document.getElementById('customW').value = project.width;
    document.getElementById('customH').value = project.height;
    return;
  }
  if(wrap) wrap.style.display = 'none';
  const [w,h] = val.split('x').map(Number);
  if(w && h) applyProjectSize(w, h, true);
};
document.getElementById('customSizeApply').onclick = ()=>{
  const w = +document.getElementById('customW').value || project.width;
  const h = +document.getElementById('customH').value || project.height;
  applyProjectSize(w, h, true);
};
// Enter w polach custom
['customW','customH'].forEach(id=>{
  const el = document.getElementById(id);
  if(el) el.addEventListener('keydown', e=>{
    if(e.key==='Enter') document.getElementById('customSizeApply').click();
  });
});

/** Ustaw rozmiar projektu z pierwszego zaimportowanego wideo/obrazu (opcjonalnie) */
let sizeFromFirstDone = false;
function maybeSetSizeFromMedia(item){
  if(sizeFromFirstDone) return;
  if(workspaceSettings.sizeFromFirst === false) return;
  if(!item || !item.width || !item.height) return;
  if(item.type !== 'video' && item.type !== 'image' && !item.isGif) return;
  // tylko gdy projekt jeszcze „pusty” (brak klipów) albo domyślne 1280×720
  const hasClips = project.tracks.some(t=>t.clips.length>0);
  if(hasClips) return;
  sizeFromFirstDone = true;
  applyProjectSize(item.width, item.height, true);
}

// ---------- USTAWIENIA STANOWISKA (LOKALNE, TYLKO NA TYM KOMPUTERZE) ----------
const DEFAULT_WORKSPACE_SETTINGS = { accentColor:'#7c5cff', trackHeight:56, defaultZoom:60, autoplay:false, magnetic:true, sizeFromFirst:true, mediaWidth:240 };
let workspaceSettings = { ...DEFAULT_WORKSPACE_SETTINGS };

function loadWorkspaceSettings(){
  try{
    const raw = localStorage.getItem('montaz_workspace_settings');
    if(raw) workspaceSettings = { ...DEFAULT_WORKSPACE_SETTINGS, ...JSON.parse(raw) };
  }catch(e){}
  applyWorkspaceSettings();
}
function saveWorkspaceSettings(){
  localStorage.setItem('montaz_workspace_settings', JSON.stringify(workspaceSettings));
}
function applyWorkspaceSettings(){
  document.documentElement.style.setProperty('--accent', workspaceSettings.accentColor);
  document.documentElement.style.setProperty('--track-height', workspaceSettings.trackHeight+'px');
  document.documentElement.style.setProperty('--clip-height', Math.max(20,workspaceSettings.trackHeight-8)+'px');
  const mw = workspaceSettings.mediaWidth || 240;
  document.documentElement.style.setProperty('--media-w', mw+'px');
  pxPerSec = workspaceSettings.defaultZoom;
}

const settingsModal = document.getElementById('settingsModal');
document.getElementById('settingsBtn').onclick = ()=>{
  document.getElementById('setAccentColor').value = workspaceSettings.accentColor;
  document.getElementById('setTrackHeight').value = workspaceSettings.trackHeight;
  document.getElementById('setTrackHeightLbl').textContent = workspaceSettings.trackHeight+'px';
  document.getElementById('setDefaultZoom').value = workspaceSettings.defaultZoom;
  document.getElementById('setZoomLbl').textContent = workspaceSettings.defaultZoom+'px/s';
  document.getElementById('setAutoplay').checked = !!workspaceSettings.autoplay;
  const mag = document.getElementById('setMagnetic');
  if(mag) mag.checked = workspaceSettings.magnetic !== false;
  const sff = document.getElementById('setSizeFromFirst');
  if(sff) sff.checked = workspaceSettings.sizeFromFirst !== false;
  settingsModal.style.display = 'flex';
};
document.getElementById('settingsClose').onclick = ()=>{ settingsModal.style.display='none'; };
settingsModal.addEventListener('click', e=>{ if(e.target===settingsModal) settingsModal.style.display='none'; });
document.getElementById('setAccentColor').oninput = e=>{ workspaceSettings.accentColor=e.target.value; applyWorkspaceSettings(); saveWorkspaceSettings(); };
document.getElementById('setTrackHeight').oninput = e=>{
  workspaceSettings.trackHeight=+e.target.value;
  document.getElementById('setTrackHeightLbl').textContent = workspaceSettings.trackHeight+'px';
  applyWorkspaceSettings(); saveWorkspaceSettings(); renderTracks();
};
document.getElementById('setDefaultZoom').oninput = e=>{
  workspaceSettings.defaultZoom=+e.target.value;
  document.getElementById('setZoomLbl').textContent = workspaceSettings.defaultZoom+'px/s';
  saveWorkspaceSettings();
};
document.getElementById('setAutoplay').onchange = e=>{ workspaceSettings.autoplay=e.target.checked; saveWorkspaceSettings(); };
document.getElementById('setMagnetic').onchange = e=>{ workspaceSettings.magnetic=e.target.checked; saveWorkspaceSettings(); };
document.getElementById('setSizeFromFirst').onchange = e=>{ workspaceSettings.sizeFromFirst=e.target.checked; saveWorkspaceSettings(); };
document.getElementById('settingsResetBtn').onclick = ()=>{
  workspaceSettings = { ...DEFAULT_WORKSPACE_SETTINGS };
  saveWorkspaceSettings(); applyWorkspaceSettings();
  document.getElementById('settingsBtn').click();
  renderTracks();
};

// ---------- TEKST NA WIDEO (fonty wspoldzielone z fonts.css) ----------
const TXT_FONTS_EMBEDDED = [
  'Anton','Bebas Neue','Archivo Black','Alfa Slab One','Russo One','Staatliches',
  'Bangers','Creepster','Shrikhand','Bungee','Righteous','Poppins Black',
  'Oswald','Orbitron','VT323','Press Start 2P','Fredoka','Permanent Marker',
  'Bad Script','Kalam','Caveat','Sacramento','Pacifico','Lobster',
  'Montserrat','Raleway','Poppins','Open Sans','Nunito','Rubik','Inter','Barlow',
  'Work Sans','Quicksand','Comfortaa','DM Sans','Manrope','Karla','Mukta','Ubuntu',
  'PT Sans','Lora','Playfair Display','Crimson Text','Cinzel','Abril Fatface',
  'Passion One','Rammetto One','Baloo 2','Titan One','Fjalla One'
];
const TXT_FONTS_SYSTEM_BASE = [
  'Arial','Arial Black','Verdana','Tahoma','Trebuchet MS','Georgia','Times New Roman',
  'Impact','Segoe UI','Segoe UI Black','Comic Sans MS','Calibri','Century Gothic',
  'Consolas','Courier New','Lucida Console','Lucida Sans Unicode','Palatino Linotype',
  'Bookman Old Style','Garamond','Franklin Gothic Medium','Candara','Constantia',
  'Corbel','Ebrima','Gabriola','Microsoft Sans Serif','MS Gothic','MS UI Gothic',
  'Yu Gothic','Meiryo','Malgun Gothic','Microsoft YaHei','SimSun','Noto Sans',
  'Roboto','Helvetica','Helvetica Neue','Futura','Gill Sans','Optima','Avenir',
  'DIN','Proxima Nova','Montserrat','Poppins'
];
let TXT_FONTS_SYSTEM = TXT_FONTS_SYSTEM_BASE.slice();
let localFontsLoaded = false;

async function loadLocalFonts(){
  if(localFontsLoaded) return;
  localFontsLoaded = true;
  try{
    if(typeof queryLocalFonts === 'function'){
      const fonts = await queryLocalFonts();
      const names = new Set(TXT_FONTS_SYSTEM);
      fonts.forEach(f=>{
        const n = (f.fullName || f.family || '').trim();
        if(n) names.add(n);
        const fam = (f.family || '').trim();
        if(fam) names.add(fam);
      });
      TXT_FONTS_SYSTEM = [...names].sort((a,b)=>a.localeCompare(b,'pl'));
    }
  }catch(e){ console.warn('queryLocalFonts niedostępne:', e); }
}
// spróbuj od razu (Chrome/Edge z uprawnieniem)
loadLocalFonts();

function txtFontCss(name){
  if(!name) return 'Anton';
  // już w cudzysłowach / css
  if(name.startsWith('"') || name.includes(',')) return name;
  return /[^A-Za-z0-9]/.test(name) ? `"${name}"` : name;
}
function allFontNames(){
  const s = new Set([...TXT_FONTS_EMBEDDED, ...TXT_FONTS_SYSTEM]);
  return [...s];
}

document.getElementById('addTextBtn').onclick = ()=>{
  let track = visualTracks()[visualTracks().length-1];
  if(!track || track.clips.some(c=> currentTime>=c.start && currentTime<c.start+c.duration)){
    track = addTrack('visual');
  }
  const clip = {
    id: uidClip(), trackId: track.id, mediaId:null, type:'text',
    start: currentTime, duration: 3,
    sourceIn:0, sourceOut:3, volume:100,
    text:'Twój tekst', fontFamily:'Anton', fontSize:64, color:'#ffffff',
    strokeColor:'#000000', strokeWidth:6, align:'center', x:50, y:85,
    bold:true, italic:false, opacity:100,
    bgEnabled:false, bgColor:'#000000', bgOpacity:80, bgPadding:16,
    fadeIn:0, fadeOut:0, animation:'none'
  };
  track.clips.push(clip);
  selectClip(clip.id);
  ensureWholeTimelineVisible();
  renderTracks();
  pushHistory();
};

// ---------- PRZYCIĘCIE MAGNETYCZNE (SNAPPING, jak w CapCut) ----------
const SNAP_PX = 10;
function collectSnapPoints(excludeClipId){
  const points = [0, currentTime];
  project.tracks.forEach(tr=> tr.clips.forEach(c=>{
    if(c.id===excludeClipId) return;
    points.push(c.start, c.start+c.duration);
  }));
  return points;
}
function snapTime(t, excludeClipId){
  // bez magnetycznej osi — zero przyciągania (w tym do 0)
  if(workspaceSettings.magnetic === false) return t;
  const pxThreshold = SNAP_PX/pxPerSec;
  const points = collectSnapPoints(excludeClipId);
  let best = t, bestDist = pxThreshold;
  points.forEach(p=>{
    const d = Math.abs(p-t);
    if(d < bestDist){ bestDist = d; best = p; }
  });
  return best;
}

/** CapCut-style: zsuń klipy na ścieżce tak, by nie było luk (od lewej) */
function packTrack(track){
  if(!track || workspaceSettings.magnetic === false) return;
  const sorted = [...track.clips].sort((a,b)=>a.start-b.start);
  let cursor = 0;
  sorted.forEach(c=>{
    if(c.start > cursor + 0.001) c.start = cursor;
    // jeśli nachodzi — zostaw (nakładki dozwolone), przesuwamy cursor
    cursor = Math.max(cursor, c.start + c.duration);
  });
}

// ---------- RIPPLE DELETE (usuń i zsuń pozostałe klipy) ----------
function rippleDeleteClip(id){
  const found = getClipById(id);
  if(!found) return;
  const { clip, track } = found;
  const removedDur = clip.duration;
  const removedStart = clip.start;
  track.clips = track.clips.filter(c=>c.id!==id);
  track.clips.forEach(c=>{
    if(c.start >= removedStart+removedDur-0.001) c.start -= removedDur;
  });
  if(selectedClipId===id) selectedClipId=null;
  renderTracks(); renderProps(); pushHistory();
}

// ---------- FILTRY / PRZEJŚCIA (pierwsze efekty) ----------
const CLIP_FILTER_PRESETS = {
  naturalny:  {brightness:100, contrast:100, saturate:100, hueRotate:0, grayscale:0, sepia:0, invert:0, blur:0},
  zywe:       {brightness:105, contrast:115, saturate:145, hueRotate:0, grayscale:0, sepia:0, invert:0, blur:0},
  czb:        {brightness:100, contrast:110, saturate:0,   hueRotate:0, grayscale:100, sepia:0, invert:0, blur:0},
  cieple:     {brightness:105, contrast:100, saturate:115, hueRotate:0, grayscale:0, sepia:15, invert:0, blur:0},
  chlodne:    {brightness:100, contrast:108, saturate:110, hueRotate:180, grayscale:0, sepia:0, invert:0, blur:0},
  vhs:        {brightness:95,  contrast:120, saturate:80,  hueRotate:0, grayscale:0, sepia:0, invert:0, blur:0},
  sepia:      {brightness:105, contrast:105, saturate:100, hueRotate:0, grayscale:0, sepia:80, invert:0, blur:0},
  negatyw:    {brightness:100, contrast:100, saturate:100, hueRotate:180, grayscale:0, sepia:0, invert:100, blur:0},
  cyberpunk:  {brightness:105, contrast:130, saturate:180, hueRotate:270, grayscale:0, sepia:0, invert:0, blur:0},
  mroczny:    {brightness:80,  contrast:130, saturate:70,  hueRotate:0, grayscale:0, sepia:10, invert:0, blur:0},
  marzycielski:{brightness:112, contrast:95, saturate:105, hueRotate:0, grayscale:0, sepia:5, invert:0, blur:1.5},
  starekino:  {brightness:95,  contrast:115, saturate:35,  hueRotate:0, grayscale:0, sepia:45, invert:0, blur:0}
};

function activeClipsOnTrack(track, t){
  return track.clips.filter(c=> t>=c.start && t < c.start+c.duration).sort((a,b)=>a.start-b.start);
}

// ---------- AUTOMATYCZNE NAPISY (AI / Whisper) ----------
const captionsModal = document.getElementById('captionsModal');
const capClipSelect = document.getElementById('capClipSelect');
let capQuality = 'zbalansowany';
let capTemplate = 'zmianowe';
let capKaraoke = true;

function listTranscribableClips(){
  const out = [];
  project.tracks.forEach(tr=>{
    tr.clips.forEach(c=>{
      if(c.type==='video' || c.type==='audio') out.push(c);
    });
  });
  return out;
}

document.getElementById('autoCaptionsBtn').onclick = ()=>{
  const clips = listTranscribableClips();
  if(clips.length===0){ alert('Najpierw dodaj na oś czasu jakiś klip wideo albo audio z dźwiękiem.'); return; }
  capClipSelect.innerHTML = clips.map(c=>{
    const media = getMediaById(c.mediaId);
    return `<option value="${c.id}">${escapeHtml(media?media.name:c.id)} (${fmtTime(c.start)} – ${fmtTime(c.start+c.duration)})</option>`;
  }).join('');
  updateQualityReadyLabels();
  document.getElementById('captionsSetupView').style.display = 'block';
  document.getElementById('captionsProgressView').style.display = 'none';
  captionsModal.style.display = 'flex';
};
document.getElementById('captionsClose').onclick = ()=>{ captionsModal.style.display='none'; };
captionsModal.addEventListener('click', e=>{ if(e.target===captionsModal) captionsModal.style.display='none'; });
document.querySelectorAll('#captionsSetupView [data-quality]').forEach(b=>{
  b.onclick = ()=>{
    document.querySelectorAll('#captionsSetupView [data-quality]').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');
    capQuality = b.dataset.quality;
  };
});
document.querySelectorAll('#captionsSetupView [data-template]').forEach(b=>{
  b.onclick = ()=>{
    document.querySelectorAll('#captionsSetupView [data-template]').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');
    capTemplate = b.dataset.template;
  };
});
document.getElementById('capKaraokeCheck').onchange = e=>{ capKaraoke = e.target.checked; };

function updateQualityReadyLabels(){
  if(!window.whisperEngine || !window.whisperEngine.isModelReady) return;
  document.querySelectorAll('#captionsSetupView [data-quality]').forEach(b=>{
    const ready = window.whisperEngine.isModelReady(b.dataset.quality);
    const base = { szybki:'Szybki', zbalansowany:'Zbalansowany', dokladny:'Najdokładniejszy' }[b.dataset.quality];
    b.textContent = ready ? `${base} ✅` : base;
  });
}
window.addEventListener('whisper-ready', ()=>{
  if(window.whisperEngine.preloadFastModel) window.whisperEngine.preloadFastModel();
  setTimeout(updateQualityReadyLabels, 2000);
});

async function extractAudioForWhisper(clip){
  const media = getMediaById(clip.mediaId);
  if(!media || !media.file) throw new Error('Brak oryginalnego pliku dla tego klipu.');

  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  const actx = new AudioCtx();
  let decoded = null;

  // 1) spróbuj natywnego decode (działa dla wav/mp3/ogg)
  try{
    const arrayBuffer = await media.file.arrayBuffer();
    // kopia — decodeAudioData przejmuje / odłącza buffer
    decoded = await actx.decodeAudioData(arrayBuffer.slice(0));
  }catch(e1){
    console.warn('decodeAudioData natywne nieudane, próbuję ffmpeg…', e1);
  }

  // 2) fallback: ffmpeg wyciąga WAV 16 kHz mono (obsługuje mp4/webm/mov/…)
  if(!decoded){
    if(!window.ffmpegEngine){
      await new Promise(res=>{
        if(window.ffmpegEngine) return res();
        window.addEventListener('ffmpeg-ready', res, {once:true});
      });
    }
    await window.ffmpegEngine.ensureLoaded();
    const wavBlob = await window.ffmpegEngine.extractAudioToWav(media.file);
    const wavBuf = await wavBlob.arrayBuffer();
    try{
      decoded = await actx.decodeAudioData(wavBuf.slice(0));
    }catch(e2){
      try{ actx.close(); }catch(_){}
      throw new Error('Nie udało się odczytać dźwięku z tego pliku (brak ścieżki audio albo nieobsługiwany kodek).');
    }
  }

  const startSample = Math.max(0, Math.floor((clip.sourceIn||0) * decoded.sampleRate));
  const srcOut = (clip.sourceOut!==undefined && clip.sourceOut!==null) ? clip.sourceOut : (clip.sourceIn||0) + (clip.duration||0);
  const endSample = Math.min(decoded.length, Math.floor(srcOut * decoded.sampleRate));
  const length = Math.max(1, endSample - startSample);
  const channels = [];
  for(let c=0;c<decoded.numberOfChannels;c++) channels.push(decoded.getChannelData(c));
  const mono = new Float32Array(length);
  for(let i=0;i<length;i++){
    let sum=0;
    for(let c=0;c<channels.length;c++) sum += channels[c][startSample+i] || 0;
    mono[i] = sum / Math.max(1, channels.length);
  }
  const targetRate = 16000;
  // jeśli już 16k i mono — zwróć wycinek
  if(decoded.sampleRate === targetRate && channels.length === 1){
    try{ actx.close(); }catch(_){}
    return mono;
  }
  const offlineCtx = new OfflineAudioContext(1, Math.max(1, Math.ceil(length * targetRate / decoded.sampleRate)), targetRate);
  const buffer = offlineCtx.createBuffer(1, length, decoded.sampleRate);
  buffer.copyToChannel(mono, 0);
  const src = offlineCtx.createBufferSource();
  src.buffer = buffer;
  src.connect(offlineCtx.destination);
  src.start();
  const rendered = await offlineCtx.startRendering();
  try{ actx.close(); }catch(_){}
  return rendered.getChannelData(0);
}

function setCapProgress(pct, text){
  document.getElementById('capProgressBar').style.width = Math.max(0,Math.min(100,pct))+'%';
  if(text) document.getElementById('capStatusText').textContent = text;
}

document.getElementById('capStartBtn').onclick = async ()=>{
  const clipId = capClipSelect.value;
  const found = getClipById(clipId);
  if(!found) return;
  const clip = found.clip;
  const language = document.getElementById('capLanguage').value;

  document.getElementById('captionsSetupView').style.display = 'none';
  document.getElementById('captionsProgressView').style.display = 'block';
  setCapProgress(5, 'Wyciągam ścieżkę dźwiękową z klipu…');

  try{
    if(!window.whisperEngine){
      await new Promise(res=>{
        if(window.whisperEngine) return res();
        window.addEventListener('whisper-ready', res, {once:true});
      });
    }
    const audio = await extractAudioForWhisper(clip);
    setCapProgress(8, 'Pobieram / ładuję model AI (jednorazowo)...');
    setCapProgress(35, 'Rozpoznaję mowę (AI)…');
    const segments = await window.whisperEngine.transcribe(audio, {
      quality: capQuality,
      language,
      onProgress: (p)=>{
        if(p && p.status==='fallback'){
          setCapProgress(65, p.message || 'Próbuję lżejszym modelem...');
        } else if(p && p.status==='progress' && p.file){
          const pct = 8 + Math.round((p.progress||0)*0.6);
          setCapProgress(pct, `Pobieram model AI: ${p.file} (${Math.round(p.progress||0)}%)`);
        } else if(p && p.status==='ready'){
          setCapProgress(70, 'Model gotowy — analizuję dźwięk...');
        }
      }
    });
    setCapProgress(92, 'Grupuję słowa w napisy...');

    let textTrack = project.tracks.find(t=>t.kind==='visual' && t.__isCaptionTrack);
    if(!textTrack){
      textTrack = addTrack('visual');
      textTrack.__isCaptionTrack = true;
    }
    const words = segments; // whisper.js zwraca teraz plaska liste POJEDYNCZYCH SLOW z czasem
    const groups = groupWordsIntoCaptions(words, capTemplate);
    groups.forEach(group=>{
      const allWords = group.flat();
      if(allWords.length===0) return;
      const text = group.map(line=> line.map(w=>w.text).join(' ')).join('\n');
      const groupStart = allWords[0].start, groupEnd = allWords[allWords.length-1].end;
      textTrack.clips.push({
        id: uidClip(), trackId: textTrack.id, mediaId:null, type:'text',
        start: clip.start+groupStart, duration: Math.max(0.3, groupEnd-groupStart),
        sourceIn:0, sourceOut: Math.max(0.3, groupEnd-groupStart), volume:100,
        text, fontFamily:'Anton', fontSize: capTemplate==='potrojny'?36:capTemplate==='podwojny'?42:48,
        color:'#ffffff', strokeColor:'#000000', strokeWidth:6, align:'center', x:50, y:88,
        bold:true, italic:false, opacity:100,
        bgEnabled:false, bgColor:'#000000', bgOpacity:80, bgPadding:16,
        fadeIn:0, fadeOut:0, animation:'none',
        karaoke: capKaraoke,
        highlightColor: '#ffd400',
        // slowa z CZASEM BEZWZGLEDNYM na osi (start klipu + wzgledny czas slowa) - do podswietlania karaoke
        words: group.map(line=> line.map(w=>({ text:w.text, start: clip.start+w.start, end: clip.start+w.end })))
      });
    });
    renderTracks(); renderFrame(currentTime); pushHistory();
    setCapProgress(100, `Gotowe! Dodano ${groups.length} napisów.`);
    setTimeout(()=>{ captionsModal.style.display='none'; }, 1200);
  }catch(err){
    setCapProgress(0, '❌ Błąd: '+(err.message||err));
  }
};

// ---------- GRUPOWANIE SŁÓW W NAPISY WG SZABLONU ----------
const CAPTION_TEMPLATES = {
  pojedynczy: { lines:1, maxWordsPerLine:8,  charBudget:34 },
  podwojny:   { lines:2, maxWordsPerLine:6,  charBudget:26 },
  potrojny:   { lines:3, maxWordsPerLine:5,  charBudget:22 },
  zmianowe:   { lines:1, maxWordsPerLine:6,  charBudget:24, minWords:3 }
};

function groupWordsIntoCaptions(words, templateKey){
  const t = CAPTION_TEMPLATES[templateKey] || CAPTION_TEMPLATES.zmianowe;
  const groups = [];
  let i = 0;
  while(i < words.length){
    const lines = [];
    for(let ln=0; ln<t.lines && i<words.length; ln++){
      const line = [];
      let chars = 0;
      while(i < words.length && line.length < t.maxWordsPerLine){
        const w = words[i];
        const wLen = w.text.length+1;
        if(line.length>0 && chars+wLen > t.charBudget) break;
        if(line.length>0 && t.minWords && line.length>=t.minWords && /[.!?…,]$/.test(words[i-1].text)) break;
        line.push(w);
        chars += wLen;
        i++;
        if(/[.!?…]$/.test(w.text)) break;
      }
      if(line.length>0) lines.push(line);
    }
    if(lines.length===0) break;
    groups.push(lines);
  }
  return groups;
}

// ---------- EKSPORT WIDEO (przechwytywanie klatka po klatce + miks audio + ffmpeg) ----------
const exportModal = document.getElementById('exportModal');
let exportQuality = 'srednia';
let exportFps = 30;
let exportBitrate = 8000;

const RESOLUTION_HEIGHTS = { '144':144,'240':240,'360':360,'480':480,'720':720,'1080':1080 };

document.getElementById('exportBtn').onclick = ()=>{
  if(projectDuration() < 0.1){ alert('Dodaj najpierw coś na oś czasu.'); return; }
  document.getElementById('exportResProjectOpt').textContent = `Taka jak projekt (${project.width}×${project.height})`;
  exportFps = project.fps || 30;
  document.getElementById('exportFpsRange').value = exportFps;
  document.getElementById('exportFpsLbl').textContent = exportFps;
  document.getElementById('exportSetupView').style.display = 'block';
  document.getElementById('exportProgressView').style.display = 'none';
  exportModal.style.display = 'flex';
};
document.getElementById('exportModalClose').onclick = ()=>{ exportModal.style.display='none'; };
document.querySelectorAll('#exportSetupView [data-exq]').forEach(b=>{
  b.onclick = ()=>{
    document.querySelectorAll('#exportSetupView [data-exq]').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');
    exportQuality = b.dataset.exq;
  };
});
document.getElementById('exportFpsRange').oninput = e=>{
  exportFps = +e.target.value;
  document.getElementById('exportFpsLbl').textContent = exportFps;
};
document.getElementById('exportBitrateRange').oninput = e=>{
  exportBitrate = +e.target.value;
  document.getElementById('exportBitrateLbl').textContent = exportBitrate+' kb/s';
};

// oblicza docelowa szerokosc/wysokosc wyjscia (zachowujac proporcje projektu)
function computeExportResolution(){
  const resVal = document.getElementById('exportResSelect').value;
  if(resVal==='0') return { w: project.width, h: project.height };
  const targetH = RESOLUTION_HEIGHTS[resVal] || project.height;
  const aspect = project.width/project.height;
  let w = Math.round(targetH*aspect);
  if(w%2!==0) w++; // ffmpeg (yuv420p) wymaga parzystych wymiarow
  let h = targetH % 2 !== 0 ? targetH+1 : targetH;
  return { w, h };
}

function setExportProgress(pct, text){
  pct = Math.max(0, Math.min(100, pct));
  document.getElementById('exportProgressBar').style.width = pct+'%';
  const el = document.getElementById('exportStatusText');
  if(text){
    // zawsze dopisuj procent, jeśli nie ma go w tekście
    const hasPct = /\d+\s*%/.test(text);
    el.textContent = hasPct ? text : `${text}  (${Math.round(pct)}%)`;
  }
}

function seekVideoPrecise(el, time){
  return new Promise(resolve=>{
    if(Math.abs(el.currentTime-time) < 0.01){ resolve(); return; }
    const onSeeked = ()=>{ el.removeEventListener('seeked', onSeeked); resolve(); };
    el.addEventListener('seeked', onSeeked);
    try{ el.currentTime = time; }catch(e){ resolve(); }
  });
}

async function captureFrameAt(t, mime='image/jpeg', quality=0.92){
  const seekPromises = [];
  visualTracks().forEach(track=>{
    activeClipsOnTrack(track, t).forEach(clip=>{
      if(clip.type!=='video') return;
      const media = getMediaById(clip.mediaId);
      if(!media || !media.el) return;
      const speed = clip.speed || 1;
      const srcTime = Math.max(0, clip.sourceIn + (t-clip.start) * speed);
      seekPromises.push(seekVideoPrecise(media.el, srcTime));
    });
  });
  await Promise.all(seekPromises);
  renderFrame(t);
  return new Promise(resolve=> previewCanvas.toBlob(resolve, mime, quality));
}

// ---------- MIKS AUDIO (wszystkie sciezki, z automatycznym crossfade) ----------
function planTrackGains(track){
  const clips = [...track.clips].filter(c=>c.type==='video'||c.type==='audio').sort((a,b)=>a.start-b.start);
  const plan = new Map();
  clips.forEach(c=> plan.set(c.id, []));
  for(let i=0;i<clips.length;i++){
    const c = clips[i];
    const vol = (c.volume!==undefined?c.volume:100)/100;
    const next = clips[i+1];
    const prev = clips[i-1];
    const points = plan.get(c.id);
    if(prev && prev.start+prev.duration > c.start+0.001){
      points.push({time:c.start, value:0});
      points.push({time:prev.start+prev.duration, value:vol});
    } else {
      points.push({time:c.start, value:vol});
    }
    if(next && c.start+c.duration > next.start+0.001){
      points.push({time:next.start, value:vol});
      points.push({time:c.start+c.duration, value:0});
    } else {
      points.push({time:c.start+c.duration, value:vol});
    }
  }
  return plan;
}

async function mixdownAudio(duration, onProgress){
  const sampleRate = 44100;
  const offlineCtx = new OfflineAudioContext(2, Math.max(1,Math.ceil(duration*sampleRate)), sampleRate);
  const relevantTracks = [...visualTracks(), ...audioTracks()];
  const allEntries = [];
  relevantTracks.forEach(track=>{
    const gains = planTrackGains(track);
    track.clips.forEach(clip=>{
      if(clip.type!=='video' && clip.type!=='audio') return;
      const media = getMediaById(clip.mediaId);
      if(!media || !media.file) return;
      allEntries.push({clip, media, gainPoints: gains.get(clip.id)||[]});
    });
  });

  // dekoduj unikalne media
  const decodedCache = new Map();
  let done = 0;
  for(const entry of allEntries){
    if(decodedCache.has(entry.media.id)) continue;
    try{
      const ab = await entry.media.file.arrayBuffer();
      const buf = await offlineCtx.decodeAudioData(ab.slice(0));
      decodedCache.set(entry.media.id, buf);
    }catch(e){
      // fallback ffmpeg → wav
      try{
        if(window.ffmpegEngine){
          await window.ffmpegEngine.ensureLoaded();
          const wavBlob = await window.ffmpegEngine.extractAudioToWav(entry.media.file);
          const wavBuf = await wavBlob.arrayBuffer();
          const buf = await offlineCtx.decodeAudioData(wavBuf.slice(0));
          decodedCache.set(entry.media.id, buf);
        } else {
          console.warn('Nie udało się zdekodować audio:', entry.media.name, e);
        }
      }catch(e2){
        console.warn('Nie udało się zdekodować audio (ffmpeg):', entry.media.name, e2);
      }
    }
    done++;
    if(onProgress) onProgress(done / Math.max(1, allEntries.length) * 0.5);
  }

  allEntries.forEach(entry=>{
    const media = getMediaById(entry.clip.mediaId);
    const decoded = media ? decodedCache.get(media.id) : null;
    if(!decoded) return;
    if(entry.clip.muted) return;
    const speed = entry.clip.speed || 1;
    const src = offlineCtx.createBufferSource();
    src.buffer = decoded;
    src.playbackRate.value = speed;
    const gainNode = offlineCtx.createGain();
    src.connect(gainNode); gainNode.connect(offlineCtx.destination);
    const pts = entry.gainPoints;
    if(pts.length>0){
      gainNode.gain.setValueAtTime(pts[0].value, Math.max(0,pts[0].time));
      for(let i=1;i<pts.length;i++) gainNode.gain.linearRampToValueAtTime(pts[i].value, Math.max(0,pts[i].time));
    }
    const sourceSpan = Math.min(entry.clip.duration*speed, decoded.duration-entry.clip.sourceIn);
    if(sourceSpan>0) src.start(Math.max(0,entry.clip.start), Math.max(0,entry.clip.sourceIn), sourceSpan);
  });

  if(onProgress) onProgress(0.9);
  const result = await offlineCtx.startRendering();
  if(onProgress) onProgress(1);
  return result;
}

function audioBufferToWavBlob(buffer){
  const numCh = buffer.numberOfChannels;
  const len = buffer.length * numCh * 2 + 44;
  const arrBuf = new ArrayBuffer(len);
  const view = new DataView(arrBuf);
  const writeStr = (offset,str)=>{ for(let i=0;i<str.length;i++) view.setUint8(offset+i, str.charCodeAt(i)); };
  writeStr(0,'RIFF'); view.setUint32(4, 36+buffer.length*numCh*2, true); writeStr(8,'WAVE');
  writeStr(12,'fmt '); view.setUint32(16,16,true); view.setUint16(20,1,true);
  view.setUint16(22,numCh,true); view.setUint32(24,buffer.sampleRate,true);
  view.setUint32(28,buffer.sampleRate*numCh*2,true); view.setUint16(32,numCh*2,true); view.setUint16(34,16,true);
  writeStr(36,'data'); view.setUint32(40,buffer.length*numCh*2,true);
  let offset = 44;
  const chData = []; for(let c=0;c<numCh;c++) chData.push(buffer.getChannelData(c));
  for(let i=0;i<buffer.length;i++){
    for(let c=0;c<numCh;c++){
      const s = Math.max(-1, Math.min(1, chData[c][i]));
      view.setInt16(offset, s<0?s*0x8000:s*0x7FFF, true);
      offset += 2;
    }
  }
  return new Blob([arrBuf], {type:'audio/wav'});
}

/** Szybki eksport real-time: canvas.captureStream + MediaRecorder (~1x czas trwania) */
async function exportRealtime(duration, fps, outW, outH, bitrateKbps){
  const wasPlaying = isPlaying;
  pause();
  currentTime = 0;

  // wycisz źródła wideo (audio idzie z offline-mix)
  mediaLibrary.forEach(m=>{
    if(m.el && m.type==='video'){ try{ m.el.muted = true; }catch(e){} }
  });

  // tymczasowy canvas w docelowej rozdzielczości (captureStream stąd)
  const off = document.createElement('canvas');
  off.width = outW; off.height = outH;
  const octx = off.getContext('2d', { alpha: false });

  const stream = off.captureStream(fps);

  // miksuj audio do MediaStream
  let audioCtx = null;
  let audioSrcNode = null;
  try{
    const mixed = await mixdownAudio(duration, null);
    if(mixed && mixed.length > 0){
      audioCtx = new AudioContext();
      const dest = audioCtx.createMediaStreamDestination();
      audioSrcNode = audioCtx.createBufferSource();
      audioSrcNode.buffer = mixed;
      audioSrcNode.connect(dest);
      dest.stream.getAudioTracks().forEach(t=> stream.addTrack(t));
    }
  }catch(e){ console.warn('Audio mix realtime:', e); }

  const mimeCandidates = [
    'video/webm;codecs=vp9,opus',
    'video/webm;codecs=vp8,opus',
    'video/webm',
    'video/mp4'
  ];
  let mime = '';
  for(const m of mimeCandidates){
    if(typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(m)){ mime = m; break; }
  }
  if(!mime) throw new Error('MediaRecorder nie wspiera żadnego formatu wideo w tej przeglądarce');

  const bits = Math.max(500000, (bitrateKbps||8000)*1000);
  const recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: bits });
  const chunks = [];
  recorder.ondataavailable = e=>{ if(e.data && e.data.size) chunks.push(e.data); };
  const stopped = new Promise(resolve=>{ recorder.onstop = ()=> resolve(); });

  // przygotuj wideo na t=0 i odpal odtwarzanie timeline
  await prepareVideosAt(0);
  renderFrame(0);
  octx.drawImage(previewCanvas, 0, 0, outW, outH);

  recorder.start(250);
  if(audioSrcNode) audioSrcNode.start(0);

  // używamy normalnego play() – sync z clockiem przeglądarki
  const endTime = duration;
  play();

  await new Promise(resolve=>{
    const startWall = performance.now();
    function tick(ts){
      const elapsed = (performance.now() - startWall) / 1000;
      // draw aktualny podgląd na off-canvas
      octx.fillStyle = '#000';
      octx.fillRect(0,0,outW,outH);
      octx.drawImage(previewCanvas, 0, 0, outW, outH);

      const pct = 5 + Math.min(0.94, elapsed / Math.max(0.01, duration)) * 90;
      if(Math.floor(elapsed*10)%3===0){
        setExportProgress(pct, `Nagrywam… ${Math.min(elapsed,duration).toFixed(1)}s / ${duration.toFixed(1)}s`);
      }

      if(elapsed >= endTime + 0.05 || currentTime >= endTime){
        pause();
        try{ recorder.stop(); }catch(e){}
        resolve();
        return;
      }
      requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  });

  await stopped;
  stream.getTracks().forEach(t=> t.stop());
  if(audioCtx) try{ await audioCtx.close(); }catch(e){}

  // przywróć dźwięk wideo
  mediaLibrary.forEach(m=>{
    if(m.el && m.type==='video'){ try{ m.el.muted = false; }catch(e){} }
  });

  currentTime = 0;
  renderFrame(0);
  if(wasPlaying) play();

  const blob = new Blob(chunks, { type: mime.split(';')[0] || 'video/webm' });
  return blob;
}

/** Ustawia currentTime wszystkich aktywnych wideo na daną chwilę timeline */
async function prepareVideosAt(t){
  const promises = [];
  visualTracks().forEach(track=>{
    activeClipsOnTrack(track, t).forEach(clip=>{
      if(clip.type!=='video') return;
      const media = getMediaById(clip.mediaId);
      if(!media || !media.el) return;
      const speed = clip.speed || 1;
      const srcTime = Math.max(0, clip.sourceIn + (t - clip.start) * speed);
      promises.push(seekVideoPrecise(media.el, srcTime));
    });
  });
  await Promise.all(promises);
}

/** Klasyczny eksport klatka-po-klatce (dokładniejszy, wolniejszy) – JPEG + ultrafast */
async function exportFrameByFrame(duration, fps, outW, outH){
  if(!window.ffmpegEngine){
    setExportProgress(1, 'Ładuję silnik eksportu (jednorazowo)...');
    await new Promise(res=>{
      if(window.ffmpegEngine) return res();
      window.addEventListener('ffmpeg-ready', res, {once:true});
    });
  }
  await window.ffmpegEngine.ensureLoaded((p)=>{
    if(p.phase==='loading') setExportProgress(2, 'Ładuję silnik ffmpeg (jednorazowo, ~30MB)...');
  });
  await window.ffmpegEngine.resetSession();

  const totalFrames = Math.max(1, Math.ceil(duration*fps));

  setExportProgress(4, 'Miksuję dźwięk ze wszystkich ścieżek...');
  const mixedBuffer = await mixdownAudio(duration, (p)=> setExportProgress(4+p*8, 'Miksuję dźwięk ze wszystkich ścieżek...'));
  let audioBlob = null;
  if(mixedBuffer){
    audioBlob = audioBufferToWavBlob(mixedBuffer);
    await window.ffmpegEngine.writeAudio(audioBlob);
  }

  // równoległe seeki + JPEG zamiast PNG = dużo szybciej
  for(let i=0;i<totalFrames;i++){
    const t = i/fps;
    const blob = await captureFrameAt(t, 'image/jpeg', 0.92);
    await window.ffmpegEngine.writeFrame(i, blob, 'jpg');
    const pct = 12 + (i/totalFrames)*68;
    if(i%3===0) setExportProgress(pct, `Renderuję klatki…`);
  }

  setExportProgress(82, 'Koduję wideo (ffmpeg, ultrafast)...');
  const videoBlob = await window.ffmpegEngine.encode(fps, !!audioBlob, {
    quality: exportQuality, width: outW, height: outH, bitrate: exportBitrate
  });
  return videoBlob;
}

document.getElementById('exportStartBtn').onclick = async ()=>{
  document.getElementById('exportSetupView').style.display = 'none';
  document.getElementById('exportProgressView').style.display = 'block';
  const wasPlaying = isPlaying;
  pause();

  try{
    const fps = exportFps || project.fps || 30;
    const { w: outW, h: outH } = computeExportResolution();
    const duration = projectDuration();

    // ZAWSZE szybki tryb real-time (~1× czas trwania montażu).
    // Fallback na klatki tylko gdy MediaRecorder nie działa.
    let videoBlob;
    setExportProgress(2, 'Przygotowuję szybki eksport…');
    try{
      videoBlob = await exportRealtime(duration, fps, outW, outH, exportBitrate);
    }catch(rtErr){
      console.warn('Realtime failed, fallback to frames:', rtErr);
      setExportProgress(5, 'Realtime niedostępny – przełączam na klatki…');
      videoBlob = await exportFrameByFrame(duration, fps, outW, outH);
    }

    setExportProgress(98, 'Gotowe, zapisuję plik…');
    const ext = (videoBlob.type||'').includes('webm') ? 'webm' : 'mp4';
    const url = URL.createObjectURL(videoBlob);
    const a = document.createElement('a');
    a.href = url; a.download = 'moj-montaz.'+ext;
    a.click();
    setTimeout(()=>URL.revokeObjectURL(url), 4000);

    setExportProgress(100, '✅ Gotowe! Plik został pobrany.');
    setTimeout(()=>{ exportModal.style.display='none'; }, 1500);
  }catch(err){
    setExportProgress(0, '❌ Błąd eksportu: '+(err.message||err));
    console.error(err);
  } finally {
    if(wasPlaying) play();
  }
};

// ---------- SUWAK SZEROKOŚCI BIBLIOTEKI ----------
(function setupMediaResize(){
  const handle = document.getElementById('mediaResizeHandle');
  if(!handle) return;
  let dragging = false, startX = 0, startW = 240;
  handle.addEventListener('pointerdown', (e)=>{
    dragging = true;
    startX = e.clientX;
    startW = workspaceSettings.mediaWidth || 240;
    handle.classList.add('dragging');
    handle.setPointerCapture(e.pointerId);
    e.preventDefault();
  });
  handle.addEventListener('pointermove', (e)=>{
    if(!dragging) return;
    const dx = e.clientX - startX;
    let w = Math.max(160, Math.min(480, startW + dx));
    workspaceSettings.mediaWidth = w;
    document.documentElement.style.setProperty('--media-w', w+'px');
  });
  handle.addEventListener('pointerup', ()=>{
    if(!dragging) return;
    dragging = false;
    handle.classList.remove('dragging');
    saveWorkspaceSettings();
  });
})();

// ---------- EFEKTY / PRZEJŚCIA / ANIMACJE (panel lewy) ----------
const TRANSITION_PRESETS = [
  { id:'none', name:'Brak', ico:'➖' },
  { id:'crossfade', name:'Przenikanie', ico:'🌫️' },
  { id:'fadeblack', name:'Przez czerń', ico:'⬛' },
  { id:'fadewhite', name:'Przez biel', ico:'⬜' },
  { id:'slideleft', name:'Wjazd ←', ico:'⬅️' },
  { id:'slideright', name:'Wjazd →', ico:'➡️' },
  { id:'slideup', name:'Wjazd ↑', ico:'⬆️' },
  { id:'zoom', name:'Zoom', ico:'🔍' },
];
const ANIMATION_PRESETS = [
  { id:'none', name:'Brak', ico:'➖' },
  { id:'pop', name:'Powiększenie', ico:'💥' },
  { id:'slideup', name:'Wjazd z dołu', ico:'🔼' },
  { id:'fadein', name:'Pojawienie', ico:'✨' },
  { id:'zoomin', name:'Zoom in', ico:'🔎' },
  { id:'shake', name:'Wstrząs', ico:'📳' },
];

function selectedClipsList(){
  if(selectedClipIds.size > 0){
    return [...selectedClipIds].map(id=>getClipById(id)).filter(Boolean).map(f=>f.clip);
  }
  if(selectedClipId){
    const f = getClipById(selectedClipId);
    return f ? [f.clip] : [];
  }
  return [];
}

function renderToolsPanel(tool){
  const panel = document.getElementById('toolsPanel');
  const list = document.getElementById('mediaList');
  const importBtn = document.getElementById('importBtn');
  if(tool === 'media'){
    panel.style.display = 'none';
    list.classList.remove('hidden-by-tool');
    importBtn.classList.remove('hidden-by-tool');
    return;
  }
  list.classList.add('hidden-by-tool');
  importBtn.classList.add('hidden-by-tool');
  panel.style.display = 'block';

  if(tool === 'effects'){
    const presets = Object.keys(CLIP_FILTER_PRESETS);
    panel.innerHTML = `
      <p class="tool-hint">Kliknij efekt, żeby zastosować na <b>zaznaczonym</b> klipie wideo/obrazie. Zaznacz klip na osi czasu.</p>
      <div class="tool-grid" id="effectsGrid"></div>`;
    const grid = panel.querySelector('#effectsGrid');
    presets.forEach(key=>{
      const card = document.createElement('div');
      card.className = 'tool-card';
      card.innerHTML = `<span class="ico">🎨</span>${key}`;
      card.onclick = ()=>{
        const clips = selectedClipsList().filter(c=>c.type==='video'||c.type==='image');
        if(!clips.length){ alert('Zaznacz najpierw klip wideo lub obraz na osi czasu.'); return; }
        clips.forEach(c=>{
          if(!c.filters) c.filters = {...DEFAULT_FILTERS};
          Object.assign(c.filters, CLIP_FILTER_PRESETS[key]);
        });
        renderFrame(currentTime); renderProps(); pushHistory();
      };
      grid.appendChild(card);
    });
    return;
  }

  if(tool === 'transitions'){
    panel.innerHTML = `
      <p class="tool-hint">Przejście między klipami: zaznacz klip i wybierz efekt. Nakładające się klipy = crossfade automatyczny. Czas przejścia: <b id="trDurLbl">0.5s</b></p>
      <input type="range" id="trDur" min="0.1" max="2" step="0.1" value="0.5" style="width:100%; margin-bottom:10px;">
      <div class="tool-grid" id="trGrid"></div>`;
    const dur = panel.querySelector('#trDur');
    dur.oninput = ()=>{ panel.querySelector('#trDurLbl').textContent = (+dur.value).toFixed(1)+'s'; };
    const grid = panel.querySelector('#trGrid');
    TRANSITION_PRESETS.forEach(tr=>{
      const card = document.createElement('div');
      card.className = 'tool-card';
      card.innerHTML = `<span class="ico">${tr.ico}</span>${tr.name}`;
      card.onclick = ()=>{
        const clips = selectedClipsList().filter(c=>c.type==='video'||c.type==='image'||c.type==='text');
        if(!clips.length){ alert('Zaznacz klip na osi czasu.'); return; }
        const d = +document.getElementById('trDur').value;
        clips.forEach(c=>{
          c.transition = tr.id;
          c.transitionDur = d;
          if(tr.id === 'crossfade' || tr.id === 'fadeblack' || tr.id === 'fadewhite'){
            c.fadeIn = d; c.fadeOut = d;
          } else if(tr.id === 'none'){
            c.fadeIn = 0; c.fadeOut = 0;
          } else {
            c.fadeIn = d; c.fadeOut = 0;
          }
        });
        renderFrame(currentTime); renderProps(); pushHistory();
      };
      grid.appendChild(card);
    });
    return;
  }

  if(tool === 'animations'){
    panel.innerHTML = `
      <p class="tool-hint">Animacja wejścia dla zaznaczonych klipów (tekst / wideo).</p>
      <div class="tool-grid" id="anGrid"></div>`;
    const grid = panel.querySelector('#anGrid');
    ANIMATION_PRESETS.forEach(an=>{
      const card = document.createElement('div');
      card.className = 'tool-card';
      card.innerHTML = `<span class="ico">${an.ico}</span>${an.name}`;
      card.onclick = ()=>{
        const clips = selectedClipsList();
        if(!clips.length){ alert('Zaznacz klip na osi czasu.'); return; }
        clips.forEach(c=>{
          c.animation = an.id;
          if(an.id === 'fadein'){ c.fadeIn = Math.max(c.fadeIn||0, 0.4); }
          if(an.id === 'none'){ /* leave fades */ }
        });
        renderFrame(currentTime); renderProps(); pushHistory();
      };
      grid.appendChild(card);
    });
  }
}

document.querySelectorAll('#toolsStrip .tool-tab').forEach(btn=>{
  btn.onclick = ()=>{
    document.querySelectorAll('#toolsStrip .tool-tab').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    renderToolsPanel(btn.dataset.tool);
  };
});

// rozszerzone animacje w drawTextClip / drawVisualClip
const _origDrawVisualClip = drawVisualClip;
drawVisualClip = function(clip, t, alpha){
  // animacje wideo
  if(clip.type !== 'text' && clip.animation && clip.animation !== 'none'){
    const localElapsed = t - clip.start;
    const animDur = 0.45;
    const p = Math.max(0, Math.min(1, localElapsed / animDur));
    pctx.save();
    if(clip.animation === 'zoomin'){
      const s = 0.7 + 0.3 * p;
      const cw = previewCanvas.width, ch = previewCanvas.height;
      pctx.translate(cw/2, ch/2);
      pctx.scale(s, s);
      pctx.translate(-cw/2, -ch/2);
    } else if(clip.animation === 'slideup'){
      pctx.translate(0, (1-p) * previewCanvas.height * 0.15);
    } else if(clip.animation === 'shake' && p < 1){
      pctx.translate((Math.random()-0.5)*8, (Math.random()-0.5)*8);
    }
    _origDrawVisualClip(clip, t, alpha);
    pctx.restore();
    return;
  }
  _origDrawVisualClip(clip, t, alpha);
};

// przejścia fadeblack / fadewhite / slide w renderFrame — proste overlay
const _origRenderFrame = renderFrame;
renderFrame = function(t){
  _origRenderFrame(t);
  // overlay przejść na aktywnych klipach
  visualTracks().forEach(track=>{
    activeClipsOnTrack(track, t).forEach(clip=>{
      if(!clip.transition || clip.transition === 'none' || clip.transition === 'crossfade') return;
      const local = t - clip.start;
      const td = clip.transitionDur || 0.5;
      if(local > td) return;
      const p = 1 - (local / td); // 1 na starcie → 0
      if(clip.transition === 'fadeblack'){
        pctx.fillStyle = `rgba(0,0,0,${p})`;
        pctx.fillRect(0,0,previewCanvas.width, previewCanvas.height);
      } else if(clip.transition === 'fadewhite'){
        pctx.fillStyle = `rgba(255,255,255,${p})`;
        pctx.fillRect(0,0,previewCanvas.width, previewCanvas.height);
      }
    });
  });
};

// ---------- INIT ----------

function init(){
  loadWorkspaceSettings();
  // start od menu głównego z listą projektów
  showHome();
}
init();
