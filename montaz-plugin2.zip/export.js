// ============================================================
// MODUŁ EKSPORTU WIDEO (ffmpeg.wasm, 100% lokalnie)
// + konwersja GIF → MP4 oraz szybki zapis klatek JPEG.
// ============================================================
import { FFmpeg } from './lib/ffmpeg/index.js';
import { toBlobURL } from './lib/ffmpeg-util/index.js';

let ffmpeg = null;
let loaded = false;
let frameCount = 0;
let frameExt = 'jpg'; // jpg jest ~10x mniejszy i szybszy niż png

async function ensureLoaded(onProgress){
  if(loaded) return;
  ffmpeg = new FFmpeg();
  ffmpeg.on('log', ({message})=>{ /* debug */ });
  ffmpeg.on('progress', ({progress})=>{
    if(onProgress) onProgress({ phase:'encode', progress: Math.max(0,Math.min(1,progress)) });
  });
  const baseURL = './lib/ffmpeg-core';
  if(onProgress) onProgress({ phase:'loading', progress:0 });
  await ffmpeg.load({
    coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
    wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
  });
  loaded = true;
}

async function resetSession(){
  frameCount = 0;
  frameExt = 'jpg';
}

async function writeFrame(index, blob, ext){
  if(ext) frameExt = ext;
  const name = `frame_${String(index).padStart(6,'0')}.${frameExt}`;
  const buf = new Uint8Array(await blob.arrayBuffer());
  await ffmpeg.writeFile(name, buf);
  frameCount = Math.max(frameCount, index+1);
}

async function writeAudio(wavBlob){
  const buf = new Uint8Array(await wavBlob.arrayBuffer());
  await ffmpeg.writeFile('audio.wav', buf);
}

async function encode(fps, hasAudio, opts){
  opts = opts || {};
  const quality = opts.quality || 'srednia';
  // ultrafast / veryfast = dużo szybsze kodowanie (klucz do 10s ≈ 10s)
  const preset = quality==='wysoka' ? 'fast' : quality==='niska' ? 'ultrafast' : 'ultrafast';
  const inputPattern = `frame_%06d.${frameExt}`;
  const args = ['-framerate', String(fps), '-i', inputPattern];
  if(hasAudio) args.push('-i', 'audio.wav');
  args.push('-c:v','libx264','-pix_fmt','yuv420p','-preset',preset);
  if(opts.width && opts.height){
    args.push('-vf', `scale=${opts.width}:${opts.height}`);
  }
  if(opts.bitrate){
    args.push('-b:v', `${opts.bitrate}k`, '-maxrate', `${opts.bitrate}k`, '-bufsize', `${opts.bitrate*2}k`);
  } else {
    args.push('-crf', quality==='wysoka'?'18':quality==='niska'?'28':'23');
  }
  if(hasAudio) args.push('-c:a','aac','-b:a','192k','-shortest');
  args.push('-movflags','+faststart','-y','output.mp4');
  await ffmpeg.exec(args);
  const data = await ffmpeg.readFile('output.mp4');
  const blob = new Blob([data.buffer], {type:'video/mp4'});
  try{
    for(let i=0;i<frameCount;i++){
      await ffmpeg.deleteFile(`frame_${String(i).padStart(6,'0')}.${frameExt}`).catch(()=>{});
    }
    if(hasAudio) await ffmpeg.deleteFile('audio.wav').catch(()=>{});
    await ffmpeg.deleteFile('output.mp4').catch(()=>{});
  }catch(e){}
  return blob;
}

/** Konwertuje plik GIF (lub inny obraz animowany) na MP4, zwraca Blob video/mp4 */
async function convertGifToMp4(gifBlob, onProgress){
  await ensureLoaded(onProgress);
  const inName = 'input.gif';
  const outName = 'gif_out.mp4';
  const buf = new Uint8Array(await gifBlob.arrayBuffer());
  await ffmpeg.writeFile(inName, buf);
  // -ignore_loop 0 = odtwórz całą animację; -movflags +faststart
  await ffmpeg.exec([
    '-i', inName,
    '-movflags', '+faststart',
    '-pix_fmt', 'yuv420p',
    '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
    '-c:v', 'libx264',
    '-preset', 'ultrafast',
    '-crf', '20',
    '-an',
    '-y', outName
  ]);
  const data = await ffmpeg.readFile(outName);
  const blob = new Blob([data.buffer], {type:'video/mp4'});
  try{
    await ffmpeg.deleteFile(inName).catch(()=>{});
    await ffmpeg.deleteFile(outName).catch(()=>{});
  }catch(e){}
  return blob;
}

/** Wyciąga audio z dowolnego pliku (wideo/audio) do WAV mono 16kHz — pod Whisper */
async function extractAudioToWav(mediaBlob, onProgress){
  await ensureLoaded(onProgress);
  const inName = 'media_in';
  const outName = 'audio_out.wav';
  const buf = new Uint8Array(await mediaBlob.arrayBuffer());
  await ffmpeg.writeFile(inName, buf);
  // mono 16 kHz — idealne pod Whisper
  await ffmpeg.exec([
    '-i', inName,
    '-vn',
    '-ac', '1',
    '-ar', '16000',
    '-f', 'wav',
    '-y', outName
  ]);
  const data = await ffmpeg.readFile(outName);
  const blob = new Blob([data.buffer], {type:'audio/wav'});
  try{
    await ffmpeg.deleteFile(inName).catch(()=>{});
    await ffmpeg.deleteFile(outName).catch(()=>{});
  }catch(e){}
  return blob;
}

window.ffmpegEngine = {
  ensureLoaded,
  resetSession,
  writeFrame,
  writeAudio,
  encode,
  convertGifToMp4,
  extractAudioToWav
};
window.dispatchEvent(new Event('ffmpeg-ready'));
