/* ============================================================
   MASZYNKA DO MINIATUREK — silnik edytora + generator tła
   WERSJA: 2.3.1 (naprawa: liczby przy suwakach nie odswiezaly sie na zywo - w calej apce)
   usuwanie tła, naprawione wyostrzanie, narzędzia na tekście)
   ============================================================ */
console.log('Maszynka do Miniaturek — script.js wersja 2.3.1 załadowany poprawnie');

// ---------- STAN GŁÓWNY ----------
let canvasW = 1280, canvasH = 720;

const PALETTES = [
  ['#7c5cff','#00d1a0','#ff5c7a','#ffd166'],
  ['#ff6b6b','#f7d774','#7cf7c1','#6b8cff'],
  ['#0f2027','#2c5364','#00d1a0','#7c5cff'],
  ['#ff9a8b','#ff6a88','#ff99ac','#fecfef'],
  ['#1e3c72','#2a5298','#00d1a0','#7c5cff'],
  ['#f857a6','#ff5858','#ffd166','#7c5cff'],
  ['#232526','#414345','#7c5cff','#00d1a0'],
  ['#11998e','#38ef7d','#00d1a0','#7c5cff']
];
function randomPalette(){ return PALETTES[Math.floor(Math.random()*PALETTES.length)]; }

function makeJagSeed(n){
  const arr = [];
  for(let i=0;i<n;i++) arr.push((Math.random()*2-1));
  arr[0]=0; arr[n-1]=0; // gorne/dolne krawedzie bez zabkow, zeby nie wychodzilo poza canvas
  return arr;
}

let bg = {
  base: 'linear',
  solidColor: '#7c5cff',
  linear: { angle: 135, stops: [{c:'#7c5cff',p:0},{c:'#00d1a0',p:1}] },
  radial: { cx:50, cy:50, r:75, stops:[{c:'#7c5cff',p:0},{c:'#160f2e',p:1}] },
  mesh: { baseColor:'#0f0b23', blur:55, blobs: randomBlobs() },
  split: {
    angle: 8, jag: 35, jagSeed: makeJagSeed(9),
    color1:'#1f6fee', color2:'#e51c27',
    seamColor:'#ffffff', seamWidth:16,
    rays: { enabled:true, opacity:22, count:16, useCustomColors:false, color1:'#5b9dff', color2:'#ff6b6b' },
    watermark: { enabled:true, icon:'💀', size:90, spacing:170, rotation:-15, opacity:10, customSrc:null, customImg:null }
  },
  image: { src:null, img:null, offsetX:50, offsetY:50, scale:100, blurBg:0, brightness:100, contrast:100, saturate:100, hueRotate:0 },
  rays: {
    centerColor:'#8CFF6B', edgeColor:'#0b5e1f', lineColor:'#0a4016', lineOpacity:45,
    count:46, minLen:35, maxLen:150, minThick:2, maxThick:26, innerGap:12,
    focalX:50, focalY:50, glow:60, lineGlow:0, seedOpts:null, seed: makeRaySeed(46)
  },
  pattern: { type:'none', color:'#ffffff', opacity:20, size:24, angle:0 }
};

let effects = { vignette:0, grain:0, brightness:100, contrast:100, saturate:100 };

let layers = []; // {id,type,...}
let selectedId = null;
let layerCounter = 0;

let history = [];
let historyIndex = -1;
let suppressHistory = false;

let currentTab = 'bg';

let noiseTileCanvas = null; // cache for grain

// ---------- DOM ----------
const mainCanvas = document.getElementById('mainCanvas');
const ctx = mainCanvas.getContext('2d');
const stage = document.getElementById('stage');
const canvasWrap = document.getElementById('canvasWrap');
const toolpanel = document.getElementById('toolpanel');
// NAPRAWA: liczby obok suwakow (np. "Obrot odcienia 0°") w wielu panelach nie odswiezaly sie
// na zywo podczas przeciagania - sam EFEKT na plotnie dzialal poprawnie, ale wyswietlana wartosc
// zostawala "zamrozona" az do pelnego przerysowania panelu. Ten jeden, globalny listener (delegacja
// zdarzen) naprawia to dla KAZDEGO suwaka w calej aplikacji na raz: przy kazdym ruchu suwaka aktualizuje
// tekst w sasiadujacym <span> wewnatrz <label>, zachowujac istniejacy sufiks (%, px, ° itd.).
toolpanel.addEventListener('input', (e)=>{
  const t = e.target;
  if(t.tagName==='INPUT' && t.type==='range'){
    const label = t.previousElementSibling;
    const span = label && label.tagName==='LABEL' ? label.querySelector('span') : null;
    if(span){
      const suffixMatch = span.textContent.match(/[^0-9.\-]+$/);
      span.textContent = t.value + (suffixMatch ? suffixMatch[0] : '');
    }
  }
});
const layerListEl = document.getElementById('layerList');
const fileInput = document.getElementById('fileInput');
const projectInput = document.getElementById('projectInput');

function uid(){ return 'L' + (++layerCounter) + '_' + Math.random().toString(36).slice(2,7); }

function randomBlobs(){
  const palette = randomPalette();
  const blobs = [];
  const n = 4;
  for(let i=0;i<n;i++){
    blobs.push({
      x: 15 + Math.random()*70,
      y: 15 + Math.random()*70,
      r: 30 + Math.random()*30,
      color: palette[i % palette.length],
      opacity: 55 + Math.random()*35
    });
  }
  return blobs;
}

// ---------- ROZMIAR CANVASU / DOPASOWANIE DO WIDOKU ----------
function setCanvasSize(w,h){
  canvasW = w; canvasH = h;
  mainCanvas.width = w;
  mainCanvas.height = h;
  fitStageToView();
  render();
}

function fitStageToView(){
  const availW = canvasWrap.clientWidth - 60;
  const availH = canvasWrap.clientHeight - 60;
  const scale = Math.min(availW / canvasW, availH / canvasH, 1.5);
  mainCanvas.style.width = (canvasW*scale) + 'px';
  mainCanvas.style.height = (canvasH*scale) + 'px';
  stage.style.width = (canvasW*scale) + 'px';
  stage.style.height = (canvasH*scale) + 'px';
}
window.addEventListener('resize', fitStageToView);

// ---------- TŁO: RYSOWANIE ----------
function hexToRgba(hex, alphaPct){
  const a = (alphaPct===undefined) ? 1 : Math.max(0,Math.min(100,alphaPct))/100;
  let h = hex.replace('#','');
  if(h.length===3) h = h.split('').map(c=>c+c).join('');
  const r = parseInt(h.substr(0,2),16), g = parseInt(h.substr(2,2),16), b = parseInt(h.substr(4,2),16);
  return `rgba(${r},${g},${b},${a})`;
}

function drawBackground(c, w, h){
  c.save();
  if(bg.base === 'solid'){
    c.fillStyle = bg.solidColor;
    c.fillRect(0,0,w,h);
  } else if(bg.base === 'linear'){
    const angle = (bg.linear.angle||0) * Math.PI/180;
    const x0 = w/2 - Math.cos(angle)*w, y0 = h/2 - Math.sin(angle)*h;
    const x1 = w/2 + Math.cos(angle)*w, y1 = h/2 + Math.sin(angle)*h;
    const grad = c.createLinearGradient(x0,y0,x1,y1);
    bg.linear.stops.forEach(s=> grad.addColorStop(Math.max(0,Math.min(1,s.p)), s.c));
    c.fillStyle = grad;
    c.fillRect(0,0,w,h);
  } else if(bg.base === 'radial'){
    const cx = w*(bg.radial.cx/100), cy = h*(bg.radial.cy/100);
    const r = Math.max(w,h)*(bg.radial.r/100);
    const grad = c.createRadialGradient(cx,cy,0,cx,cy,r);
    bg.radial.stops.forEach(s=> grad.addColorStop(Math.max(0,Math.min(1,s.p)), s.c));
    c.fillStyle = grad;
    c.fillRect(0,0,w,h);
  } else if(bg.base === 'mesh'){
    c.fillStyle = bg.mesh.baseColor;
    c.fillRect(0,0,w,h);
    const off = document.createElement('canvas');
    off.width = w; off.height = h;
    const octx = off.getContext('2d');
    bg.mesh.blobs.forEach(b=>{
      const bx = w*(b.x/100), by = h*(b.y/100), br = Math.max(w,h)*(b.r/100);
      const grad = octx.createRadialGradient(bx,by,0,bx,by,br);
      grad.addColorStop(0, hexToRgba(b.color, b.opacity));
      grad.addColorStop(1, hexToRgba(b.color, 0));
      octx.fillStyle = grad;
      octx.fillRect(0,0,w,h);
    });
    c.filter = `blur(${bg.mesh.blur*0.6}px)`;
    c.drawImage(off,0,0);
    c.filter = 'none';
  } else if(bg.base === 'split'){
    drawSplitBackground(c,w,h);
  } else if(bg.base === 'image'){
    drawImageBackground(c,w,h);
  } else if(bg.base === 'rays'){
    drawRaysBackground(c,w,h);
  }
  c.restore();

  drawPatternOverlay(c,w,h);
}

// ---------- TŁO: PROMIENIE (autentyczne, nierowne "manga speed lines") ----------
function makeRaySeed(n, opts){
  opts = opts || {};
  const clusterMin = opts.clusterMin || 2;
  const clusterMax = opts.clusterMax || 4;
  const windows = opts.windows || [[0, Math.PI*2]]; // zakresy katow (radiany) skad losujemy klastry; domyslnie pelne kolo
  const clusterSpread = opts.clusterSpread!==undefined ? opts.clusterSpread : 0.09; // jak blisko siebie sa linie w jednym klastrze
  const arr = [];
  while(arr.length < n){
    const win = windows[Math.floor(Math.random()*windows.length)];
    const baseAngle = win[0] + Math.random()*(win[1]-win[0]);
    const clusterSize = clusterMin + Math.floor(Math.random()*(clusterMax-clusterMin+1));
    for(let i=0; i<clusterSize && arr.length<n; i++){
      arr.push({
        a: baseAngle + (Math.random()-0.5)*clusterSpread*2,
        l: 0.3 + Math.random()*0.7,
        t: Math.pow(Math.random(), 2.3)
      });
    }
  }
  return arr;
}

function drawRaysBackground(c,w,h){
  const rb = bg.rays;
  const fx = w*(rb.focalX/100), fy = h*(rb.focalY/100);
  const maxR = Math.sqrt(w*w+h*h)*0.62;
  const innerGap = maxR * ((rb.innerGap||0)/100);

  const grad = c.createRadialGradient(fx,fy,0, fx,fy, maxR);
  grad.addColorStop(0, rb.centerColor);
  grad.addColorStop(1, rb.edgeColor);
  c.fillStyle = grad;
  c.fillRect(0,0,w,h);

  const drawShards = ()=>{
    c.fillStyle = rb.lineColor;
    rb.seed.forEach(s=>{
      const lenFactor = rb.minLen + s.l*(rb.maxLen-rb.minLen);
      const len = maxR * lenFactor / 100;
      // grubosc skalowana dlugoscia - krotkie promienie NIE moga byc bardzo grube (unika "kluchow")
      const lengthRatio = Math.max(0, Math.min(1, (lenFactor-rb.minLen)/Math.max(1,(rb.maxLen-rb.minLen))));
      const thick = rb.minThick + s.t*(rb.maxThick-rb.minThick) * (0.35 + 0.65*lengthRatio);
      const dx = Math.cos(s.a), dy = Math.sin(s.a);
      const px = -dy, py = dx;
      const innerX = fx+dx*innerGap, innerY = fy+dy*innerGap;
      const outerX = fx+dx*(innerGap+len), outerY = fy+dy*(innerGap+len);
      const halfT = thick/2;
      c.beginPath();
      c.moveTo(innerX, innerY);
      c.lineTo(outerX+px*halfT, outerY+py*halfT);
      c.lineTo(outerX-px*halfT, outerY-py*halfT);
      c.closePath();
      c.fill();
    });
  };

  // Miekka poswiata KAZDEJ linii z osobna (nie tylko centralny blask) - to jest to, czego brakowalo
  // zeby cienkie, neonowe streaki (jak w Twoim fioletowym/niebieskim referencyjnym tle) wygladaly
  // "swiecąco" a nie jak plaskie, twarde trojkaty.
  if(rb.lineGlow>0){
    c.save();
    c.globalAlpha = (rb.lineOpacity/100) * (rb.lineGlow/100) * 0.9;
    c.filter = `blur(${Math.max(2, rb.maxThick*0.9)}px)`;
    drawShards();
    c.restore();
  }

  c.save();
  c.globalAlpha = rb.lineOpacity/100;
  drawShards();
  c.restore();

  if(rb.glow>0){
    const glowR = maxR*0.18*(rb.glow/100);
    const gg = c.createRadialGradient(fx,fy,0, fx,fy, Math.max(4,glowR));
    gg.addColorStop(0,'rgba(255,255,255,0.95)');
    gg.addColorStop(0.35,'rgba(255,255,255,0.45)');
    gg.addColorStop(1,'rgba(255,255,255,0)');
    c.fillStyle = gg;
    c.beginPath(); c.arc(fx,fy,Math.max(4,glowR),0,Math.PI*2); c.fill();
  }
}

function drawImageBackground(c,w,h){
  const bi = bg.image;
  if(!bi.img){ c.fillStyle = '#14161d'; c.fillRect(0,0,w,h); return; }
  const img = bi.img;
  const coverScale = Math.max(w/img.width, h/img.height) * (bi.scale/100);
  const drawW = img.width*coverScale, drawH = img.height*coverScale;
  // offsetX/offsetY 0-100, 50=wysrodkowane; poza 0-100 pozwala "wypchnac" obraz poza kadr
  const cx = (bi.offsetX/100)*w;
  const cy = (bi.offsetY/100)*h;
  c.save();
  const filters = [];
  if(bi.blurBg>0) filters.push(`blur(${bi.blurBg}px)`);
  filters.push(`brightness(${bi.brightness}%)`, `contrast(${bi.contrast}%)`, `saturate(${bi.saturate}%)`, `hue-rotate(${bi.hueRotate}deg)`);
  c.filter = filters.join(' ');
  c.drawImage(img, cx-drawW/2, cy-drawH/2, drawW, drawH);
  c.restore();
}

function getSeamPoints(w,h){
  const s = bg.split;
  const seed = s.jagSeed;
  const n = seed.length;
  const pts = [];
  for(let i=0;i<n;i++){
    const t = i/(n-1);
    const y = t*h;
    const baseX = w/2 + (y-h/2)*Math.tan(s.angle*Math.PI/180);
    pts.push({ x: baseX + seed[i]*s.jag, y });
  }
  return pts;
}

function drawSplitBackground(c,w,h){
  const s = bg.split;
  const pts = getSeamPoints(w,h);

  // lewa strefa
  c.save();
  c.beginPath();
  c.moveTo(0,0);
  pts.forEach(p=>c.lineTo(p.x,p.y));
  c.lineTo(0,h);
  c.closePath();
  c.clip();
  c.fillStyle = s.color1;
  c.fillRect(0,0,w,h);
  if(s.rays.enabled) drawSpeedRays(c,w,h,pts, -1, s.rays.useCustomColors? s.rays.color1 : lightenColor(s.color1,45));
  c.restore();

  // prawa strefa
  c.save();
  c.beginPath();
  c.moveTo(w,0);
  pts.forEach(p=>c.lineTo(p.x,p.y));
  c.lineTo(w,h);
  c.closePath();
  c.clip();
  c.fillStyle = s.color2;
  c.fillRect(0,0,w,h);
  if(s.rays.enabled) drawSpeedRays(c,w,h,pts, 1, s.rays.useCustomColors? s.rays.color2 : lightenColor(s.color2,45));
  c.restore();

  // biala "blyskawica" na styku
  if(s.seamWidth>0){
    c.save();
    c.beginPath();
    c.moveTo(pts[0].x,pts[0].y);
    pts.slice(1).forEach(p=>c.lineTo(p.x,p.y));
    c.strokeStyle = s.seamColor;
    c.lineWidth = s.seamWidth;
    c.lineJoin = 'miter';
    c.miterLimit = 4;
    c.stroke();
    c.restore();
  }

  // wzorek w tle (naklejki w tle, np. czaszki)
  if(s.watermark.enabled) drawWatermarkTile(c,w,h);
}

function lightenColor(hex, amt){
  let h = hex.replace('#','');
  if(h.length===3) h = h.split('').map(ch=>ch+ch).join('');
  const r = Math.min(255, parseInt(h.substr(0,2),16) + amt*2.2);
  const g = Math.min(255, parseInt(h.substr(2,2),16) + amt*2.2);
  const b = Math.min(255, parseInt(h.substr(4,2),16) + amt*2.2);
  return `rgb(${r|0},${g|0},${b|0})`;
}

function drawSpeedRays(c,w,h,pts, dirSign, color){
  const rays = bg.split.rays;
  const seed = bg.split.jagSeed;
  const focalY = h/2;
  const seamAtMid = w/2 + (0)*Math.tan(bg.split.angle*Math.PI/180);
  c.save();
  c.globalAlpha = rays.opacity/100;
  c.strokeStyle = color;
  const count = rays.count;
  const maxLen = Math.max(w,h)*1.4;
  for(let i=0;i<count;i++){
    const t = i/(count-1);
    const spread = Math.PI*0.85;
    const angle = (t-0.5)*spread;
    const len = maxLen*(0.5 + 0.5*Math.abs(Math.sin((seed[i%seed.length]||0.3)*10)));
    const thick = 2 + Math.abs(seed[(i+2)%seed.length]||0.4)*10;
    const dx = Math.cos(angle)*dirSign;
    const dy = Math.sin(angle);
    c.beginPath();
    c.moveTo(seamAtMid, focalY);
    c.lineTo(seamAtMid + dx*len, focalY + dy*len);
    c.lineWidth = thick;
    c.stroke();
  }
  c.restore();
}

function drawWatermarkTile(c,w,h){
  const wm = bg.split.watermark;
  c.save();
  c.globalAlpha = wm.opacity/100;
  const step = Math.max(40, wm.spacing);
  const diag = Math.sqrt(w*w+h*h);
  for(let y=-diag*0.3; y<h+diag*0.3; y+=step){
    for(let x=-diag*0.3; x<w+diag*0.3; x+=step){
      c.save();
      c.translate(x,y);
      c.rotate(wm.rotation*Math.PI/180);
      if(wm.customImg){
        c.drawImage(wm.customImg, -wm.size/2, -wm.size/2, wm.size, wm.size);
      } else {
        c.font = `${wm.size}px "Segoe UI Emoji", sans-serif`;
        c.textAlign = 'center';
        c.textBaseline = 'middle';
        c.fillText(wm.icon, 0, 0);
      }
      c.restore();
    }
  }
  c.restore();
}

// Prosty deterministyczny "hash losowy" (0..1) na podstawie dwóch liczb calkowitych - do gwiazdek,
// zeby ich rozmieszczenie bylo stale miedzy kolejnymi renderami (bez migotania jak przy Math.random()).
function hashRand(i,j){
  const x = Math.sin(i*12.9898 + j*78.233) * 43758.5453;
  return x - Math.floor(x);
}
function drawSparkleStar(ctx,cx,cy,r){
  ctx.beginPath();
  ctx.moveTo(cx, cy-r);
  ctx.quadraticCurveTo(cx+r*0.15, cy-r*0.15, cx+r, cy);
  ctx.quadraticCurveTo(cx+r*0.15, cy+r*0.15, cx, cy+r);
  ctx.quadraticCurveTo(cx-r*0.15, cy+r*0.15, cx-r, cy);
  ctx.quadraticCurveTo(cx-r*0.15, cy-r*0.15, cx, cy-r);
  ctx.closePath();
  ctx.fill();
}

function drawPatternOverlay(c,w,h){
  const p = bg.pattern;
  if(!p || p.type==='none' || p.opacity<=0) return;
  c.save();
  c.globalAlpha = p.opacity/100;
  if(p.type === 'noise'){
    c.drawImage(getNoiseTile(p.color), 0, 0, w, h);
  } else {
    const off = document.createElement('canvas');
    off.width = w; off.height = h;
    const octx = off.getContext('2d');
    octx.strokeStyle = p.color;
    octx.fillStyle = p.color;
    octx.lineWidth = Math.max(1, p.size/12);
    octx.translate(w/2,h/2);
    octx.rotate(p.angle*Math.PI/180);
    octx.translate(-w/2,-h/2);
    const step = Math.max(6, p.size);
    const diag = Math.sqrt(w*w+h*h);
    if(p.type === 'dots'){
      for(let y=-diag; y<diag; y+=step){
        for(let x=-diag; x<diag; x+=step){
          octx.beginPath();
          octx.arc(x,y, Math.max(1,step*0.12), 0, Math.PI*2);
          octx.fill();
        }
      }
    } else if(p.type === 'lines'){
      for(let x=-diag; x<diag*2; x+=step){
        octx.beginPath();
        octx.moveTo(x,-diag);
        octx.lineTo(x,diag*2);
        octx.stroke();
      }
    } else if(p.type === 'grid'){
      for(let x=-diag; x<diag*2; x+=step){
        octx.beginPath(); octx.moveTo(x,-diag); octx.lineTo(x,diag*2); octx.stroke();
      }
      for(let y=-diag; y<diag*2; y+=step){
        octx.beginPath(); octx.moveTo(-diag,y); octx.lineTo(diag*2,y); octx.stroke();
      }
    } else if(p.type === 'cross'){
      for(let x=-diag*2; x<diag*3; x+=step){
        octx.beginPath(); octx.moveTo(x,-diag); octx.lineTo(x+diag*3,diag*2); octx.stroke();
        octx.beginPath(); octx.moveTo(x,diag*2); octx.lineTo(x+diag*3,-diag); octx.stroke();
      }
    } else if(p.type === 'scan'){
      const lh = Math.max(2, step/6);
      for(let y=-diag; y<diag*2; y+=lh*2){
        octx.fillRect(-diag, y, diag*4, lh);
      }
    } else if(p.type === 'halftone'){
      let row = 0;
      for(let y=-diag; y<diag*2; y+=step){
        const offsetX = (row%2)*step/2;
        for(let x=-diag; x<diag*2; x+=step){
          octx.beginPath();
          octx.arc(x+offsetX,y, Math.max(1,step*0.28), 0, Math.PI*2);
          octx.fill();
        }
        row++;
      }
    } else if(p.type === 'hex'){
      const hexR = step/2;
      const hexH = hexR*Math.sqrt(3);
      let row = 0;
      for(let y=-hexH*2; y<diag*3; y+=hexH){
        const offsetX = (row%2) ? hexR*1.5 : 0;
        for(let x=-hexR*3+offsetX; x<diag*3; x+=hexR*3){
          octx.beginPath();
          for(let k=0;k<6;k++){
            const ang = Math.PI/3*k;
            const px = x+hexR*Math.cos(ang), py = y+hexR*Math.sin(ang);
            if(k===0) octx.moveTo(px,py); else octx.lineTo(px,py);
          }
          octx.closePath();
          octx.stroke();
        }
        row++;
      }
    } else if(p.type === 'rings'){
      const cx = w/2, cy = h/2;
      octx.lineWidth = Math.max(2, step*0.12);
      for(let rr=step; rr<diag*1.5; rr+=step){
        octx.beginPath();
        octx.arc(cx, cy, rr, 0, Math.PI*2);
        octx.stroke();
      }
    } else if(p.type === 'stars'){
      let gi=0;
      for(let y=-diag; y<diag*2; y+=step){
        let gj=0;
        for(let x=-diag; x<diag*2; x+=step){
          const rnd1 = hashRand(gi,gj), rnd2 = hashRand(gi+50,gj+50), rnd3 = hashRand(gi+90,gj+7);
          if(rnd1 < 0.35){
            const jx = x + (rnd2-0.5)*step*0.8;
            const jy = y + (rnd3-0.5)*step*0.8;
            const rr = step*0.16*(0.4+rnd1);
            octx.globalAlpha = 0.5+rnd2*0.5;
            drawSparkleStar(octx, jx, jy, rr);
          }
          gj++;
        }
        gi++;
      }
      octx.globalAlpha = 1;
    } else if(p.type === 'bands'){
      // Miekkie, szerokie, rozmyte "pasma" (jak w referencyjnym niebieskim tle) - zamiast
      // cienkich, twardych okregow ('rings'), tutaj kazde pasmo jest rozmyte filtrem blur.
      const cx = w/2, cy = h/2;
      const maxR = diag*0.95;
      octx.filter = `blur(${Math.max(6, step*0.5)}px)`;
      let rr = step*2.4;
      let bi = 0;
      while(rr < maxR){
        octx.lineWidth = step*1.1;
        octx.globalAlpha = 0.55;
        octx.beginPath();
        octx.arc(cx, cy, rr, 0, Math.PI*2);
        octx.stroke();
        rr += step*2.4;
        bi++;
        if(bi>6) break;
      }
      octx.filter = 'none';
      octx.globalAlpha = 1;
    }
    c.drawImage(off,0,0);
  }
  c.restore();
}

function getNoiseTile(color){
  const size = 160;
  const off = document.createElement('canvas');
  off.width = size; off.height = size;
  const octx = off.getContext('2d');
  const img = octx.createImageData(size,size);
  // parse color
  let h = color.replace('#','');
  if(h.length===3) h = h.split('').map(ch=>ch+ch).join('');
  const r = parseInt(h.substr(0,2),16), g = parseInt(h.substr(2,2),16), b = parseInt(h.substr(4,2),16);
  for(let i=0;i<img.data.length;i+=4){
    const v = Math.random();
    img.data[i]=r; img.data[i+1]=g; img.data[i+2]=b;
    img.data[i+3]= v*255;
  }
  octx.putImageData(img,0,0);
  return off;
}

// ---------- WARSTWY: RYSOWANIE ----------
function getLayerCorners(layer){
  const w = layer.w, h = layer.h;
  const rad = (layer.rotation||0) * Math.PI/180;
  const cos = Math.cos(rad), sin = Math.sin(rad);
  const pts = [[-w/2,-h/2],[w/2,-h/2],[w/2,h/2],[-w/2,h/2]];
  return pts.map(([x,y])=>({
    x: layer.x + x*cos - y*sin,
    y: layer.y + x*sin + y*cos
  }));
}

function buildAdjFilter(layer){
  const b = layer.brightness!==undefined?layer.brightness:100;
  const co = layer.contrast!==undefined?layer.contrast:100;
  const s = layer.saturate!==undefined?layer.saturate:100;
  const bl = layer.fxBlur!==undefined?layer.fxBlur:0;
  const gr = layer.fxGrayscale!==undefined?layer.fxGrayscale:0;
  const se = layer.fxSepia!==undefined?layer.fxSepia:0;
  return `brightness(${b}%) contrast(${co}%) saturate(${s}%) blur(${bl}px) grayscale(${gr}%) sepia(${se}%)`;
}

function adjControlsHtml(layer){
  const b = layer.brightness!==undefined?layer.brightness:100;
  const co = layer.contrast!==undefined?layer.contrast:100;
  const s = layer.saturate!==undefined?layer.saturate:100;
  const bl = layer.fxBlur!==undefined?layer.fxBlur:0;
  const gr = layer.fxGrayscale!==undefined?layer.fxGrayscale:0;
  const se = layer.fxSepia!==undefined?layer.fxSepia:0;
  return `
    <h3 style="margin-top:16px;">Jasność / kontrast / kolor (ten element)</h3>
    <div class="field"><label>Jasność <span>${b}%</span></label><input type="range" class="adjBrightness" min="0" max="200" value="${b}"></div>
    <div class="field"><label>Kontrast <span>${co}%</span></label><input type="range" class="adjContrast" min="0" max="200" value="${co}"></div>
    <div class="field"><label>Nasycenie <span>${s}%</span></label><input type="range" class="adjSaturate" min="0" max="200" value="${s}"></div>
    <h3 style="margin-top:16px;">Efekty z narzędzi (ten element) ✨</h3>
    <p class="hint" style="margin-top:0;">Te same efekty co dla zdjęć — teraz też na tekście, kształtach i emoji.</p>
    <div class="chip-row" style="margin-bottom:10px;">
      <button class="chip" data-adjfx="none">Brak</button>
      <button class="chip" data-adjfx="vivid">Żywe kolory</button>
      <button class="chip" data-adjfx="bw">Czarno-białe</button>
      <button class="chip" data-adjfx="warm">Ciepłe</button>
      <button class="chip" data-adjfx="cool">Chłodne</button>
    </div>
    <div class="field"><label>Rozmycie <span>${bl}px</span></label><input type="range" class="adjBlur" min="0" max="30" value="${bl}"></div>
    <div class="field"><label>Czarno-białe <span>${gr}%</span></label><input type="range" class="adjGrayscale" min="0" max="100" value="${gr}"></div>
    <div class="field"><label>Sepia <span>${se}%</span></label><input type="range" class="adjSepia" min="0" max="100" value="${se}"></div>
  `;
}
function bindAdjControls(sel){
  const upd = fn=>{ fn(); render(); };
  const b = toolpanel.querySelector('.adjBrightness'), co = toolpanel.querySelector('.adjContrast'), s = toolpanel.querySelector('.adjSaturate');
  if(b){ b.oninput=e=>upd(()=>sel.brightness=+e.target.value); b.onchange=()=>pushHistory(); }
  if(co){ co.oninput=e=>upd(()=>sel.contrast=+e.target.value); co.onchange=()=>pushHistory(); }
  if(s){ s.oninput=e=>upd(()=>sel.saturate=+e.target.value); s.onchange=()=>pushHistory(); }
  const bl = toolpanel.querySelector('.adjBlur'), gr = toolpanel.querySelector('.adjGrayscale'), se = toolpanel.querySelector('.adjSepia');
  if(bl){ bl.oninput=e=>upd(()=>sel.fxBlur=+e.target.value); bl.onchange=()=>pushHistory(); }
  if(gr){ gr.oninput=e=>upd(()=>sel.fxGrayscale=+e.target.value); gr.onchange=()=>pushHistory(); }
  if(se){ se.oninput=e=>upd(()=>sel.fxSepia=+e.target.value); se.onchange=()=>pushHistory(); }
  toolpanel.querySelectorAll('[data-adjfx]').forEach(btn=>{
    btn.onclick = ()=>{
      const presets = {
        none:{brightness:100,contrast:100,saturate:100,fxBlur:0,fxGrayscale:0,fxSepia:0},
        vivid:{brightness:105,contrast:115,saturate:150,fxBlur:0,fxGrayscale:0,fxSepia:0},
        bw:{brightness:100,contrast:110,saturate:0,fxBlur:0,fxGrayscale:100,fxSepia:0},
        warm:{brightness:105,contrast:100,saturate:110,fxBlur:0,fxGrayscale:0,fxSepia:30},
        cool:{brightness:100,contrast:105,saturate:120,fxBlur:0,fxGrayscale:0,fxSepia:0}
      };
      Object.assign(sel, presets[btn.dataset.adjfx]);
      render();
      if(sel.type==='text') renderTextPanel();
      else if(sel.type==='shape') renderShapePanel();
      else if(sel.type==='emoji') renderEmojiPanel();
      pushHistory();
    };
  });
}

function drawLayer(c, layer){
  c.save();
  c.globalAlpha = (layer.opacity!==undefined? layer.opacity:100)/100;
  c.translate(layer.x, layer.y);
  c.rotate((layer.rotation||0)*Math.PI/180);

  if(layer.type === 'text'){
    c.filter = buildAdjFilter(layer);
    drawTextLayer(c, layer);
  } else if(layer.type === 'image'){
    drawImageLayer(c, layer);
  } else if(layer.type === 'shape'){
    c.filter = buildAdjFilter(layer);
    drawShapeLayer(c, layer);
  } else if(layer.type === 'emoji'){
    c.filter = buildAdjFilter(layer);
    c.font = `${layer.size}px "Segoe UI Emoji", sans-serif`;
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.fillText(layer.char, 0, 0);
  }
  c.restore();
}

function measureTextLayer(layer){
  ctx.save();
  ctx.font = `${layer.italic?'italic ':''}${layer.bold?'bold ':''}${layer.fontSize}px ${layer.fontFamily}`;
  const lines = layer.text.split('\n');
  let maxW = 0;
  lines.forEach(l=>{ const m = ctx.measureText(l); if(m.width>maxW) maxW = m.width; });
  const lineH = layer.fontSize * 1.25;
  ctx.restore();
  layer.w = Math.max(40, maxW + (layer.strokeWidth||0)*2 + 16);
  layer.h = Math.max(30, lineH * lines.length + 10);
}

// Buduje CanvasGradient dla ukladu WYSRODKOWANEGO wokol (0,0) - tak rysowany jest tekst/ksztalt.
function makeLinearGradientCentered(ctx, angleDeg, halfW, halfH, stops){
  const rad = (angleDeg||0) * Math.PI/180;
  const x0 = -Math.cos(rad)*halfW, y0 = -Math.sin(rad)*halfH;
  const x1 = Math.cos(rad)*halfW, y1 = Math.sin(rad)*halfH;
  const g = ctx.createLinearGradient(x0,y0,x1,y1);
  stops.forEach(s=> g.addColorStop(Math.max(0,Math.min(1,s.p)), s.c));
  return g;
}
// Buduje CanvasGradient dla prostokata 0..w / 0..h (np. silhouetka obrazka w lokalnym ukladzie).
function makeLinearGradientBox(ctx, angleDeg, w, h, stops){
  const rad = (angleDeg||0) * Math.PI/180;
  const cx = w/2, cy = h/2;
  const x0 = cx - Math.cos(rad)*cx, y0 = cy - Math.sin(rad)*cy;
  const x1 = cx + Math.cos(rad)*cx, y1 = cy + Math.sin(rad)*cy;
  const g = ctx.createLinearGradient(x0,y0,x1,y1);
  stops.forEach(s=> g.addColorStop(Math.max(0,Math.min(1,s.p)), s.c));
  return g;
}

function drawTextLayer(c, layer){
  const lines = layer.text.split('\n');
  const lineH = layer.fontSize * 1.25;
  c.font = `${layer.italic?'italic ':''}${layer.bold?'bold ':''}${layer.fontSize}px ${layer.fontFamily}`;
  c.textAlign = layer.align || 'center';
  c.textBaseline = 'middle';
  const totalH = lineH * lines.length;
  const startY = -totalH/2 + lineH/2;
  let alignX = 0;
  if(layer.align==='left') alignX = -layer.w/2 + 8;
  if(layer.align==='right') alignX = layer.w/2 - 8;

  // Cien - rysowany recznie (zamiast natywnego canvas shadow), zeby mogl byc gradientowy.
  if(layer.shadowEnabled){
    c.save();
    c.filter = `blur(${layer.shadowBlur}px)`;
    c.translate(layer.shadowOffsetX, layer.shadowOffsetY);
    c.fillStyle = layer.shadowGradient
      ? makeLinearGradientCentered(c, layer.shadowGradient.angle, layer.w/2, totalH/2, layer.shadowGradient.stops)
      : layer.shadowColor;
    lines.forEach((line,i)=>{
      const y = startY + i*lineH;
      c.fillText(line, alignX, y);
    });
    c.restore();
  }

  let fillStyle = layer.color;
  if(layer.gradient){
    let grad;
    if(layer.gradient.type === 'radial'){
      const hw = layer.w/2, hh = totalH/2;
      const cx = -hw + hw*2*((layer.gradient.cx!==undefined?layer.gradient.cx:50)/100);
      const cy = -hh + hh*2*((layer.gradient.cy!==undefined?layer.gradient.cy:50)/100);
      const r = Math.max(hw,hh) * ((layer.gradient.r!==undefined?layer.gradient.r:70)/100);
      grad = c.createRadialGradient(cx,cy,0,cx,cy,Math.max(1,r));
    } else {
      const rad = (layer.gradient.angle||0) * Math.PI/180;
      const hw = layer.w/2, hh = totalH/2;
      const x0 = -Math.cos(rad)*hw, y0 = -Math.sin(rad)*hh;
      const x1 = Math.cos(rad)*hw, y1 = Math.sin(rad)*hh;
      grad = c.createLinearGradient(x0,y0,x1,y1);
    }
    layer.gradient.stops.forEach(s=> grad.addColorStop(Math.max(0,Math.min(1,s.p)), s.c));
    fillStyle = grad;
  }
  const strokeStyle = layer.strokeGradient
    ? makeLinearGradientCentered(c, layer.strokeGradient.angle, layer.w/2, totalH/2, layer.strokeGradient.stops)
    : layer.strokeColor;
  lines.forEach((line,i)=>{
    const y = startY + i*lineH;
    if(layer.strokeWidth>0){
      c.lineWidth = layer.strokeWidth;
      c.strokeStyle = strokeStyle;
      c.lineJoin = 'round';
      c.strokeText(line, alignX, y);
    }
    c.fillStyle = fillStyle;
    c.fillText(line, alignX, y);
  });
}

function drawImageLayer(c, layer){
  const src = layer.canvas || layer.img;
  if(!src) return;
  c.save();
  if(layer.flipH) c.scale(-1,1);
  if(layer.flipV) c.scale(1,-1);
  const w = layer.w, h = layer.h;
  const f = layer.filters;
  if(layer.shadow && layer.shadow.enabled){
    drawCutoutShadow(c, src, w, h, layer.shadow);
  }
  if(layer.outline && layer.outline.enabled){
    drawCutoutOutline(c, src, w, h, layer.outline);
  }
  c.filter = `brightness(${f.brightness}%) contrast(${f.contrast}%) saturate(${f.saturate}%) blur(${f.blur}px) grayscale(${f.grayscale}%) sepia(${f.sepia}%)`;
  if(layer.radius > 0){
    const r = Math.min(layer.radius, Math.min(w,h)/2);
    c.beginPath();
    roundRectPath(c, -w/2,-h/2,w,h,r);
    c.clip();
  }
  if(layer.cropMask){
    // maska "wycinanie/gumka" jest juz wypalona w layer.canvas (alpha), nic dodatkowego nie trzeba
  }
  c.drawImage(src, -w/2, -h/2, w, h);
  c.restore();
}

// Cien wyciecia (obrysu alpha) obrazka - rysowany recznie z silhouetki, zeby mogl byc gradientowy.
function drawCutoutShadow(c, src, w, h, shadow){
  const sil = document.createElement('canvas');
  sil.width = src.width; sil.height = src.height;
  const sctx = sil.getContext('2d');
  sctx.drawImage(src,0,0);
  sctx.globalCompositeOperation = 'source-in';
  sctx.fillStyle = shadow.gradient
    ? makeLinearGradientBox(sctx, shadow.gradient.angle, sil.width, sil.height, shadow.gradient.stops)
    : shadow.color;
  sctx.fillRect(0,0,sil.width,sil.height);
  c.save();
  c.filter = `blur(${shadow.blur}px)`;
  c.drawImage(sil, -w/2 + (shadow.offsetX||0), -h/2 + (shadow.offsetY||0), w, h);
  c.restore();
}

// Obrys/poswiata dookola wyciecia (kanalu alpha) - popularny "cutout sticker" look z miniaturek
function drawCutoutOutline(c, src, w, h, outline){
  const sil = document.createElement('canvas');
  sil.width = src.width; sil.height = src.height;
  const sctx = sil.getContext('2d');
  sctx.drawImage(src,0,0);
  sctx.globalCompositeOperation = 'source-in';
  sctx.fillStyle = outline.gradient
    ? makeLinearGradientBox(sctx, outline.gradient.angle, sil.width, sil.height, outline.gradient.stops)
    : outline.color;
  sctx.fillRect(0,0,sil.width,sil.height);

  const steps = 32;
  const rPx = outline.width;
  c.save();
  if(outline.glow>0){
    c.save();
    c.filter = `blur(${outline.glow}px)`;
    c.globalAlpha = 0.85;
    for(let i=0;i<steps;i++){
      const ang = (i/steps)*Math.PI*2;
      c.drawImage(sil, -w/2+Math.cos(ang)*rPx*1.4, -h/2+Math.sin(ang)*rPx*1.4, w, h);
    }
    c.restore();
  }
  for(let i=0;i<steps;i++){
    const ang = (i/steps)*Math.PI*2;
    c.drawImage(sil, -w/2+Math.cos(ang)*rPx, -h/2+Math.sin(ang)*rPx, w, h);
  }
  c.restore();
}

// Tworzy edytowalny canvas z obrazka (max 1600px na dluzszym boku, zeby retusz byl plynny)
function makeEditableCanvas(img){
  const MAXDIM = 1600;
  let iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height;
  let scale = Math.min(1, MAXDIM/Math.max(iw,ih));
  const cw = Math.max(1, Math.round(iw*scale)), ch = Math.max(1, Math.round(ih*scale));
  const cnv = document.createElement('canvas');
  cnv.width = cw; cnv.height = ch;
  cnv.getContext('2d').drawImage(img, 0, 0, cw, ch);
  return cnv;
}

function cloneCanvas(src){
  const cnv = document.createElement('canvas');
  cnv.width = src.width; cnv.height = src.height;
  cnv.getContext('2d').drawImage(src,0,0);
  return cnv;
}

function roundRectPath(c,x,y,w,h,r){
  c.moveTo(x+r,y);
  c.arcTo(x+w,y,x+w,y+h,r);
  c.arcTo(x+w,y+h,x,y+h,r);
  c.arcTo(x,y+h,x,y,r);
  c.arcTo(x,y,x+w,y,r);
  c.closePath();
}

function drawShapeLayer(c, layer){
  const w = layer.w, h = layer.h;
  c.beginPath();
  if(layer.shape === 'rect'){
    roundRectPath(c, -w/2,-h/2,w,h, Math.min(layer.cornerRadius||0, Math.min(w,h)/2));
  } else if(layer.shape === 'circle'){
    c.ellipse(0,0,w/2,h/2,0,0,Math.PI*2);
  } else if(layer.shape === 'triangle'){
    c.moveTo(0,-h/2); c.lineTo(w/2,h/2); c.lineTo(-w/2,h/2); c.closePath();
  } else if(layer.shape === 'star'){
    starPath(c, w/2, h/2, 5);
  } else if(layer.shape === 'arrow'){
    arrowPath(c, w, h);
  } else if(layer.shape === 'line'){
    c.moveTo(-w/2,0); c.lineTo(w/2,0);
  }
  if(layer.fill && layer.fill !== 'none'){ c.fillStyle = layer.fill; c.fill(); }
  if(layer.strokeWidth>0){ c.lineWidth = layer.strokeWidth; c.strokeStyle = layer.stroke; c.stroke(); }
}

function starPath(c, rx, ry, spikes){
  const step = Math.PI/spikes;
  c.moveTo(0,-ry);
  for(let i=0;i<spikes*2;i++){
    const r = (i%2===0)? 1 : 0.45;
    const a = -Math.PI/2 + i*step;
    c.lineTo(Math.cos(a)*rx*r, Math.sin(a)*ry*r);
  }
  c.closePath();
}

function arrowPath(c, w, h){
  const bodyH = h*0.35;
  c.moveTo(-w/2, -bodyH/2);
  c.lineTo(w*0.15, -bodyH/2);
  c.lineTo(w*0.15, -h/2);
  c.lineTo(w/2, 0);
  c.lineTo(w*0.15, h/2);
  c.lineTo(w*0.15, bodyH/2);
  c.lineTo(-w/2, bodyH/2);
  c.closePath();
}

// ---------- KOMPOZYCJA / EFEKTY GLOBALNE ----------
function renderComposite(targetCtx, w, h){
  targetCtx.clearRect(0,0,w,h);
  const off = document.createElement('canvas');
  off.width = w; off.height = h;
  const octx = off.getContext('2d');

  drawBackground(octx, w, h);
  layers.forEach(l=>{
    if(l.type==='text') measureTextLayer(l);
    drawLayer(octx, l);
  });

  targetCtx.save();
  targetCtx.filter = `brightness(${effects.brightness}%) contrast(${effects.contrast}%) saturate(${effects.saturate}%)`;
  targetCtx.drawImage(off,0,0);
  targetCtx.filter = 'none';
  targetCtx.restore();

  if(effects.grain>0){
    targetCtx.save();
    targetCtx.globalAlpha = effects.grain/100 * 0.5;
    const tile = getNoiseTile('#808080');
    const pattern = targetCtx.createPattern(tile,'repeat');
    targetCtx.fillStyle = pattern;
    targetCtx.globalCompositeOperation = 'overlay';
    targetCtx.fillRect(0,0,w,h);
    targetCtx.restore();
  }

  if(effects.vignette>0){
    targetCtx.save();
    const grad = targetCtx.createRadialGradient(w/2,h/2, Math.min(w,h)*0.2, w/2,h/2, Math.max(w,h)*0.75);
    grad.addColorStop(0,'rgba(0,0,0,0)');
    grad.addColorStop(1, `rgba(0,0,0,${effects.vignette/100})`);
    targetCtx.fillStyle = grad;
    targetCtx.fillRect(0,0,w,h);
    targetCtx.restore();
  }
}

function render(){
  renderComposite(ctx, canvasW, canvasH);
  if(retouchTool==='crop' && cropState){
    drawCropOverlay();
  } else {
    drawSelectionUI();
  }
  renderLayerList();
}

function drawCropOverlay(){
  ctx.save();
  ctx.fillStyle = 'rgba(0,0,0,0.55)';
  const {x,y,w,h} = cropState;
  ctx.fillRect(0,0,canvasW,y);
  ctx.fillRect(0,y+h,canvasW,canvasH-(y+h));
  ctx.fillRect(0,y,x,h);
  ctx.fillRect(x+w,y,canvasW-(x+w),h);
  ctx.strokeStyle = '#7c5cff';
  ctx.lineWidth = 2;
  ctx.setLineDash([8,5]);
  ctx.strokeRect(x,y,w,h);
  ctx.restore();
}

// ---------- SELEKCJA / UCHWYTY ----------
const HANDLE_R = 7;
function getSelectedLayer(){ return layers.find(l=>l.id===selectedId) || null; }

function drawSelectionUI(){
  if(showCenterLines){
    ctx.save();
    ctx.strokeStyle = 'rgba(0,209,160,0.5)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([5,5]);
    ctx.beginPath(); ctx.moveTo(canvasW/2,0); ctx.lineTo(canvasW/2,canvasH); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0,canvasH/2); ctx.lineTo(canvasW,canvasH/2); ctx.stroke();
    ctx.restore();
  }
  if(activeGuides.length){
    ctx.save();
    ctx.strokeStyle = '#00d1a0';
    ctx.lineWidth = 2;
    ctx.setLineDash([8,6]);
    activeGuides.forEach(g=>{
      ctx.beginPath();
      if(g.type==='v'){ ctx.moveTo(g.pos,0); ctx.lineTo(g.pos,canvasH); }
      else { ctx.moveTo(0,g.pos); ctx.lineTo(canvasW,g.pos); }
      ctx.stroke();
    });
    ctx.restore();
  }
  const l = getSelectedLayer();
  if(!l) return;
  const scale = mainCanvas.width / mainCanvas.clientWidth;
  const corners = getLayerCorners(l);
  ctx.save();
  ctx.strokeStyle = '#7c5cff';
  ctx.lineWidth = 2*scale;
  ctx.setLineDash([6*scale,4*scale]);
  ctx.beginPath();
  corners.forEach((p,i)=> i===0? ctx.moveTo(p.x,p.y): ctx.lineTo(p.x,p.y));
  ctx.closePath();
  ctx.stroke();
  ctx.setLineDash([]);

  // uchwyt resize (bottom-right corner = corners[2])
  drawHandle(corners[2].x, corners[2].y, scale);
  // uchwyt rotate
  const rot = getRotateHandlePos(l);
  drawHandle(rot.x, rot.y, scale, true);
  ctx.beginPath();
  ctx.moveTo((corners[1].x+corners[2].x)/2, (corners[1].y+corners[2].y)/2);
  ctx.lineTo(rot.x, rot.y);
  ctx.strokeStyle = '#7c5cff';
  ctx.lineWidth = 1.5*scale;
  ctx.stroke();
  ctx.restore();
}

function drawHandle(x,y,scale,isRotate){
  ctx.save();
  ctx.beginPath();
  ctx.arc(x,y,HANDLE_R*scale,0,Math.PI*2);
  ctx.fillStyle = isRotate? '#00d1a0' : '#ffffff';
  ctx.fill();
  ctx.lineWidth = 2*scale;
  ctx.strokeStyle = '#7c5cff';
  ctx.stroke();
  ctx.restore();
}

function getRotateHandlePos(l){
  const rad = (l.rotation||0)*Math.PI/180;
  const dist = l.h/2 + 34;
  return {
    x: l.x + Math.sin(rad)*dist,
    y: l.y - Math.cos(rad)*dist
  };
}

function pointInLayer(px,py,layer){
  const dx = px-layer.x, dy = py-layer.y;
  const rad = -(layer.rotation||0)*Math.PI/180;
  const lx = dx*Math.cos(rad) - dy*Math.sin(rad);
  const ly = dx*Math.sin(rad) + dy*Math.cos(rad);
  return Math.abs(lx) <= layer.w/2 && Math.abs(ly) <= layer.h/2;
}

function dist(x1,y1,x2,y2){ return Math.hypot(x2-x1,y2-y1); }

// ---------- RETUSZ: SILNIK PĘDZLI ----------
let retouchTool = null; // null | 'erase'|'clone'|'blur'|'sharpen'|'dodge'|'burn'|'sponge'|'draw'|'crop'
let retouchSettings = { size:40, hardness:65, strength:55, saturateUp:true, color:'#ffffff', drawSize:14, drawOpacity:100, bgColor:'#ffffff', bgTolerance:28, autoTolerance:30 };
let dispersionSettings = { amount:35, angle:0 };
let cloneSource = null;      // {x,y} w przestrzeni pikseli warstwy
let cloneDragAnchor = null;
let cropState = null;        // {x,y,w,h} w przestrzeni pikseli warstwy - trwajacy kadr
let isRetouchPainting = false;
let lastRetouchPoint = null;
// "Pojemność" jednego, ciągłego pociągnięcia pędzla dla narzędzi rozjaśnianie/przyciemnianie/gąbka.
// Bez tego, przy wolnym malowaniu (dużo nakładających się "stempli" na tym samym pikselu w jednej
// sesji rysowania), efekt kumulował się błyskawicznie do pełnej bieli/czerni i wyglądał jak zwykły
// pisak o stałej sile zamiast realnego, stopniowego rozjaśniania/przyciemniania.
let strokeCoverage = null; // Float32Array w*h - ile "mocy" narzędzia zużyto już w TEJ sesji rysowania
let strokeCoverageDims = null; // {w,h} wymiary canvasu warstwy, do której należy strokeCoverage
function resetStrokeCoverage(w,h){
  strokeCoverage = new Float32Array(w*h);
  strokeCoverageDims = {w,h};
}
let drawLayerRef = null;     // aktywna warstwa rysunku podczas malowania

function mapCanvasPointToLayerPixel(layer, cx, cy){
  const dx = cx-layer.x, dy = cy-layer.y;
  const rad = -(layer.rotation||0)*Math.PI/180;
  let lx = dx*Math.cos(rad) - dy*Math.sin(rad);
  let ly = dx*Math.sin(rad) + dy*Math.cos(rad);
  if(layer.flipH) lx = -lx;
  if(layer.flipV) ly = -ly;
  const scaleX = layer.canvas.width/layer.w;
  const scaleY = layer.canvas.height/layer.h;
  return {
    x: (lx + layer.w/2) * scaleX,
    y: (ly + layer.h/2) * scaleY,
    scale: (scaleX+scaleY)/2
  };
}

function stampWithSoftMask(lctx, x, y, r, hardness, drawFn){
  const size = Math.max(2, Math.ceil(r*2));
  const buf = document.createElement('canvas'); buf.width=size; buf.height=size;
  const bctx = buf.getContext('2d');
  drawFn(bctx, size, size, r);
  bctx.globalCompositeOperation = 'destination-in';
  const grad = bctx.createRadialGradient(r,r,Math.max(0,r*(hardness/100)), r,r, r);
  grad.addColorStop(0,'rgba(0,0,0,1)');
  grad.addColorStop(1,'rgba(0,0,0,0)');
  bctx.fillStyle = grad;
  bctx.fillRect(0,0,size,size);
  lctx.drawImage(buf, x-r, y-r);
}

function stampErase(lctx, x, y, r, hardness){
  const size = Math.max(2, Math.ceil(r*2));
  const buf = document.createElement('canvas'); buf.width=size; buf.height=size;
  const bctx = buf.getContext('2d');
  const grad = bctx.createRadialGradient(r,r,Math.max(0,r*(hardness/100)), r,r, r);
  grad.addColorStop(0,'rgba(0,0,0,1)');
  grad.addColorStop(1,'rgba(0,0,0,0)');
  bctx.fillStyle = grad;
  bctx.fillRect(0,0,size,size);
  lctx.save();
  lctx.globalCompositeOperation = 'destination-out';
  lctx.drawImage(buf, x-r, y-r);
  lctx.restore();
}

function stampDodgeBurn(cnv, x, y, r, strength, mode, coverage){
  const lctx = cnv.getContext('2d');
  const sx = Math.max(0, Math.floor(x-r)), sy = Math.max(0, Math.floor(y-r));
  const ex = Math.min(cnv.width, Math.ceil(x+r)), ey = Math.min(cnv.height, Math.ceil(y+r));
  const w = ex-sx, h = ey-sy;
  if(w<=0||h<=0) return;
  const imgData = lctx.getImageData(sx,sy,w,h);
  const d = imgData.data;
  const perStampAmt = (strength/100) * (mode==='dodge' ? 0.05 : -0.05);
  const capPerStroke = (strength/100) * 0.55; // max. laczna zmiana jasnosci w JEDNYM, ciaglym pociagnieciu
  for(let yy=0; yy<h; yy++){
    for(let xx=0; xx<w; xx++){
      const i = (yy*w+xx)*4;
      if(d[i+3]===0) continue; // pomijamy przezroczyste piksele - nie "zakrywamy" pustego tla
      const ddx = (sx+xx)-x, ddy=(sy+yy)-y;
      const dd = Math.sqrt(ddx*ddx+ddy*ddy);
      if(dd>r) continue;
      const falloff = 1 - (dd/r);
      let delta = perStampAmt*falloff;
      if(coverage && coverage.data){
        const mi = (sy+yy)*coverage.w + (sx+xx);
        const used = coverage.data[mi] || 0;
        const remaining = capPerStroke - used;
        if(remaining <= 0) continue;
        if(Math.abs(delta) > remaining) delta = (delta<0?-1:1) * remaining;
        coverage.data[mi] = used + Math.abs(delta);
      }
      const r0=d[i]/255, g0=d[i+1]/255, b0=d[i+2]/255;
      const max=Math.max(r0,g0,b0), min=Math.min(r0,g0,b0);
      let hh,ss,ll=(max+min)/2;
      if(max===min){ hh=0; ss=0; } else {
        const dlt = max-min;
        ss = ll>0.5 ? dlt/(2-max-min) : dlt/(max+min);
        if(max===r0) hh=((g0-b0)/dlt + (g0<b0?6:0));
        else if(max===g0) hh=((b0-r0)/dlt+2);
        else hh=((r0-g0)/dlt+4);
        hh/=6;
      }
      ll = Math.max(0, Math.min(1, ll + delta));
      const q = ll<0.5 ? ll*(1+ss) : ll+ss-ll*ss;
      const p2 = 2*ll-q;
      const hue2rgb=(p,q,t)=>{ if(t<0)t+=1; if(t>1)t-=1; if(t<1/6)return p+(q-p)*6*t; if(t<1/2)return q; if(t<2/3)return p+(q-p)*(2/3-t)*6; return p; };
      d[i]   = Math.round(hue2rgb(p2,q,hh+1/3)*255);
      d[i+1] = Math.round(hue2rgb(p2,q,hh)*255);
      d[i+2] = Math.round(hue2rgb(p2,q,hh-1/3)*255);
    }
  }
  lctx.putImageData(imgData, sx, sy);
}

// Druga odmiana rozjasniania/przyciemniania: dziala na kanalach RGB (screen/multiply),
// a nie na jasnosci HSL. Jasne piksele rozjasniaja sie wolniej niz ciemne (proporcjonalnie
// do "zapasu" do bieli/czerni), wiec duzy obszar nie robi sie od razu plaskim, bialym blobem
// tak jak przy klasycznym trybie - zachowuje wiecej naturalnej faktury przy mocnym uzyciu.
function stampDodgeBurn2(cnv, x, y, r, strength, mode, coverage){
  const lctx = cnv.getContext('2d');
  const sx = Math.max(0, Math.floor(x-r)), sy = Math.max(0, Math.floor(y-r));
  const ex = Math.min(cnv.width, Math.ceil(x+r)), ey = Math.min(cnv.height, Math.ceil(y+r));
  const w = ex-sx, h = ey-sy;
  if(w<=0||h<=0) return;
  const imgData = lctx.getImageData(sx,sy,w,h);
  const d = imgData.data;
  const perStampAmt = (strength/100) * 0.1;
  const capPerStroke = (strength/100) * 0.65; // max. sila efektu w jednym, ciaglym pociagnieciu
  for(let yy=0; yy<h; yy++){
    for(let xx=0; xx<w; xx++){
      const i = (yy*w+xx)*4;
      if(d[i+3]===0) continue;
      const ddx = (sx+xx)-x, ddy=(sy+yy)-y;
      const dd = Math.sqrt(ddx*ddx+ddy*ddy);
      if(dd>r) continue;
      const falloff = 1 - (dd/r);
      let k = perStampAmt*falloff;
      if(coverage && coverage.data){
        const mi = (sy+yy)*coverage.w + (sx+xx);
        const used = coverage.data[mi] || 0;
        const remaining = capPerStroke - used;
        if(remaining <= 0) continue;
        if(k > remaining) k = remaining;
        coverage.data[mi] = used + k;
      }
      for(let c=0;c<3;c++){
        const v = d[i+c];
        d[i+c] = mode==='dodge' ? Math.round(v + (255-v)*k) : Math.round(v * (1-k));
      }
    }
  }
  lctx.putImageData(imgData, sx, sy);
}

function stampBlur(lctx, cnv, x, y, r, hardness, strength){
  const pad = Math.ceil(r);
  const sx = Math.max(0, Math.floor(x-pad)), sy = Math.max(0, Math.floor(y-pad));
  const sw = Math.min(cnv.width-sx, pad*2), sh = Math.min(cnv.height-sy, pad*2);
  if(sw<=0||sh<=0) return;
  const tmp = document.createElement('canvas'); tmp.width=sw; tmp.height=sh;
  const tctx = tmp.getContext('2d');
  tctx.filter = `blur(${Math.max(1, strength/7)}px)`;
  tctx.drawImage(cnv, sx,sy,sw,sh, 0,0,sw,sh);
  tctx.filter = 'none';
  // przywracamy oryginalny ksztalt przezroczystosci - rozmycie nie "wycieka" na puste tlo
  tctx.globalCompositeOperation = 'destination-in';
  tctx.drawImage(cnv, sx,sy,sw,sh, 0,0,sw,sh);
  stampWithSoftMask(lctx, x, y, r, hardness, (bctx,size)=>{
    bctx.drawImage(tmp, sx-(x-r), sy-(y-r));
  });
}

function stampSharpen(lctx, cnv, x, y, r, hardness, strength){
  // Prawdziwa "maska wyostrzajaca" (unsharp mask): oryginal + sila*(oryginal - rozmyty),
  // czyli wzmacniamy lokalne krawedzie/detale zamiast tylko podbijac kontrast/nasycenie
  // calego fragmentu (stary, "podrabiany" efekt, ktory nie wygladal jak realne wyostrzenie).
  const pad = Math.ceil(r);
  const sx = Math.max(0, Math.floor(x-pad)), sy = Math.max(0, Math.floor(y-pad));
  const sw = Math.min(cnv.width-sx, pad*2), sh = Math.min(cnv.height-sy, pad*2);
  if(sw<=0||sh<=0) return;

  const orig = document.createElement('canvas'); orig.width=sw; orig.height=sh;
  const octx = orig.getContext('2d');
  octx.drawImage(cnv, sx,sy,sw,sh, 0,0,sw,sh);

  const blurred = document.createElement('canvas'); blurred.width=sw; blurred.height=sh;
  const bctx2 = blurred.getContext('2d');
  bctx2.filter = 'blur(2px)';
  bctx2.drawImage(orig, 0,0);
  bctx2.filter = 'none';

  const oImg = octx.getImageData(0,0,sw,sh);
  const bImg = bctx2.getImageData(0,0,sw,sh);
  const od = oImg.data, bd = bImg.data;
  const amt = (strength/100) * 1.8;
  for(let i=0;i<od.length;i+=4){
    if(od[i+3]===0) continue;
    for(let c=0;c<3;c++){
      const diff = od[i+c]-bd[i+c];
      od[i+c] = Math.max(0, Math.min(255, od[i+c] + diff*amt));
    }
  }
  octx.putImageData(oImg,0,0);
  octx.globalCompositeOperation = 'destination-in';
  octx.drawImage(cnv, sx,sy,sw,sh, 0,0,sw,sh);
  stampWithSoftMask(lctx, x, y, r, hardness, (bctx,size)=>{
    bctx.drawImage(orig, sx-(x-r), sy-(y-r));
  });
}

function stampSponge(cnv, x, y, r, strength, increase, coverage){
  const lctx = cnv.getContext('2d');
  const sx = Math.max(0, Math.floor(x-r)), sy = Math.max(0, Math.floor(y-r));
  const ex = Math.min(cnv.width, Math.ceil(x+r)), ey = Math.min(cnv.height, Math.ceil(y+r));
  const w = ex-sx, h = ey-sy;
  if(w<=0||h<=0) return;
  const imgData = lctx.getImageData(sx,sy,w,h);
  const d = imgData.data;
  const perStampAmt = (strength/100) * (increase?0.05:-0.05);
  const capPerStroke = (strength/100) * 0.6;
  for(let yy=0; yy<h; yy++){
    for(let xx=0; xx<w; xx++){
      const ddx = (sx+xx)-x, ddy=(sy+yy)-y;
      const dd = Math.sqrt(ddx*ddx+ddy*ddy);
      if(dd>r) continue;
      const falloff = 1 - (dd/r);
      const i = (yy*w+xx)*4;
      let delta = perStampAmt*falloff;
      if(coverage && coverage.data){
        const mi = (sy+yy)*coverage.w + (sx+xx);
        const used = coverage.data[mi] || 0;
        const remaining = capPerStroke - used;
        if(remaining <= 0) continue;
        if(Math.abs(delta) > remaining) delta = (delta<0?-1:1) * remaining;
        coverage.data[mi] = used + Math.abs(delta);
      }
      const r0=d[i]/255, g0=d[i+1]/255, b0=d[i+2]/255;
      const max=Math.max(r0,g0,b0), min=Math.min(r0,g0,b0);
      let hh,ss,ll=(max+min)/2;
      if(max===min){ hh=0; ss=0; } else {
        const dlt = max-min;
        ss = ll>0.5 ? dlt/(2-max-min) : dlt/(max+min);
        if(max===r0) hh=((g0-b0)/dlt + (g0<b0?6:0));
        else if(max===g0) hh=((b0-r0)/dlt+2);
        else hh=((r0-g0)/dlt+4);
        hh/=6;
      }
      ss = Math.max(0, Math.min(1, ss + delta));
      const q = ll<0.5 ? ll*(1+ss) : ll+ss-ll*ss;
      const p2 = 2*ll-q;
      const hue2rgb=(p,q,t)=>{ if(t<0)t+=1; if(t>1)t-=1; if(t<1/6)return p+(q-p)*6*t; if(t<1/2)return q; if(t<2/3)return p+(q-p)*(2/3-t)*6; return p; };
      d[i]   = Math.round(hue2rgb(p2,q,hh+1/3)*255);
      d[i+1] = Math.round(hue2rgb(p2,q,hh)*255);
      d[i+2] = Math.round(hue2rgb(p2,q,hh-1/3)*255);
    }
  }
  lctx.putImageData(imgData, sx, sy);
}

function stampClone(lctx, cnv, destX, destY, srcX, srcY, r, hardness){
  const size = Math.max(2, Math.ceil(r*2));
  const sx = Math.max(0, Math.floor(srcX-r)), sy = Math.max(0, Math.floor(srcY-r));
  stampWithSoftMask(lctx, destX, destY, r, hardness, (bctx,bsize)=>{
    bctx.drawImage(cnv, srcX-r, srcY-r, size, size, 0, 0, size, size);
  });
}

// ---------- USUWANIE TŁA (kolor ręcznie / automatyczne wykrywanie krawędzi) ----------
function colorDist3(r1,g1,b1,r2,g2,b2){
  return Math.sqrt((r1-r2)*(r1-r2)+(g1-g2)*(g1-g2)+(b1-b2)*(b1-b2));
}

// Usuwa dany kolor (z tolerancja i miekkim feather na krawedziach) z calej warstwy zdjecia.
function removeColorFromLayer(sel, hexColor, tolerancePct){
  if(!sel || sel.type!=='image' || !sel.canvas) return;
  const cnv = sel.canvas, cctx = cnv.getContext('2d');
  const w = cnv.width, h = cnv.height;
  if(w<=0||h<=0) return;
  const img = cctx.getImageData(0,0,w,h);
  const d = img.data;
  let hx = hexColor.replace('#','');
  if(hx.length===3) hx = hx.split('').map(ch=>ch+ch).join('');
  const tr = parseInt(hx.substr(0,2),16), tg = parseInt(hx.substr(2,2),16), tb = parseInt(hx.substr(4,2),16);
  const tol = Math.max(1, (tolerancePct/100) * 260);
  const feather = tol*0.35;
  for(let i=0;i<d.length;i+=4){
    if(d[i+3]===0) continue;
    const dist = colorDist3(d[i],d[i+1],d[i+2], tr,tg,tb);
    if(dist < tol) d[i+3] = 0;
    else if(dist < tol+feather) d[i+3] = Math.round(d[i+3] * ((dist-tol)/feather));
  }
  cctx.putImageData(img,0,0);
}

// Automatyczne usuwanie tła: NIE jest to siec neuronowa (dziala offline, bez wysylania zdjecia
// gdziekolwiek) - to algorytm "magic wand" wystartowany ze wszystkich brzegow zdjecia: usuwa
// spojne, podobne kolorystycznie obszary polaczone z krawedzia kadru. Najlepiej dziala na
// zdjeciach z prostym / jednolitym tlem (np. studyjne, zielony/bialy ekran, jednolity kolor).
function autoRemoveBackground(sel, tolerancePct){
  if(!sel || sel.type!=='image' || !sel.canvas) return;
  const cnv = sel.canvas, cctx = cnv.getContext('2d');
  const w = cnv.width, h = cnv.height;
  if(w<=0||h<=0) return;
  const img = cctx.getImageData(0,0,w,h);
  const d = img.data;
  const tol = Math.max(1, (tolerancePct/100) * 210);
  const visited = new Uint8Array(w*h);
  const idx = (x,y)=> y*w+x;
  const corners = [[0,0],[w-1,0],[0,h-1],[w-1,h-1]];
  let refR=0, refG=0, refB=0;
  corners.forEach(([x,y])=>{ const i=idx(x,y)*4; refR+=d[i]; refG+=d[i+1]; refB+=d[i+2]; });
  refR/=4; refG/=4; refB/=4;

  const stack = [];
  const pushIfBg = (x,y)=>{
    if(x<0||y<0||x>=w||y>=h) return;
    const p = idx(x,y);
    if(visited[p]) return;
    const i = p*4;
    if(d[i+3]===0){ visited[p]=1; return; }
    if(colorDist3(d[i],d[i+1],d[i+2], refR,refG,refB) < tol){ visited[p]=1; stack.push(p); }
  };
  for(let x=0;x<w;x++){ pushIfBg(x,0); pushIfBg(x,h-1); }
  for(let y=0;y<h;y++){ pushIfBg(0,y); pushIfBg(w-1,y); }

  while(stack.length){
    const p = stack.pop();
    const x = p % w, y = (p/w)|0;
    const i = p*4;
    d[i+3] = 0;
    const nbrs = [[x+1,y],[x-1,y],[x,y+1],[x,y-1]];
    for(const [nx,ny] of nbrs){
      if(nx<0||ny<0||nx>=w||ny>=h) continue;
      const np = idx(nx,ny);
      if(visited[np]) continue;
      const ni = np*4;
      if(colorDist3(d[ni],d[ni+1],d[ni+2], d[i],d[i+1],d[i+2]) < tol*0.6){
        visited[np]=1;
        stack.push(np);
      }
    }
  }
  cctx.putImageData(img,0,0);
}

function createDrawLayer(){
  const cnv = document.createElement('canvas');
  cnv.width = canvasW; cnv.height = canvasH;
  const layer = { type:'image', canvas:cnv, x:canvasW/2, y:canvasH/2, w:canvasW, h:canvasH,
    rotation:0, opacity:100, radius:0, flipH:false, flipV:false, isDrawLayer:true,
    filters:{brightness:100,contrast:100,saturate:100,blur:0,grayscale:0,sepia:0},
    shadow:{enabled:false,color:'#000000',blur:20,offsetX:0,offsetY:8}, outline:{enabled:false,color:'#ffffff',width:14,glow:0} };
  addLayer(layer);
  return layer;
}

function applyStampAt(sel, layerPt, size, hardness, strength){
  const lctx = sel.canvas.getContext('2d');
  const r = Math.max(2, size*layerPt.scale/2);
  const cov = (strokeCoverage && strokeCoverageDims && strokeCoverageDims.w===sel.canvas.width && strokeCoverageDims.h===sel.canvas.height)
    ? { data: strokeCoverage, w: strokeCoverageDims.w } : null;
  if(retouchTool==='erase') stampErase(lctx, layerPt.x, layerPt.y, r, hardness);
  else if(retouchTool==='blur') stampBlur(lctx, sel.canvas, layerPt.x, layerPt.y, r, hardness, strength);
  else if(retouchTool==='sharpen') stampSharpen(lctx, sel.canvas, layerPt.x, layerPt.y, r, hardness, strength);
  else if(retouchTool==='dodge') stampDodgeBurn(sel.canvas, layerPt.x, layerPt.y, r, strength, 'dodge', cov);
  else if(retouchTool==='burn') stampDodgeBurn(sel.canvas, layerPt.x, layerPt.y, r, strength, 'burn', cov);
  else if(retouchTool==='dodge2') stampDodgeBurn2(sel.canvas, layerPt.x, layerPt.y, r, strength, 'dodge', cov);
  else if(retouchTool==='burn2') stampDodgeBurn2(sel.canvas, layerPt.x, layerPt.y, r, strength, 'burn', cov);
  else if(retouchTool==='sponge') stampSponge(sel.canvas, layerPt.x, layerPt.y, r, strength, retouchSettings.saturateUp, cov);
  else if(retouchTool==='draw'){
    lctx.save();
    lctx.globalAlpha = retouchSettings.drawOpacity/100;
    stampWithSoftMask(lctx, layerPt.x, layerPt.y, r, hardness, (bctx,bsize)=>{
      bctx.fillStyle = retouchSettings.color;
      bctx.fillRect(0,0,bsize,bsize);
    });
    lctx.restore();
  }
  else if(retouchTool==='clone' && cloneSource){
    const off = { dx: cloneSource.x - cloneDragAnchor.x, dy: cloneSource.y - cloneDragAnchor.y };
    stampClone(lctx, sel.canvas, layerPt.x, layerPt.y, layerPt.x+off.dx, layerPt.y+off.dy, r, hardness);
  }
}

function paintStroke(sel, fromP, toP){
  const size = retouchTool==='draw' ? retouchSettings.drawSize : retouchSettings.size;
  const hardness = retouchSettings.hardness;
  const strength = retouchSettings.strength;
  const d = dist(fromP.x,fromP.y,toP.x,toP.y);
  const step = Math.max(2, size*0.18);
  const n = Math.max(1, Math.ceil(d/step));
  for(let i=0;i<=n;i++){
    const t = i/n;
    const cx = fromP.x + (toP.x-fromP.x)*t;
    const cy = fromP.y + (toP.y-fromP.y)*t;
    const layerPt = mapCanvasPointToLayerPixel(sel, cx, cy);
    applyStampAt(sel, layerPt, size, hardness, strength);
  }
  render();
}

function handleRetouchPointerDown(p, e){
  if(retouchTool === 'crop'){
    const sel = getSelectedLayer();
    if(!sel || sel.type!=='image'){ return; }
    cropState = { x:p.x, y:p.y, w:0, h:0, x0:p.x, y0:p.y };
    isRetouchPainting = true;
    render();
    return;
  }

  if(retouchTool === 'bgcolor'){
    const sel = getSelectedLayer();
    if(!sel || sel.type!=='image' || !sel.canvas) return;
    const layerPt = mapCanvasPointToLayerPixel(sel, p.x, p.y);
    const lctx = sel.canvas.getContext('2d');
    let px;
    try{ px = lctx.getImageData(Math.round(layerPt.x), Math.round(layerPt.y), 1, 1).data; }
    catch(err){ return; }
    if(px[3]===0) return; // kliknieto w przezroczysty piksel - nic do pobrania
    const hex = '#' + [px[0],px[1],px[2]].map(v=>v.toString(16).padStart(2,'0')).join('');
    retouchSettings.bgColor = hex;
    removeColorFromLayer(sel, hex, retouchSettings.bgTolerance);
    render(); renderRetouchPanel(); pushHistory();
    return;
  }

  if(retouchTool === 'autobg'){
    // ten tryb nie maluje po canvasie - dziala tylko przez przycisk "Wykryj i usuń tło" w panelu
    return;
  }

  let sel = getSelectedLayer();
  if(retouchTool === 'draw' && (!sel || sel.type!=='image')){
    sel = createDrawLayer();
  }
  if(!sel || sel.type!=='image' || !sel.canvas) return;

  if(retouchTool === 'clone'){
    const layerPt = mapCanvasPointToLayerPixel(sel, p.x, p.y);
    if(e.altKey || !cloneSource){
      cloneSource = { x:layerPt.x, y:layerPt.y };
      render();
      return;
    }
    cloneDragAnchor = { x:layerPt.x, y:layerPt.y };
  }

  isRetouchPainting = true;
  lastRetouchPoint = p;
  if(['dodge','burn','dodge2','burn2','sponge'].includes(retouchTool)){
    resetStrokeCoverage(sel.canvas.width, sel.canvas.height);
  } else {
    strokeCoverage = null; strokeCoverageDims = null;
  }
  paintStroke(sel, p, p);
}

function handleRetouchPointerMove(p, e){
  if(retouchTool === 'crop'){
    if(!cropState) return;
    cropState.x = Math.min(p.x, cropState.x0);
    cropState.y = Math.min(p.y, cropState.y0);
    cropState.w = Math.abs(p.x - cropState.x0);
    cropState.h = Math.abs(p.y - cropState.y0);
    render();
    return;
  }
  const sel = getSelectedLayer();
  if(!sel || sel.type!=='image' || !lastRetouchPoint) return;
  paintStroke(sel, lastRetouchPoint, p);
  lastRetouchPoint = p;
}

function handleRetouchPointerUp(){
  if(isRetouchPainting && retouchTool!=='crop'){
    pushHistory();
  }
  isRetouchPainting = false;
  lastRetouchPoint = null;
  cloneDragAnchor = null;
  strokeCoverage = null; strokeCoverageDims = null;
  render();
}

function applyCrop(){
  const sel = getSelectedLayer();
  if(!sel || sel.type!=='image' || !cropState || cropState.w<4 || cropState.h<4) return;
  if(Math.round(sel.rotation||0) !== 0){
    alert('Wyzeruj rotację warstwy przed kadrowaniem (suwak Rotacja w zakładce Obraz na 0°).');
    return;
  }
  // przecinamy prostokat kadru z granicami warstwy w przestrzeni canvasu
  const lx0 = sel.x - sel.w/2, ly0 = sel.y - sel.h/2, lx1 = sel.x + sel.w/2, ly1 = sel.y + sel.h/2;
  const rx0 = Math.max(lx0, cropState.x), ry0 = Math.max(ly0, cropState.y);
  const rx1 = Math.min(lx1, cropState.x+cropState.w), ry1 = Math.min(ly1, cropState.y+cropState.h);
  if(rx1-rx0 < 4 || ry1-ry0 < 4) return;
  const p0 = mapCanvasPointToLayerPixel(sel, rx0, ry0);
  const p1 = mapCanvasPointToLayerPixel(sel, rx1, ry1);
  const pw = Math.max(1, Math.round(p1.x-p0.x)), ph = Math.max(1, Math.round(p1.y-p0.y));
  const newCanvas = document.createElement('canvas');
  newCanvas.width = pw; newCanvas.height = ph;
  newCanvas.getContext('2d').drawImage(sel.canvas, p0.x, p0.y, pw, ph, 0, 0, pw, ph);
  sel.canvas = newCanvas;
  sel.w = rx1-rx0; sel.h = ry1-ry0;
  sel.x = rx0 + sel.w/2; sel.y = ry0 + sel.h/2;
  cropState = null;
  retouchTool = null;
  render(); renderRetouchPanel(); pushHistory();
}

function cancelCrop(){
  cropState = null;
  render();
}

// ---------- INTERAKCJA MYSZĄ ----------
let drag = null; // {mode:'move'|'resize'|'rotate', layer, startPointer, startState}

function canvasPointFromEvent(e){
  const rect = mainCanvas.getBoundingClientRect();
  const scaleX = mainCanvas.width / rect.width;
  const scaleY = mainCanvas.height / rect.height;
  return { x:(e.clientX-rect.left)*scaleX, y:(e.clientY-rect.top)*scaleY };
}

mainCanvas.addEventListener('pointerdown', (e)=>{
  const p = canvasPointFromEvent(e);

  if(retouchTool){
    handleRetouchPointerDown(p, e);
    return;
  }

  const sel = getSelectedLayer();

  if(sel){
    const corners = getLayerCorners(sel);
    const scale = mainCanvas.width / mainCanvas.clientWidth;
    const handleHit = HANDLE_R*scale + 6*scale;
    const rz = corners[2];
    const rot = getRotateHandlePos(sel);
    if(dist(p.x,p.y,rz.x,rz.y) < handleHit){
      drag = { mode:'resize', layer: sel, start:p, startW: sel.w, startH: sel.h, startFont: sel.fontSize, startSize: sel.size };
      return;
    }
    if(dist(p.x,p.y,rot.x,rot.y) < handleHit){
      drag = { mode:'rotate', layer: sel, cx: sel.x, cy: sel.y };
      return;
    }
  }

  // hit test od góry (ostatnia warstwa = na wierzchu)
  for(let i=layers.length-1;i>=0;i--){
    if(pointInLayer(p.x,p.y,layers[i])){
      selectLayer(layers[i].id);
      drag = { mode:'move', layer: layers[i], start:p, startX: layers[i].x, startY: layers[i].y };
      return;
    }
  }
  selectLayer(null);
});

let activeGuides = [];
let showCenterLines = false;
document.getElementById('centerLinesToggle').onchange = e=>{ showCenterLines = e.target.checked; render(); };
const SNAP_THRESHOLD = 10;

window.addEventListener('pointermove', (e)=>{
  if(retouchTool){
    if(isRetouchPainting) handleRetouchPointerMove(canvasPointFromEvent(e), e);
    return;
  }
  if(!drag) return;
  const p = canvasPointFromEvent(e);
  const l = drag.layer;
  activeGuides = [];
  if(drag.mode === 'move'){
    let nx = drag.startX + (p.x - drag.start.x);
    let ny = drag.startY + (p.y - drag.start.y);
    // snap do srodka canvasu
    if(Math.abs(nx - canvasW/2) < SNAP_THRESHOLD){ nx = canvasW/2; activeGuides.push({type:'v', pos:canvasW/2}); }
    if(Math.abs(ny - canvasH/2) < SNAP_THRESHOLD){ ny = canvasH/2; activeGuides.push({type:'h', pos:canvasH/2}); }
    // snap do innych warstw (srodek do srodka)
    layers.forEach(other=>{
      if(other.id===l.id) return;
      if(Math.abs(nx - other.x) < SNAP_THRESHOLD){ nx = other.x; activeGuides.push({type:'v', pos:other.x}); }
      if(Math.abs(ny - other.y) < SNAP_THRESHOLD){ ny = other.y; activeGuides.push({type:'h', pos:other.y}); }
    });
    l.x = nx; l.y = ny;
  } else if(drag.mode === 'resize'){
    const factor = Math.max(0.1, 1 + (dist(p.x,p.y,l.x,l.y) - dist(drag.start.x,drag.start.y,l.x,l.y)) / 120);
    if(l.type === 'text'){
      l.fontSize = Math.max(8, Math.round(drag.startFont * factor));
    } else if(l.type === 'emoji'){
      l.size = Math.max(10, Math.round(drag.startSize * factor));
    } else {
      l.w = Math.max(16, drag.startW * factor);
      l.h = Math.max(16, drag.startH * factor);
    }
  } else if(drag.mode === 'rotate'){
    const angle = Math.atan2(p.x-drag.cx, -(p.y-drag.cy)) * 180/Math.PI;
    l.rotation = Math.round(angle);
  }
  render();
});

window.addEventListener('pointerup', ()=>{
  if(retouchTool){ handleRetouchPointerUp(); return; }
  if(drag){ drag=null; activeGuides=[]; render(); pushHistory(); }
});

// ---------- WARSTWY: CRUD ----------
function addLayer(layer){
  layer.id = uid();
  layers.push(layer);
  selectLayer(layer.id);
  pushHistory();
}

function selectLayer(id){
  selectedId = id;
  render();
  syncTabToSelection();
  renderToolPanel();
}

function syncTabToSelection(){
  const l = getSelectedLayer();
  if(!l) return;
  const map = {text:'text', image:'image', shape:'shape', emoji:'emoji'};
  if(map[l.type] && map[l.type] !== currentTab){
    currentTab = map[l.type];
    document.querySelectorAll('.tab-btn').forEach(b=> b.classList.toggle('active', b.dataset.tab===currentTab));
  }
}

function deleteLayer(id){
  layers = layers.filter(l=>l.id!==id);
  if(selectedId===id) selectedId=null;
  render(); renderToolPanel(); pushHistory();
}

function duplicateLayer(id){
  const l = layers.find(x=>x.id===id);
  if(!l) return;
  const copy = JSON.parse(JSON.stringify(l, (k,v)=> (k==='canvas'||k==='img') ? undefined : v));
  copy.id = uid();
  copy.x += 24; copy.y += 24;
  if(l.type==='image' && l.canvas) copy.canvas = cloneCanvas(l.canvas); // niezalezna kopia pikseli
  layers.push(copy);
  selectLayer(copy.id);
  pushHistory();
}

function moveLayer(id, dir){
  const i = layers.findIndex(l=>l.id===id);
  if(i<0) return;
  const j = i+dir;
  if(j<0 || j>=layers.length) return;
  [layers[i],layers[j]] = [layers[j],layers[i]];
  render(); pushHistory();
}

document.getElementById('layerUp').onclick = ()=> selectedId && moveLayer(selectedId, 1);
document.getElementById('layerDown').onclick = ()=> selectedId && moveLayer(selectedId, -1);
document.getElementById('layerDup').onclick = ()=> selectedId && duplicateLayer(selectedId);
document.getElementById('layerDel').onclick = ()=> selectedId && deleteLayer(selectedId);

const LAYER_ICONS = {text:'🔤', image:'🖼️', shape:'◆', emoji:'😀'};
function layerLabel(l){
  if(l.type==='text') return l.text.slice(0,18) || 'Tekst';
  if(l.type==='image') return 'Obrazek';
  if(l.type==='shape') return 'Kształt: '+l.shape;
  if(l.type==='emoji') return 'Emoji '+l.char;
  return l.type;
}

let dragLayerId = null;
function reorderLayer(draggedId, targetId){
  const from = layers.findIndex(l=>l.id===draggedId);
  const to = layers.findIndex(l=>l.id===targetId);
  if(from<0 || to<0 || from===to) return;
  const [item] = layers.splice(from,1);
  layers.splice(to,0,item);
  render(); renderLayerList(); pushHistory();
}

function renderLayerList(){
  layerListEl.innerHTML = '';
  if(layers.length===0){
    layerListEl.innerHTML = '<div class="layer-empty">Brak warstw — dodaj tekst, obraz, kształt albo emoji z panelu po lewej.</div>';
    return;
  }
  for(let i=layers.length-1;i>=0;i--){
    const l = layers[i];
    const div = document.createElement('div');
    div.className = 'layer-item' + (l.id===selectedId? ' selected':'');
    div.draggable = true;
    div.dataset.layerId = l.id;
    div.innerHTML = `<span class="drag-handle" title="Przeciągnij, żeby zmienić kolejność warstw">⠿</span><span class="ic">${LAYER_ICONS[l.type]||'▪'}</span><span class="name">${escapeHtml(layerLabel(l))}</span><button data-act="del">✕</button>`;
    div.addEventListener('click',(e)=>{
      if(e.target.dataset.act==='del'){ deleteLayer(l.id); return; }
      selectLayer(l.id);
    });
    div.addEventListener('dragstart', (e)=>{
      dragLayerId = l.id;
      div.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
    });
    div.addEventListener('dragend', ()=>{
      div.classList.remove('dragging');
      dragLayerId = null;
      layerListEl.querySelectorAll('.layer-item').forEach(el=>el.classList.remove('drag-over'));
    });
    div.addEventListener('dragover', (e)=>{
      e.preventDefault();
      if(dragLayerId && dragLayerId!==l.id) div.classList.add('drag-over');
    });
    div.addEventListener('dragleave', ()=>{ div.classList.remove('drag-over'); });
    div.addEventListener('drop', (e)=>{
      e.preventDefault();
      div.classList.remove('drag-over');
      if(dragLayerId && dragLayerId!==l.id) reorderLayer(dragLayerId, l.id);
      dragLayerId = null;
    });
    layerListEl.appendChild(div);
  }
}

function escapeHtml(s){ return (s||'').replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

// ---------- ZAKŁADKI ----------
document.querySelectorAll('.tab-btn').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    if(btn.dataset.tab!=='retouch'){ retouchTool=null; cropState=null; mainCanvas.style.cursor='default'; render(); }
    currentTab = btn.dataset.tab;
    renderToolPanel();
  });
});

function renderToolPanel(){
  if(currentTab==='bg') return renderBgPanel();
  if(currentTab==='text') return renderTextPanel();
  if(currentTab==='image') return renderImagePanel();
  if(currentTab==='shape') return renderShapePanel();
  if(currentTab==='emoji') return renderEmojiPanel();
  if(currentTab==='filters') return renderFiltersPanel();
  if(currentTab==='retouch') return renderRetouchPanel();
}

function h(html){ const d=document.createElement('div'); d.innerHTML=html; return d.firstElementChild; }

// ---------- PANEL: TŁO ----------
function bgTemplateGridHtml(cat){
  const items = [];
  BG_TEMPLATES.forEach((t,i)=>{ if((t.cat||'ogolne')===cat) items.push({...t,i}); });
  if(!items.length) return '<p class="hint">Brak szablonów w tej kategorii.</p>';
  return `<div class="grid-buttons bg-template-grid" style="grid-template-columns:repeat(4,1fr); margin-bottom:16px;">
    ${items.map(t=>`<button data-i="${t.i}" title="${escapeHtml(t.name)}" style="font-size:18px; height:44px;">${t.icon}</button>`).join('')}
  </div>`;
}

function renderBgPanel(){
  toolpanel.innerHTML = `
    <h3>Gotowe zdjęcia (dokładne kopie 1:1) 📷</h3>
    <p class="hint" style="margin-top:0;">Te trzy to dokładnie te bitmapy, które przesłałeś — bez przerabiania. Klikasz i masz dokładnie to samo, a potem możesz jeszcze pokolorować/dostroić suwakami niżej (zakładka "Zdjęcie").</p>
    <div class="grid-buttons stock-bg-grid-main" style="grid-template-columns:repeat(3,1fr); margin-bottom:16px;">
      ${STOCK_BACKGROUNDS.map((sBg,i)=>`<button data-stock-i="${i}" title="${escapeHtml(sBg.name)}" style="font-size:20px; height:44px;">${sBg.icon}</button>`).join('')}
    </div>

    <h3>Szablony ogólne</h3>
    ${bgTemplateGridHtml('ogolne')}

    <h3>Tła GFX / efekty ✨</h3>
    ${bgTemplateGridHtml('gfx')}

    <h3>Tła pod zdjęcie profilowe 🙂</h3>
    ${bgTemplateGridHtml('pfp')}

    <h3>Generator tła</h3>
    <button id="randomizeBg" class="btn-primary" style="width:100%; padding:10px; border:none; border-radius:8px; margin-bottom:14px; cursor:pointer;">🎲 Losuj idealne tło</button>

    <div class="field">
      <label>Typ tła</label>
      <div class="chip-row" id="bgBaseChips">
        ${chip('none','Brak (przezroczyste)')}${chip('solid','Jednolity (1 kolor)')}${chip('linear','Gradient')}${chip('radial','Radialny')}${chip('mesh','Plamy (mesh)')}${chip('rays','Promienie 💥')}${chip('split','VS / Skos ⚡')}${chip('image','Zdjęcie 📷')}
      </div>
      <p class="hint">💡 Gradienty (Gradient / Radialny) obsługują dużo więcej niż 2 kolory — dodawaj kolejne przyciskiem "+ Dodaj kolor" (do 20 punktów).</p>
    </div>
    <div id="bgSubPanel"></div>

    <h3 style="margin-top:20px;">Wzór na wierzchu</h3>
    <div class="field">
      <div class="chip-row" id="patternChips">
        ${chip('none','Brak', bg.pattern.type)}${chip('dots','Kropki', bg.pattern.type)}${chip('lines','Linie', bg.pattern.type)}${chip('grid','Siatka', bg.pattern.type)}${chip('cross','Krata skos', bg.pattern.type)}${chip('hex','Hex (plaster miodu)', bg.pattern.type)}${chip('scan','Linie skanowania', bg.pattern.type)}${chip('halftone','Halftone (comic)', bg.pattern.type)}${chip('rings','Pierścienie (ostre)', bg.pattern.type)}${chip('bands','Pasma (miękkie, glow)', bg.pattern.type)}${chip('stars','Gwiazdki ✨', bg.pattern.type)}${chip('noise','Szum', bg.pattern.type)}
      </div>
    </div>
    <div id="patternSubPanel"></div>
  `;

  toolpanel.querySelectorAll('.stock-bg-grid-main button').forEach(b=>{
    b.onclick = ()=> loadStockBackground(+b.dataset.stockI);
  });

  toolpanel.querySelectorAll('.bg-template-grid button').forEach(b=>{
    b.onclick = ()=>{ applyBgTemplate(+b.dataset.i); };
  });

  function chip(val,label,activeVal){
    const active = activeVal ? (activeVal===val) : (bg.base===val);
    return `<button class="chip ${active?'active':''}" data-val="${val}">${label}</button>`;
  }

  document.getElementById('bgBaseChips').querySelectorAll('.chip').forEach(c=>{
    c.onclick = ()=>{ bg.base = c.dataset.val; render(); renderBgPanel(); pushHistory(); };
  });
  document.getElementById('patternChips').querySelectorAll('.chip').forEach(c=>{
    c.onclick = ()=>{ bg.pattern.type = c.dataset.val; render(); renderBgPanel(); pushHistory(); };
  });

  renderBgSubPanel();
  renderPatternSubPanel();
}

function stopsEditor(stopsArr, onChange, onStructureChange, maxStops){
  maxStops = maxStops || 20;
  const rerender = onStructureChange || renderBgPanel;
  let html = `<div class="field"><label>Kolory gradientu <span style="color:var(--text-dim);">(${stopsArr.length}/${maxStops})</span></label><div style="display:flex; flex-direction:column; gap:6px;">`;
  stopsArr.forEach((s,i)=>{
    html += `<div class="row" style="align-items:center;">
      <input type="color" data-i="${i}" class="stopColor" value="${s.c}" style="flex:0 0 60px; height:32px;">
      <input type="range" data-i="${i}" class="stopPos" min="0" max="100" value="${Math.round(s.p*100)}" style="flex:1;">
      ${stopsArr.length>2 ? `<button data-i="${i}" class="stopDel" style="background:transparent;border:none;color:var(--danger);cursor:pointer;">✕</button>`:''}
    </div>`;
  });
  html += `</div>${stopsArr.length<maxStops ? '<button id="stopAdd" class="chip" style="margin-top:8px;">+ Dodaj kolor</button>' : `<p class="hint">Maksymalnie ${maxStops} kolorów.</p>`}</div>`;
  const wrap = h(`<div>${html}</div>`);
  wrap.querySelectorAll('.stopColor').forEach(inp=>{
    inp.oninput = ()=>{ stopsArr[+inp.dataset.i].c = inp.value; onChange(); };
    inp.onchange = ()=>pushHistory();
  });
  wrap.querySelectorAll('.stopPos').forEach(inp=>{
    inp.oninput = ()=>{ stopsArr[+inp.dataset.i].p = (+inp.value)/100; onChange(); };
    inp.onchange = ()=>pushHistory();
  });
  wrap.querySelectorAll('.stopDel').forEach(btn=>{
    btn.onclick = ()=>{ stopsArr.splice(+btn.dataset.i,1); onChange(); rerender(); pushHistory(); };
  });
  const addBtn = wrap.querySelector('#stopAdd');
  if(addBtn) addBtn.onclick = ()=>{
    if(stopsArr.length>=maxStops) return;
    const pal = randomPalette();
    // Naprawa buga: nowy kolor zawsze ladowal sie na pozycji p:1, czyli DOKLADNIE tam gdzie zwykle
    // jest juz ostatni istniejacy kolor (typowy gradient 2-kolorowy konczy sie na p:1). Dwa przystanki
    // na tej samej pozycji tworza brzydki, twardy skok koloru tuz przy krawedzi ("buguje sie").
    // Teraz nowy kolor wstawiamy dokladnie w SRODEK najwiekszej wolnej przerwy miedzy istniejacymi
    // kolorami - zawsze widoczny i sensownie umiejscowiony, niezaleznie ile kolorow juz jest.
    const sorted = stopsArr.map((s,idx)=>({p:s.p, idx})).sort((a,b)=>a.p-b.p);
    let bestGap = -1, bestMid = 0.5, insertAfterIdx = stopsArr.length-1;
    for(let i=0;i<sorted.length-1;i++){
      const gap = sorted[i+1].p - sorted[i].p;
      if(gap > bestGap){ bestGap = gap; bestMid = (sorted[i].p + sorted[i+1].p)/2; insertAfterIdx = sorted[i].idx; }
    }
    stopsArr.splice(insertAfterIdx+1, 0, {c: pal[stopsArr.length % pal.length], p: bestMid});
    onChange(); rerender(); pushHistory();
  };
  return wrap;
}

function renderBgSubPanel(){
  const sp = document.getElementById('bgSubPanel');
  sp.innerHTML = '';
  if(bg.base === 'solid'){
    sp.appendChild(h(`<div class="field"><label>Kolor</label><input type="color" id="solidColor" value="${bg.solidColor}"></div>`));
    sp.querySelector('#solidColor').oninput = (e)=>{ bg.solidColor = e.target.value; render(); };
    sp.querySelector('#solidColor').onchange = ()=> pushHistory();
  } else if(bg.base === 'linear'){
    sp.appendChild(h(`<div class="field"><label>Kąt <span>${bg.linear.angle}°</span></label><input type="range" id="linAngle" min="0" max="360" value="${bg.linear.angle}"></div>`));
    sp.querySelector('#linAngle').oninput = (e)=>{ bg.linear.angle = +e.target.value; render(); sp.querySelector('label span').textContent = bg.linear.angle+'°'; };
    sp.querySelector('#linAngle').onchange = ()=> pushHistory();
    sp.appendChild(stopsEditor(bg.linear.stops, ()=>{ render(); }));
  } else if(bg.base === 'radial'){
    sp.appendChild(h(`<div class="row">
      <div class="field"><label>Środek X <span>${bg.radial.cx}%</span></label><input type="range" id="radCx" min="0" max="100" value="${bg.radial.cx}"></div>
      <div class="field"><label>Środek Y <span>${bg.radial.cy}%</span></label><input type="range" id="radCy" min="0" max="100" value="${bg.radial.cy}"></div>
    </div>`));
    sp.appendChild(h(`<div class="field"><label>Promień <span>${bg.radial.r}%</span></label><input type="range" id="radR" min="10" max="150" value="${bg.radial.r}"></div>`));
    sp.querySelector('#radCx').oninput = (e)=>{ bg.radial.cx=+e.target.value; render(); };
    sp.querySelector('#radCy').oninput = (e)=>{ bg.radial.cy=+e.target.value; render(); };
    sp.querySelector('#radR').oninput = (e)=>{ bg.radial.r=+e.target.value; render(); };
    [sp.querySelector('#radCx'),sp.querySelector('#radCy'),sp.querySelector('#radR')].forEach(i=> i.onchange = ()=>pushHistory());
    sp.appendChild(stopsEditor(bg.radial.stops, ()=>{ render(); }));
  } else if(bg.base === 'mesh'){
    sp.appendChild(h(`<div class="field"><label>Kolor bazowy</label><input type="color" id="meshBase" value="${bg.mesh.baseColor}"></div>`));
    sp.appendChild(h(`<div class="field"><label>Rozmycie plam <span>${bg.mesh.blur}</span></label><input type="range" id="meshBlur" min="0" max="100" value="${bg.mesh.blur}"></div>`));
    sp.appendChild(h(`<button id="meshRandom" class="chip" style="width:100%; margin-bottom:8px;">🎲 Losuj plamy</button>`));
    sp.querySelector('#meshBase').oninput = (e)=>{ bg.mesh.baseColor=e.target.value; render(); };
    sp.querySelector('#meshBase').onchange = ()=>pushHistory();
    sp.querySelector('#meshBlur').oninput = (e)=>{ bg.mesh.blur=+e.target.value; render(); };
    sp.querySelector('#meshBlur').onchange = ()=>pushHistory();
    sp.querySelector('#meshRandom').onclick = ()=>{ bg.mesh.blobs = randomBlobs(); render(); renderBgPanel(); pushHistory(); };
    bg.mesh.blobs.forEach((b,i)=>{
      const row = h(`<div class="row" style="align-items:center; margin-bottom:6px;">
        <input type="color" class="blobColor" data-i="${i}" value="${b.color}" style="flex:0 0 50px; height:30px;">
        <input type="range" class="blobOpacity" data-i="${i}" min="0" max="100" value="${Math.round(b.opacity)}" style="flex:1;" title="Intensywność">
      </div>`);
      row.querySelector('.blobColor').oninput=(e)=>{ b.color=e.target.value; render(); };
      row.querySelector('.blobColor').onchange=()=>pushHistory();
      row.querySelector('.blobOpacity').oninput=(e)=>{ b.opacity=+e.target.value; render(); };
      row.querySelector('.blobOpacity').onchange=()=>pushHistory();
      sp.appendChild(row);
    });
  } else if(bg.base === 'split'){
    const sp2 = bg.split;
    sp.appendChild(h(`<button id="vsPreset" class="btn-primary" style="width:100%; padding:10px; border:none; border-radius:8px; margin-bottom:12px; cursor:pointer;">⚡ Szablon VS (czerwono-niebieski)</button>`));
    sp.querySelector('#vsPreset').onclick = ()=>{
      Object.assign(bg.split, {
        angle:8, jag:35, jagSeed: makeJagSeed(9),
        color1:'#1f6fee', color2:'#e51c27', seamColor:'#ffffff', seamWidth:16
      });
      bg.split.rays = { enabled:true, opacity:22, count:16, useCustomColors:false, color1:'#5b9dff', color2:'#ff6b6b' };
      bg.split.watermark = { enabled:true, icon:'💀', size:90, spacing:170, rotation:-15, opacity:10, customSrc:null, customImg:null };
      render(); renderBgPanel(); pushHistory();
    };

    sp.appendChild(h(`<h3>Kolory i skos</h3>`));
    sp.appendChild(h(`<div class="row">
      <div class="field"><label>Kolor lewej strony</label><input type="color" id="vsColor1" value="${sp2.color1}"></div>
      <div class="field"><label>Kolor prawej strony</label><input type="color" id="vsColor2" value="${sp2.color2}"></div>
    </div>`));
    sp.appendChild(h(`<div class="field"><label>Kąt skosu <span>${sp2.angle}°</span></label><input type="range" id="vsAngle" min="-60" max="60" value="${sp2.angle}"></div>`));
    sp.appendChild(h(`<div class="field"><label>Ząbki / poszarpanie <span>${sp2.jag}</span></label><input type="range" id="vsJag" min="0" max="120" value="${sp2.jag}"></div>`));
    sp.appendChild(h(`<button id="vsJagRandom" class="chip" style="width:100%; margin-bottom:10px;">🎲 Losuj ząbki błyskawicy</button>`));
    sp.appendChild(h(`<div class="row">
      <div class="field"><label>Kolor "błyskawicy"</label><input type="color" id="vsSeamColor" value="${sp2.seamColor}"></div>
      <div class="field"><label>Grubość <span>${sp2.seamWidth}</span></label><input type="range" id="vsSeamWidth" min="0" max="60" value="${sp2.seamWidth}"></div>
    </div>`));

    sp.appendChild(h(`<h3 style="margin-top:16px;">Promienie (jak w mandze)</h3>`));
    sp.appendChild(h(`<div class="field"><label>Włącz promienie <input type="checkbox" id="vsRaysOn" ${sp2.rays.enabled?'checked':''}></label></div>`));
    if(sp2.rays.enabled){
      sp.appendChild(h(`<div class="field"><label>Ilość <span>${sp2.rays.count}</span></label><input type="range" id="vsRaysCount" min="4" max="40" value="${sp2.rays.count}"></div>`));
      sp.appendChild(h(`<div class="field"><label>Przezroczystość <span>${sp2.rays.opacity}%</span></label><input type="range" id="vsRaysOpacity" min="0" max="100" value="${sp2.rays.opacity}"></div>`));
      sp.appendChild(h(`<div class="field"><label>Własne kolory promieni <input type="checkbox" id="vsRaysCustom" ${sp2.rays.useCustomColors?'checked':''}></label></div>`));
      if(sp2.rays.useCustomColors){
        sp.appendChild(h(`<div class="row">
          <div class="field"><label>Promienie (lewo)</label><input type="color" id="vsRaysColor1" value="${sp2.rays.color1}"></div>
          <div class="field"><label>Promienie (prawo)</label><input type="color" id="vsRaysColor2" value="${sp2.rays.color2}"></div>
        </div>`));
      }
    }

    sp.appendChild(h(`<h3 style="margin-top:16px;">Wzorek w tle (naklejki)</h3>`));
    sp.appendChild(h(`<div class="field"><label>Włącz wzorek <input type="checkbox" id="vsWmOn" ${sp2.watermark.enabled?'checked':''}></label></div>`));
    if(sp2.watermark.enabled){
      const icons = ['💀','🔥','⭐','⚡','❤️','👑','💯','✅','🎮','🏆'];
      sp.appendChild(h(`<div class="field"><label>Ikona</label><div class="chip-row" id="vsWmIcons">${icons.map(ic=>`<button class="chip ${sp2.watermark.icon===ic&&!sp2.watermark.customImg?'active':''}" data-ic="${ic}" style="font-size:16px;">${ic}</button>`).join('')}</div></div>`));
      sp.appendChild(h(`<div class="upload-btn" id="vsWmUpload" style="margin-bottom:10px; padding:12px;">📤 Albo wgraj własną ikonę (PNG)</div>`));
      sp.appendChild(h(`<div class="field"><label>Rozmiar <span>${sp2.watermark.size}px</span></label><input type="range" id="vsWmSize" min="20" max="300" value="${sp2.watermark.size}"></div>`));
      sp.appendChild(h(`<div class="field"><label>Odstęp <span>${sp2.watermark.spacing}</span></label><input type="range" id="vsWmSpacing" min="40" max="500" value="${sp2.watermark.spacing}"></div>`));
      sp.appendChild(h(`<div class="field"><label>Rotacja <span>${sp2.watermark.rotation}°</span></label><input type="range" id="vsWmRotation" min="-90" max="90" value="${sp2.watermark.rotation}"></div>`));
      sp.appendChild(h(`<div class="field"><label>Przezroczystość <span>${sp2.watermark.opacity}%</span></label><input type="range" id="vsWmOpacity" min="0" max="100" value="${sp2.watermark.opacity}"></div>`));
    }

    // bindowanie
    const upd = fn=>{ fn(); render(); };
    sp.querySelector('#vsColor1').oninput = e=>upd(()=>sp2.color1=e.target.value);
    sp.querySelector('#vsColor1').onchange = ()=>pushHistory();
    sp.querySelector('#vsColor2').oninput = e=>upd(()=>sp2.color2=e.target.value);
    sp.querySelector('#vsColor2').onchange = ()=>pushHistory();
    sp.querySelector('#vsAngle').oninput = e=>upd(()=>sp2.angle=+e.target.value);
    sp.querySelector('#vsAngle').onchange = ()=>pushHistory();
    sp.querySelector('#vsJag').oninput = e=>upd(()=>sp2.jag=+e.target.value);
    sp.querySelector('#vsJag').onchange = ()=>pushHistory();
    sp.querySelector('#vsJagRandom').onclick = ()=>{ sp2.jagSeed = makeJagSeed(sp2.jagSeed.length); render(); pushHistory(); };
    sp.querySelector('#vsSeamColor').oninput = e=>upd(()=>sp2.seamColor=e.target.value);
    sp.querySelector('#vsSeamColor').onchange = ()=>pushHistory();
    sp.querySelector('#vsSeamWidth').oninput = e=>upd(()=>sp2.seamWidth=+e.target.value);
    sp.querySelector('#vsSeamWidth').onchange = ()=>pushHistory();
    sp.querySelector('#vsRaysOn').onchange = e=>{ sp2.rays.enabled=e.target.checked; render(); renderBgPanel(); pushHistory(); };
    const rc = sp.querySelector('#vsRaysCount'), ro = sp.querySelector('#vsRaysOpacity'), rcu = sp.querySelector('#vsRaysCustom');
    if(rc){ rc.oninput=e=>upd(()=>sp2.rays.count=+e.target.value); rc.onchange=()=>pushHistory(); }
    if(ro){ ro.oninput=e=>upd(()=>sp2.rays.opacity=+e.target.value); ro.onchange=()=>pushHistory(); }
    if(rcu){ rcu.onchange=e=>{ sp2.rays.useCustomColors=e.target.checked; render(); renderBgPanel(); pushHistory(); }; }
    const rc1 = sp.querySelector('#vsRaysColor1'), rc2 = sp.querySelector('#vsRaysColor2');
    if(rc1){ rc1.oninput=e=>upd(()=>sp2.rays.color1=e.target.value); rc1.onchange=()=>pushHistory(); }
    if(rc2){ rc2.oninput=e=>upd(()=>sp2.rays.color2=e.target.value); rc2.onchange=()=>pushHistory(); }
    const wmOn = sp.querySelector('#vsWmOn');
    if(wmOn) wmOn.onchange = e=>{ sp2.watermark.enabled=e.target.checked; render(); renderBgPanel(); pushHistory(); };
    const wmIcons = sp.querySelector('#vsWmIcons');
    if(wmIcons) wmIcons.querySelectorAll('button').forEach(b=>{
      b.onclick = ()=>{ sp2.watermark.icon=b.dataset.ic; sp2.watermark.customImg=null; render(); renderBgPanel(); pushHistory(); };
    });
    const wmUpload = sp.querySelector('#vsWmUpload');
    if(wmUpload) wmUpload.onclick = ()=> vsWatermarkInput.click();
    const wmSize = sp.querySelector('#vsWmSize'), wmSpacing = sp.querySelector('#vsWmSpacing'), wmRot = sp.querySelector('#vsWmRotation'), wmOp = sp.querySelector('#vsWmOpacity');
    if(wmSize){ wmSize.oninput=e=>upd(()=>sp2.watermark.size=+e.target.value); wmSize.onchange=()=>pushHistory(); }
    if(wmSpacing){ wmSpacing.oninput=e=>upd(()=>sp2.watermark.spacing=+e.target.value); wmSpacing.onchange=()=>pushHistory(); }
    if(wmRot){ wmRot.oninput=e=>upd(()=>sp2.watermark.rotation=+e.target.value); wmRot.onchange=()=>pushHistory(); }
    if(wmOp){ wmOp.oninput=e=>upd(()=>sp2.watermark.opacity=+e.target.value); wmOp.onchange=()=>pushHistory(); }
  } else if(bg.base === 'rays'){
    const rb = bg.rays;
    const upd = fn=>{ fn(); render(); };
    sp.appendChild(h(`<div class="row">
      <div class="field"><label>Kolor środka</label><input type="color" id="rayCenter" value="${rb.centerColor}"></div>
      <div class="field"><label>Kolor krawędzi</label><input type="color" id="rayEdge" value="${rb.edgeColor}"></div>
    </div>`));
    sp.appendChild(h(`<div class="field"><label>Kolor promieni</label><input type="color" id="rayLineColor" value="${rb.lineColor}"></div>`));
    sp.appendChild(h(`<div class="field"><label>Przezroczystość promieni <span>${rb.lineOpacity}%</span></label><input type="range" id="rayOpacity" min="5" max="100" value="${rb.lineOpacity}"></div>`));
    sp.appendChild(h(`<div class="field"><label>Ilość promieni <span>${rb.count}</span></label><input type="range" id="rayCount" min="8" max="120" value="${rb.count}"></div>`));
    sp.appendChild(h(`<div class="row">
      <div class="field"><label>Min. długość <span>${rb.minLen}%</span></label><input type="range" id="rayMinLen" min="5" max="100" value="${rb.minLen}"></div>
      <div class="field"><label>Maks. długość <span>${rb.maxLen}%</span></label><input type="range" id="rayMaxLen" min="50" max="220" value="${rb.maxLen}"></div>
    </div>`));
    sp.appendChild(h(`<div class="row">
      <div class="field"><label>Min. grubość <span>${rb.minThick}</span></label><input type="range" id="rayMinThick" min="0" max="30" value="${rb.minThick}"></div>
      <div class="field"><label>Maks. grubość <span>${rb.maxThick}</span></label><input type="range" id="rayMaxThick" min="5" max="80" value="${rb.maxThick}"></div>
    </div>`));
    sp.appendChild(h(`<div class="field"><label>Jasny środek (blask) <span>${rb.glow}%</span></label><input type="range" id="rayGlow" min="0" max="100" value="${rb.glow}"></div>`));
    sp.appendChild(h(`<div class="field"><label>Poświata linii (neon) <span>${rb.lineGlow||0}%</span></label><input type="range" id="rayLineGlow" min="0" max="100" value="${rb.lineGlow||0}"></div>`));
    sp.appendChild(h(`<p class="hint" style="margin-top:0;">💡 "Poświata linii" dodaje miękki, rozmyty blask wokół KAŻDEGO promienia z osobna — dzięki temu cienkie promienie wyglądają jak świecące neonówki, a nie płaskie, twarde trójkąty.</p>`));
    sp.appendChild(h(`<div class="field"><label>Luka od środka <span>${rb.innerGap||0}%</span></label><input type="range" id="rayInnerGap" min="0" max="60" value="${rb.innerGap||0}"></div>`));
    sp.appendChild(h(`<div class="row">
      <div class="field"><label>Środek X <span>${rb.focalX}%</span></label><input type="range" id="rayFx" min="0" max="100" value="${rb.focalX}"></div>
      <div class="field"><label>Środek Y <span>${rb.focalY}%</span></label><input type="range" id="rayFy" min="0" max="100" value="${rb.focalY}"></div>
    </div>`));
    sp.appendChild(h(`<button id="rayRandom" class="chip" style="width:100%; margin-top:6px;">🎲 Losuj układ promieni</button>`));

    const rc = sp.querySelector('#rayCenter'), re = sp.querySelector('#rayEdge'), rl = sp.querySelector('#rayLineColor');
    rc.oninput=e=>upd(()=>rb.centerColor=e.target.value); rc.onchange=()=>pushHistory();
    re.oninput=e=>upd(()=>rb.edgeColor=e.target.value); re.onchange=()=>pushHistory();
    rl.oninput=e=>upd(()=>rb.lineColor=e.target.value); rl.onchange=()=>pushHistory();
    const bindR = (id,key)=>{ const el=sp.querySelector(id); el.oninput=e=>upd(()=>rb[key]=+e.target.value); el.onchange=()=>pushHistory(); };
    bindR('#rayOpacity','lineOpacity'); bindR('#rayCount','count'); bindR('#rayMinLen','minLen'); bindR('#rayMaxLen','maxLen');
    bindR('#rayMinThick','minThick'); bindR('#rayMaxThick','maxThick'); bindR('#rayGlow','glow'); bindR('#rayLineGlow','lineGlow'); bindR('#rayInnerGap','innerGap'); bindR('#rayFx','focalX'); bindR('#rayFy','focalY');
    sp.querySelector('#rayCount').addEventListener('change', ()=>{ rb.seed = makeRaySeed(rb.count, rb.seedOpts); render(); pushHistory(); });
    sp.querySelector('#rayRandom').onclick = ()=>{ rb.seed = makeRaySeed(rb.count, rb.seedOpts); render(); pushHistory(); };
  } else if(bg.base === 'image'){
    const bi = bg.image;
    sp.appendChild(h(`<h3 style="margin-top:0;">Gotowe tła 🖼️</h3>`));
    sp.appendChild(h(`<div class="grid-buttons stock-bg-grid" style="grid-template-columns:repeat(3,1fr); margin-bottom:12px;">
      ${STOCK_BACKGROUNDS.map((sBg,i)=>`<button data-stock-i="${i}" title="${escapeHtml(sBg.name)}" style="font-size:20px; height:44px;">${sBg.icon}</button>`).join('')}
    </div>`));
    sp.appendChild(h(`<div class="upload-btn" id="bgImgUpload">📤 ${bi.src?'Zmień zdjęcie tła (własny plik)':'Albo wgraj własne zdjęcie jako tło'}</div>`));
    if(bi.src){
      sp.appendChild(h(`<div class="field"><label>Powiększenie <span>${bi.scale}%</span></label><input type="range" id="bgImgScale" min="50" max="400" value="${bi.scale}"></div>`));
      sp.appendChild(h(`<div class="field"><label>Pozycja pozioma <span>${bi.offsetX}%</span></label><input type="range" id="bgImgOffX" min="-50" max="150" value="${bi.offsetX}"></div>`));
      sp.appendChild(h(`<div class="field"><label>Pozycja pionowa <span>${bi.offsetY}%</span></label><input type="range" id="bgImgOffY" min="-50" max="150" value="${bi.offsetY}"></div>`));
      sp.appendChild(h(`<div class="field"><label>Rozmycie tła <span>${bi.blurBg}px</span></label><input type="range" id="bgImgBlur" min="0" max="40" value="${bi.blurBg}"></div>`));
      sp.appendChild(h(`<h3 style="margin-top:14px;">Edycja koloru wgranego tła</h3>`));
      sp.appendChild(h(`<div class="field"><label>Obrót odcienia (przekoloruj) <span>${bi.hueRotate}°</span></label><input type="range" id="bgImgHue" min="0" max="360" value="${bi.hueRotate}"></div>`));
      sp.appendChild(h(`<div class="field"><label>Jasność <span>${bi.brightness}%</span></label><input type="range" id="bgImgBrightness" min="0" max="200" value="${bi.brightness}"></div>`));
      sp.appendChild(h(`<div class="field"><label>Kontrast <span>${bi.contrast}%</span></label><input type="range" id="bgImgContrast" min="0" max="200" value="${bi.contrast}"></div>`));
      sp.appendChild(h(`<div class="field"><label>Nasycenie <span>${bi.saturate}%</span></label><input type="range" id="bgImgSaturate" min="0" max="200" value="${bi.saturate}"></div>`));
      sp.appendChild(h(`<p class="hint">💡 Masz jeden plik (np. zielone promienie), a suwakiem "Obrót odcienia" zrobisz z niego wersję pomarańczową, fioletową, niebieską itd. — bez szukania kolejnych plików.</p>`));
      sp.appendChild(h(`<p class="hint">Powiększ i przesuń zdjęcie tak, żeby najlepszy fragment był widoczny w kadrze — reszta chowa się poza widoczność, dokładnie jak w Canvie.</p>`));
    }
    sp.querySelector('#bgImgUpload').onclick = ()=> bgImageInput.click();
    sp.querySelectorAll('.stock-bg-grid button').forEach(b=>{
      b.onclick = ()=> loadStockBackground(+b.dataset.stockI);
    });
    const upd = fn=>{ fn(); render(); };
    const bs = sp.querySelector('#bgImgScale'), bx = sp.querySelector('#bgImgOffX'), by = sp.querySelector('#bgImgOffY'), bb = sp.querySelector('#bgImgBlur');
    if(bs){ bs.oninput=e=>upd(()=>bi.scale=+e.target.value); bs.onchange=()=>pushHistory(); }
    if(bx){ bx.oninput=e=>upd(()=>bi.offsetX=+e.target.value); bx.onchange=()=>pushHistory(); }
    if(by){ by.oninput=e=>upd(()=>bi.offsetY=+e.target.value); by.onchange=()=>pushHistory(); }
    if(bb){ bb.oninput=e=>upd(()=>bi.blurBg=+e.target.value); bb.onchange=()=>pushHistory(); }
    const bh = sp.querySelector('#bgImgHue'), bBr = sp.querySelector('#bgImgBrightness'), bC = sp.querySelector('#bgImgContrast'), bS = sp.querySelector('#bgImgSaturate');
    if(bh){ bh.oninput=e=>upd(()=>bi.hueRotate=+e.target.value); bh.onchange=()=>pushHistory(); }
    if(bBr){ bBr.oninput=e=>upd(()=>bi.brightness=+e.target.value); bBr.onchange=()=>pushHistory(); }
    if(bC){ bC.oninput=e=>upd(()=>bi.contrast=+e.target.value); bC.onchange=()=>pushHistory(); }
    if(bS){ bS.oninput=e=>upd(()=>bi.saturate=+e.target.value); bS.onchange=()=>pushHistory(); }
  }
}

function renderPatternSubPanel(){
  const sp = document.getElementById('patternSubPanel');
  sp.innerHTML='';
  if(bg.pattern.type==='none') return;
  sp.appendChild(h(`<div class="field"><label>Kolor wzoru</label><input type="color" id="patColor" value="${bg.pattern.color}"></div>`));
  sp.appendChild(h(`<div class="field"><label>Przezroczystość <span>${bg.pattern.opacity}%</span></label><input type="range" id="patOpacity" min="0" max="100" value="${bg.pattern.opacity}"></div>`));
  if(bg.pattern.type!=='noise'){
    sp.appendChild(h(`<div class="field"><label>Rozmiar / odstęp <span>${bg.pattern.size}</span></label><input type="range" id="patSize" min="6" max="80" value="${bg.pattern.size}"></div>`));
    sp.appendChild(h(`<div class="field"><label>Kąt <span>${bg.pattern.angle}°</span></label><input type="range" id="patAngle" min="0" max="180" value="${bg.pattern.angle}"></div>`));
  }
  sp.querySelector('#patColor').oninput=(e)=>{ bg.pattern.color=e.target.value; render(); };
  sp.querySelector('#patColor').onchange=()=>pushHistory();
  sp.querySelector('#patOpacity').oninput=(e)=>{ bg.pattern.opacity=+e.target.value; render(); };
  sp.querySelector('#patOpacity').onchange=()=>pushHistory();
  const sizeI = sp.querySelector('#patSize'), angI = sp.querySelector('#patAngle');
  if(sizeI){ sizeI.oninput=(e)=>{ bg.pattern.size=+e.target.value; render(); }; sizeI.onchange=()=>pushHistory(); }
  if(angI){ angI.oninput=(e)=>{ bg.pattern.angle=+e.target.value; render(); }; angI.onchange=()=>pushHistory(); }
}

document.getElementById('toolpanel').addEventListener('click', (e)=>{
  if(e.target && e.target.id==='randomizeBg') randomizeBackground();
});

// ---------- GOTOWE SZABLONY TŁA (własny generator, nie kopie gotowych grafik) ----------
const BG_TEMPLATES = [
  { name:'Paski + blask (zielony)', icon:'🟢', apply:()=>{
    bg.base='radial';
    bg.radial = { cx:50, cy:50, r:75, stops:[{c:'#5ee65e',p:0},{c:'#0b3d0b',p:1}] };
    bg.pattern = { type:'lines', color:'#062606', opacity:35, size:46, angle:90 };
  }},
  { name:'Reflektor niebieski', icon:'🔵', apply:()=>{
    bg.base='radial';
    bg.radial = { cx:50, cy:52, r:80, stops:[{c:'#12b7f5',p:0},{c:'#0a3ed6',p:1}] };
    bg.pattern = { type:'none', color:'#ffffff', opacity:20, size:24, angle:0 };
  }},
  { name:'Promienie pomarańczowe', icon:'🟠', apply:()=>{
    bg.base='rays';
    const cornerWin = [
      [Math.PI/4-0.4, Math.PI/4+0.4],
      [3*Math.PI/4-0.4, 3*Math.PI/4+0.4],
      [5*Math.PI/4-0.4, 5*Math.PI/4+0.4],
      [7*Math.PI/4-0.4, 7*Math.PI/4+0.4]
    ];
    Object.assign(bg.rays, {
      centerColor:'#ffb25e', edgeColor:'#e8511c', lineColor:'#ffdca0', lineOpacity:85,
      count:28, minLen:45, maxLen:140, minThick:4, maxThick:34, innerGap:38,
      focalX:50, focalY:50, glow:35
    });
    bg.rays.seedOpts = {clusterMin:2, clusterMax:4, clusterSpread:0.12, windows:cornerWin};
    bg.rays.seed = makeRaySeed(bg.rays.count, bg.rays.seedOpts);
    bg.pattern = { type:'none', color:'#ffffff', opacity:20, size:24, angle:0 };
  }},
  { name:'Promienie zielone', icon:'🟩', apply:()=>{
    bg.base='rays';
    const sideWin = [ [-0.85, 0.85], [Math.PI-0.85, Math.PI+0.85] ]; // z lewej i prawej, pusto gora/dol i srodek
    Object.assign(bg.rays, {
      centerColor:'#79e34f', edgeColor:'#1f9e2e', lineColor:'#1c7a26', lineOpacity:55,
      count:46, minLen:30, maxLen:130, minThick:1, maxThick:10, innerGap:22,
      focalX:50, focalY:50, glow:55
    });
    bg.rays.seedOpts = {clusterMin:2, clusterMax:3, clusterSpread:0.05, windows:sideWin};
    bg.rays.seed = makeRaySeed(bg.rays.count, bg.rays.seedOpts);
    bg.pattern = { type:'none', color:'#ffffff', opacity:20, size:24, angle:0 };
  }},
  { name:'Neonowe promienie fiolet', icon:'🟣', apply:()=>{
    bg.base='rays';
    Object.assign(bg.rays, {
      centerColor:'#c93fe0', edgeColor:'#7b1fc9', lineColor:'#ffffff', lineOpacity:80,
      count:26, minLen:40, maxLen:160, minThick:1, maxThick:6, innerGap:16,
      focalX:50, focalY:50, glow:55
    });
    bg.rays.seedOpts = {clusterMin:2, clusterMax:3, clusterSpread:0.04};
    bg.rays.seed = makeRaySeed(bg.rays.count, bg.rays.seedOpts);
    bg.pattern = { type:'dots', color:'#ffffff', opacity:25, size:80, angle:0 };
  }},
  { name:'Siatka czerwona', icon:'🟥', apply:()=>{
    bg.base='radial';
    bg.radial = { cx:50, cy:50, r:90, stops:[{c:'#7a0000',p:0},{c:'#2b0000',p:1}] };
    bg.pattern = { type:'grid', color:'#ff2b2b', opacity:18, size:64, angle:0 };
  }},
  { name:'Siatka ciemna', icon:'⬛', apply:()=>{
    bg.base='solid';
    bg.solidColor = '#14161d';
    bg.pattern = { type:'grid', color:'#3a4356', opacity:35, size:56, angle:0 };
  }},
  { name:'Szablon VS', icon:'⚡', apply:()=>{
    bg.base='split';
    Object.assign(bg.split, {
      angle:8, jag:35, jagSeed: makeJagSeed(bg.split.jagSeed.length),
      color1:'#1f6fee', color2:'#e51c27', seamColor:'#ffffff', seamWidth:16
    });
    bg.split.rays = { enabled:true, opacity:22, count:16, useCustomColors:false, color1:'#5b9dff', color2:'#ff6b6b' };
    bg.split.watermark = { enabled:true, icon:'💀', size:90, spacing:170, rotation:-15, opacity:10, customSrc:null, customImg:null };
    bg.pattern = { type:'none', color:'#ffffff', opacity:20, size:24, angle:0 };
  }},
  // ---- Tła GFX / efekty ----
  { name:'Glitch / cyber', icon:'🟪', cat:'gfx', apply:()=>{
    bg.base='linear';
    bg.linear = { angle:135, stops:[{c:'#0d0221',p:0},{c:'#190535',p:0.5},{c:'#2c0735',p:1}] };
    bg.pattern = { type:'scan', color:'#ff2bd6', opacity:22, size:10, angle:0 };
  }},
  { name:'Halftone comic', icon:'🟨', cat:'gfx', apply:()=>{
    bg.base='solid'; bg.solidColor='#ffcf3d';
    bg.pattern = { type:'halftone', color:'#1a1a1a', opacity:70, size:26, angle:0 };
  }},
  { name:'Tech hex', icon:'⬡', cat:'gfx', apply:()=>{
    bg.base='radial';
    bg.radial = { cx:50, cy:50, r:90, stops:[{c:'#0a3d3d',p:0},{c:'#031414',p:1}] };
    bg.pattern = { type:'hex', color:'#00ffc3', opacity:30, size:44, angle:0 };
  }},
  { name:'Krata mono', icon:'⬛', cat:'gfx', apply:()=>{
    bg.base='solid'; bg.solidColor='#1a1a1a';
    bg.pattern = { type:'cross', color:'#ffffff', opacity:14, size:20, angle:0 };
  }},
  { name:'Neon scanline', icon:'📺', cat:'gfx', apply:()=>{
    bg.base='radial';
    bg.radial = { cx:50, cy:40, r:85, stops:[{c:'#ff0080',p:0},{c:'#1a0033',p:1}] };
    bg.pattern = { type:'scan', color:'#00eaff', opacity:16, size:8, angle:0 };
  }},
  // ---- Tła pod zdjęcie profilowe ----
  { name:'Pastelowe plamy', icon:'🎨', cat:'pfp', apply:()=>{
    bg.base='mesh';
    bg.mesh = { baseColor:'#fdf1e6', blur:60, blobs:[
      {x:30,y:30,r:55,color:'#ffb6c1',opacity:70},
      {x:70,y:65,r:55,color:'#a0e7e5',opacity:70},
      {x:50,y:80,r:45,color:'#ffe08a',opacity:60},
      {x:65,y:25,r:40,color:'#c3aed6',opacity:60}
    ]};
    bg.pattern = { type:'none', color:'#ffffff', opacity:20, size:24, angle:0 };
  }},
  { name:'Duotone glow', icon:'🌗', cat:'pfp', apply:()=>{
    bg.base='radial';
    bg.radial = { cx:50, cy:50, r:75, stops:[{c:'#ff6a3d',p:0},{c:'#3d0a52',p:1}] };
    bg.pattern = { type:'none', color:'#ffffff', opacity:20, size:24, angle:0 };
  }},
  { name:'Minimalny blok koloru', icon:'🟦', cat:'pfp', apply:()=>{
    bg.base='solid'; bg.solidColor='#3d5afe';
    bg.pattern = { type:'none', color:'#ffffff', opacity:20, size:24, angle:0 };
  }},
  { name:'Miękki gradient', icon:'🌤️', cat:'pfp', apply:()=>{
    bg.base='linear';
    bg.linear = { angle:160, stops:[{c:'#a1c4fd',p:0},{c:'#c2e9fb',p:1}] };
    bg.pattern = { type:'none', color:'#ffffff', opacity:20, size:24, angle:0 };
  }},
  // ---- Kolejne tla GFX (inspirowane "speed lines" z miniaturek gamingowych) ----
  { name:'Wybuch pomarańczowy', icon:'🟠', cat:'gfx', apply:()=>{
    bg.base='rays';
    bg.rays = {
      centerColor:'#ffd76b', edgeColor:'#e2450f', lineColor:'#ffb347', lineOpacity:55,
      count:46, minLen:35, maxLen:150, minThick:2, maxThick:26, innerGap:12,
      focalX:50, focalY:50, glow:60, lineGlow:35, seedOpts:null, seed: makeRaySeed(46)
    };
    bg.pattern = { type:'none', color:'#ffffff', opacity:20, size:24, angle:0 };
  }},
  { name:'Neon fiolet', icon:'🟣', cat:'gfx', apply:()=>{
    bg.base='rays';
    bg.rays = {
      centerColor:'#f24bff', edgeColor:'#4a0a8f', lineColor:'#ffffff', lineOpacity:85,
      count:26, minLen:60, maxLen:260, minThick:1, maxThick:5, innerGap:20,
      focalX:50, focalY:50, glow:75, lineGlow:80, seedOpts:null, seed: makeRaySeed(26)
    };
    bg.pattern = { type:'stars', color:'#ffffff', opacity:35, size:60, angle:0 };
  }},
  { name:'Cyber turkus', icon:'🔵', cat:'gfx', apply:()=>{
    bg.base='rays';
    bg.rays = {
      centerColor:'#8ef8ff', edgeColor:'#0f7fd6', lineColor:'#075a9e', lineOpacity:75,
      count:34, minLen:40, maxLen:170, minThick:4, maxThick:22, innerGap:14,
      focalX:50, focalY:50, glow:45, lineGlow:45, seedOpts:null, seed: makeRaySeed(34)
    };
    bg.pattern = { type:'bands', color:'#bdf3ff', opacity:35, size:60, angle:0 };
  }},
  { name:'Gwiaździste niebo', icon:'✨', cat:'gfx', apply:()=>{
    bg.base='radial';
    bg.radial = { cx:50, cy:35, r:100, stops:[{c:'#1b2a52',p:0},{c:'#050814',p:1}] };
    bg.pattern = { type:'stars', color:'#ffffff', opacity:80, size:34, angle:0 };
  }}
];
function applyBgTemplate(i){
  BG_TEMPLATES[i].apply();
  render(); renderBgPanel(); pushHistory();
}

// Wczytuje jedno z gotowych, wbudowanych teł-zdjęć (dokładna kopia bitmapy, 1:1) jako tło typu
// "Zdjęcie" - od razu podpięte pod pełną istniejącą edycję zdjęcia w tle (obrót odcienia,
// jasność, kontrast, nasycenie, rozmycie, powiększenie, pozycja).
function loadStockBackground(i){
  const sBg = STOCK_BACKGROUNDS[i];
  if(!sBg) return;
  const img = new Image();
  img.onload = ()=>{
    bg.base = 'image';
    bg.image = { src: sBg.data, img, offsetX:50, offsetY:50, scale:100, blurBg:0, brightness:100, contrast:100, saturate:100, hueRotate:0 };
    render(); renderBgPanel(); pushHistory();
  };
  img.src = sBg.data;
}

function randomizeBackground(){
  const modes = ['linear','radial','mesh','split','rays'];
  bg.base = modes[Math.floor(Math.random()*modes.length)];
  const pal = randomPalette();
  if(bg.base==='linear'){
    bg.linear.angle = Math.floor(Math.random()*360);
    bg.linear.stops = [{c:pal[0],p:0},{c:pal[1],p:1}];
  } else if(bg.base==='radial'){
    bg.radial.cx = 30+Math.random()*40; bg.radial.cy = 30+Math.random()*40; bg.radial.r = 60+Math.random()*60;
    bg.radial.stops = [{c:pal[0],p:0},{c:pal[1],p:1}];
  } else if(bg.base==='mesh'){
    bg.mesh.baseColor = pal[3];
    bg.mesh.blobs = randomBlobs();
    bg.mesh.blur = 40+Math.random()*40;
  } else if(bg.base==='split'){
    bg.split.color1 = pal[0]; bg.split.color2 = pal[1];
    bg.split.angle = Math.round((Math.random()*40-20));
    bg.split.jag = 15+Math.random()*70;
    bg.split.jagSeed = makeJagSeed(bg.split.jagSeed.length);
    bg.split.rays.enabled = Math.random()>0.3;
    bg.split.rays.opacity = 12+Math.random()*25;
    bg.split.watermark.enabled = Math.random()>0.4;
  } else if(bg.base==='rays'){
    bg.rays.centerColor = pal[0]; bg.rays.edgeColor = pal[2];
    bg.rays.lineColor = Math.random()>0.5 ? '#ffffff' : pal[1];
    bg.rays.lineOpacity = 35+Math.random()*40;
    bg.rays.count = 20+Math.floor(Math.random()*60);
    bg.rays.minLen = 20+Math.random()*30;
    bg.rays.maxLen = 100+Math.random()*100;
    bg.rays.minThick = Math.random()*4;
    bg.rays.maxThick = 8+Math.random()*30;
    bg.rays.glow = 30+Math.random()*60;
    bg.rays.seed = makeRaySeed(bg.rays.count);
  }
  const patTypes = ['none','none','dots','grid','noise'];
  bg.pattern.type = patTypes[Math.floor(Math.random()*patTypes.length)];
  bg.pattern.opacity = 10+Math.random()*20;
  bg.pattern.size = 14+Math.random()*30;
  bg.pattern.angle = Math.floor(Math.random()*180);
  bg.pattern.color = '#ffffff';
  render(); renderBgPanel(); pushHistory();
}

// ---------- PANEL: TEKST ----------
// Fonty WBUDOWANE w plugin (fonts.css, dzialaja w 100% offline, gwarantowane)
const FONTS_EMBEDDED = [
  'Anton','Bebas Neue','Archivo Black','Alfa Slab One','Russo One','Staatliches',
  'Bangers','Creepster','Shrikhand','Bungee','Righteous','Poppins Black',
  'Oswald','Orbitron','VT323','Press Start 2P','Fredoka','Permanent Marker',
  'Bad Script','Kalam','Caveat','Sacramento','Pacifico','Lobster',
  'Montserrat','Raleway','Poppins','Open Sans','Nunito','Rubik','Inter','Barlow',
  'Work Sans','Quicksand','Comfortaa','DM Sans','Manrope','Karla','Mukta','Ubuntu',
  'PT Sans','Lora','Playfair Display','Crimson Text','Cinzel','Abril Fatface',
  'Passion One','Rammetto One','Baloo 2','Titan One','Fjalla One'
];
// Fonty SYSTEMOWE (dzialaja jesli sa zainstalowane w Windows/Office - w wiekszosci przypadkow tak)
const FONTS_SYSTEM = [
  'Arial','Arial Black','Arial Narrow','Arial Rounded MT Bold','Verdana','Tahoma','Trebuchet MS','Georgia','Times New Roman','Courier New',
  'Comic Sans MS','Impact','Segoe UI','Segoe UI Black','Segoe UI Semibold','Segoe UI Semilight','Segoe Print','Segoe Script',
  'Calibri','Cambria','Candara','Corbel','Consolas','Constantia','Franklin Gothic Book','Franklin Gothic Medium','Franklin Gothic Demi',
  'Franklin Gothic Heavy','Franklin Gothic Medium Cond','Century Gothic','Century Schoolbook','Century','Bahnschrift','Bahnschrift SemiBold',
  'Bahnschrift SemiLight','Bahnschrift Condensed','Rockwell','Rockwell Extra Bold','Rockwell Condensed','Book Antiqua','Bookman Old Style',
  'Californian FB','Cooper Black','Broadway','Britannic Bold','Berlin Sans FB','Berlin Sans FB Demi',
  'Elephant','Forte','Harrington','Jokerman','Kristen ITC','Kunstler Script','Magneto',
  'Matura MT Script Capitals','Monotype Corsiva','Papyrus','Playbill','Ravie','Showcard Gothic','Stencil',
  'Vivaldi','Viner Hand ITC','Wide Latin','Lucida Handwriting','Lucida Console','Lucida Sans Unicode','Lucida Sans','Lucida Bright',
  'Lucida Calligraphy','Lucida Fax','Lucida Sans Typewriter',
  'MV Boli','Gadugi','Ebrima','Malgun Gothic','Malgun Gothic Semilight','Microsoft Sans Serif','Freestyle Script','French Script MT',
  'Gigi','Mistral','Old English Text MT','Chiller','Blackadder ITC','Bradley Hand ITC','Curlz MT',
  'Edwardian Script ITC','Vladimir Script',
  'Agency FB','Baskerville Old Face','Bell MT','Bernard MT Condensed','Bodoni MT','Bodoni MT Black','Bodoni MT Condensed',
  'Bodoni MT Poster Compressed','Brush Script MT','Calisto MT','Castellar','Centaur','Colonna MT',
  'Copperplate Gothic Bold','Copperplate Gothic Light','Dubai','Dubai Light','Dubai Medium',
  'Engravers MT','Eras Bold ITC','Eras Demi ITC','Eras Light ITC','Eras Medium ITC',
  'Felix Titling','Footlight MT Light','Gabriola','Garamond','Gill Sans MT','Gill Sans MT Condensed',
  'Goudy Old Style','Goudy Stout','Haettenschweiler','High Tower Text','Imprint MT Shadow','Informal Roman',
  'Leelawadee','Leelawadee UI','Marlett','Meiryo','Meiryo UI','Microsoft JhengHei','Microsoft YaHei',
  'MingLiU','Miriam','MS Gothic','MS Mincho','MS PGothic','MS PMincho','MV Boli','Myanmar Text',
  'Nirmala UI','Niagara Engraved','Niagara Solid','NSimSun','Nyala','OCR A Extended','Onyx',
  'Palatino Linotype','Parchment','Perpetua','Perpetua Titling MT','Plantagenet Cherokee',
  'Sakkal Majalla','Segoe UI Historic','SimHei','SimSun','SimSun-ExtB','Sitka Text','Sitka Heading',
  'Sitka Display','Sitka Banner','Snap ITC','Sylfaen','Tempus Sans ITC','Traditional Arabic',
  'Tw Cen MT','Tw Cen MT Condensed','Univers','Urdu Typesetting','Yu Gothic','Yu Gothic UI','Yu Mincho',
  'PMingLiU','DengXian','FangSong','KaiTi','Microsoft Uighur','Microsoft Tai Le','Microsoft Himalaya',
  'Kokila','Utsaah','Aparajita','Vrinda','Shruti','Vani','Kalinga','Iskoola Pota','Latha','Gautami',
  'Mangal','Tunga','Vijaya','Estrangelo Edessa','David','Levenim MT','Miriam Fixed','Aharoni'
];
function fontFamilyCss(name){ return /[^A-Za-z0-9]/.test(name) ? `"${name}"` : name; }

const FONTS_GOOGLE = [
  "Roboto",
  "Roboto Condensed",
  "Roboto Slab",
  "Roboto Mono",
  "Roboto Serif",
  "Roboto Flex",
  "Noto Sans",
  "Noto Serif",
  "Source Sans Pro",
  "Source Serif Pro",
  "Source Code Pro",
  "IBM Plex Sans",
  "IBM Plex Serif",
  "IBM Plex Mono",
  "IBM Plex Sans Condensed",
  "Merriweather",
  "Merriweather Sans",
  "PT Serif",
  "PT Sans Narrow",
  "PT Sans Caption",
  "PT Serif Caption",
  "PT Mono",
  "Nunito Sans",
  "Mulish",
  "Josefin Sans",
  "Josefin Slab",
  "Dosis",
  "Hind",
  "Hind Siliguri",
  "Cabin",
  "Cabin Condensed",
  "Signika",
  "Signika Negative",
  "Varela Round",
  "Varela",
  "Exo",
  "Exo 2",
  "Saira",
  "Saira Condensed",
  "Saira Extra Condensed",
  "Saira Semi Condensed",
  "Saira Stencil One",
  "Chivo",
  "Heebo",
  "Assistant",
  "Rajdhani",
  "Teko",
  "Play",
  "Yanone Kaffeesatz",
  "Titillium Web",
  "Overpass",
  "Overpass Mono",
  "Cairo",
  "Cairo Play",
  "Almarai",
  "Tajawal",
  "Zilla Slab",
  "Zilla Slab Highlight",
  "Vollkorn",
  "Vollkorn SC",
  "Alegreya",
  "Alegreya Sans",
  "Alegreya Sans SC",
  "Alegreya SC",
  "Domine",
  "Bitter",
  "Bitter Pro",
  "Arvo",
  "Slabo 27px",
  "Slabo 13px",
  "Cardo",
  "Neuton",
  "Old Standard TT",
  "Spectral",
  "Spectral SC",
  "Libre Baskerville",
  "Libre Caslon Text",
  "Libre Franklin",
  "Frank Ruhl Libre",
  "EB Garamond",
  "Cormorant",
  "Cormorant Garamond",
  "Cormorant Infant",
  "Cormorant SC",
  "Cormorant Unicase",
  "Marcellus",
  "Marcellus SC",
  "Prata",
  "Italiana",
  "Italianno",
  "Cinzel Decorative",
  "Fraunces",
  "Bricolage Grotesque",
  "Sora",
  "Space Grotesk",
  "Space Mono",
  "JetBrains Mono",
  "Fira Code",
  "Fira Sans",
  "Fira Sans Condensed",
  "Fira Sans Extra Condensed",
  "Fira Mono",
  "Inconsolata",
  "Ubuntu Mono",
  "Ubuntu Condensed",
  "Ubuntu Sans",
  "Anonymous Pro",
  "Cousine",
  "Cutive Mono",
  "Cutive",
  "Courier Prime",
  "Syne",
  "Syne Mono",
  "Syne Tactile",
  "Unbounded",
  "Chakra Petch",
  "Prompt",
  "Kanit",
  "Athiti",
  "Mitr",
  "Niramit",
  "K2D",
  "Charmonman",
  "Pridi",
  "Sriracha",
  "Taviraj",
  "Bai Jamjuree",
  "Krub",
  "Maitree",
  "Trirong",
  "Chonburi",
  "Pattaya",
  "Itim",
  "Fahkwang",
  "Baloo Bhai 2",
  "Baloo Da 2",
  "Baloo Bhaijaan 2",
  "Baloo Chettan 2",
  "Baloo Paaji 2",
  "Baloo Tamma 2",
  "Baloo Tammudu 2",
  "Baloo Thambi 2",
  "Anek Latin",
  "Amaranth",
  "Advent Pro",
  "Allerta",
  "Allerta Stencil",
  "Amatic SC",
  "Amiri",
  "Antic",
  "Antic Didone",
  "Antic Slab",
  "Antonio",
  "Arapey",
  "Architects Daughter",
  "Armata",
  "Arsenal",
  "Artifika",
  "Arya",
  "Asap",
  "Asap Condensed",
  "Astloch",
  "Asul",
  "Atma",
  "Atomic Age",
  "Aubrey",
  "Audiowide",
  "Autour One",
  "Average",
  "Average Sans",
  "Averia Gruesa Libre",
  "Averia Libre",
  "Averia Sans Libre",
  "Averia Serif Libre",
  "B612",
  "B612 Mono",
  "Bahiana",
  "Bahianita",
  "Balsamiq Sans",
  "Baskervville",
  "Battambang",
  "Baumans",
  "Bayon",
  "Belgrano",
  "Bellefair",
  "Belleza",
  "BenchNine",
  "Bentham",
  "Berkshire Swash",
  "Beth Ellen",
  "Bevan",
  "Big Shoulders Display",
  "Big Shoulders Text",
  "Big Shoulders Stencil Display",
  "Big Shoulders Stencil Text",
  "Bigshot One",
  "Bilbo",
  "Bilbo Swash Caps",
  "BioRhyme",
  "BioRhyme Expanded",
  "Birthstone",
  "Biryani",
  "Black And White Picture",
  "Black Han Sans",
  "Black Ops One",
  "Blinker",
  "Bodoni Moda",
  "Bokor",
  "Bonbon",
  "Bonheur Royale",
  "Boogaloo",
  "Bowlby One",
  "Bowlby One SC",
  "Brawler",
  "Bree Serif",
  "Brygada 1918",
  "Bubblegum Sans",
  "Bubbler One",
  "Buda",
  "Buenard",
  "Bungee Hairline",
  "Bungee Inline",
  "Bungee Outline",
  "Bungee Shade",
  "Bungee Spice",
  "Butcherman",
  "Butterfly Kids",
  "Caesar Dressing",
  "Cagliostro",
  "Caladea",
  "Calistoga",
  "Calligraffitti",
  "Cambay",
  "Candal",
  "Cantarell",
  "Cantata One",
  "Cantora One",
  "Capriola",
  "Carattere",
  "Carme",
  "Carrois Gothic",
  "Carrois Gothic SC",
  "Carter One",
  "Castoro",
  "Catamaran",
  "Caudex",
  "Caveat Brush",
  "Cedarville Cursive",
  "Ceviche One",
  "Chango",
  "Charis SIL",
  "Chathura",
  "Chau Philomene One",
  "Chela One",
  "Chelsea Market",
  "Chenla",
  "Chewy",
  "Chicle",
  "Chilanka",
  "Clicker Script",
  "Coda",
  "Codystar",
  "Coiny",
  "Combo",
  "Comic Neue",
  "Coming Soon",
  "Commissioner",
  "Concert One",
  "Condiment",
  "Content",
  "Contrail One",
  "Convergence",
  "Cookie",
  "Copse",
  "Corben",
  "Coustard",
  "Covered By Your Grace",
  "Crafty Girls",
  "Crete Round",
  "Crimson Pro",
  "Croissant One",
  "Crushed",
  "Cuprum",
  "Cute Font",
  "DM Mono",
  "DM Serif Display",
  "DM Serif Text",
  "Damion",
  "Dancing Script",
  "Dangrek",
  "Darker Grotesque",
  "David Libre",
  "Dawning of a New Day",
  "Days One",
  "Dekko",
  "Dela Gothic One",
  "Delius",
  "Delius Swash Caps",
  "Delius Unicase",
  "Della Respira",
  "Denk One",
  "Devonshire",
  "Didact Gothic",
  "Diplomata",
  "Diplomata SC",
  "Do Hyeon",
  "Dokdo",
  "Donegal One",
  "Dongle",
  "Doppio One",
  "Dorsa",
  "DotGothic16",
  "Dr Sugiyama",
  "Duru Sans",
  "Dynalight",
  "Eagle Lake",
  "East Sea Dokdo",
  "Eater",
  "Economica",
  "Eczar",
  "Edu NSW ACT Foundation",
  "El Messiri",
  "Electrolize",
  "Elsie",
  "Elsie Swash Caps",
  "Emblema One",
  "Emilys Candy",
  "Encode Sans",
  "Engagement",
  "Englebert",
  "Enriqueta",
  "Ephesis",
  "Epilogue",
  "Erica One",
  "Esteban",
  "Euphoria Script",
  "Ewert",
  "Exile",
  "Expletus Sans",
  "Fanwood Text",
  "Farro",
  "Farsan",
  "Fascinate",
  "Fascinate Inline",
  "Faster One",
  "Fasthand",
  "Fauna One",
  "Faustina",
  "Federant",
  "Federo",
  "Felipa",
  "Fenix",
  "Festive",
  "Finger Paint",
  "Fjord One",
  "Flamenco",
  "Flavors",
  "Fleur De Leah",
  "Flow Circular",
  "Flow Rounded",
  "Fondamento",
  "Fontdiner Swanky",
  "Forum",
  "Francois One",
  "Fredericka the Great",
  "Freehand",
  "Fresca",
  "Frijole",
  "Fruktur",
  "Fuggles",
  "Fugaz One",
  "Fuzzy Bubbles",
  "Gabarito",
  "Gabriela",
  "Gaegu",
  "Gafata",
  "Galada",
  "Galdeano",
  "Galindo",
  "Gamja Flower",
  "Gantari",
  "Gasoek One",
  "Gayathri",
  "Geo",
  "Georama",
  "Geostar",
  "Geostar Fill",
  "Germania One",
  "Gideon Roman",
  "Gidugu",
  "Gilda Display",
  "Girassol",
  "Give You Glory",
  "Glass Antiqua",
  "Glegoo",
  "Gloria Hallelujah",
  "Glory",
  "Gluten",
  "Goblin One",
  "Gochi Hand"
];

// Fonty GOOGLE FONTS (setki dodatkowych stylów, ladowane online przy pierwszym uzyciu zakladki Tekst)
let googleFontsLoaded = false;
function ensureGoogleFontsLoaded(){
  if(googleFontsLoaded) return;
  googleFontsLoaded = true;
  const chunkSize = 50;
  for(let i=0;i<FONTS_GOOGLE.length;i+=chunkSize){
    const chunk = FONTS_GOOGLE.slice(i, i+chunkSize);
    const fams = chunk.map(f=>'family='+encodeURIComponent(f).replace(/%20/g,'+')+':wght@400;700').join('&');
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://fonts.googleapis.com/css2?'+fams+'&display=swap';
    link.onload = ()=>{ if(currentTab==='text') renderTextPanel(); };
    link.onerror = ()=>{};
    document.head.appendChild(link);
  }
}


const FONTS_TOTAL_COUNT = FONTS_EMBEDDED.length + FONTS_GOOGLE.length + FONTS_SYSTEM.length;
// Kilka najmocniejszych, "gamingowo-miniaturkowych" krojów (grube, czytelne z daleka) - zawsze na
// samej górze listy, żeby nie trzeba było przeszukiwać setek pozycji za każdym razem.
const FONTS_RECOMMENDED = ['Anton','Bebas Neue','Archivo Black','Poppins Black','Bungee','Righteous','Titan One','Alfa Slab One','Fjalla One','Russo One','Staatliches','Bangers'];

function fontPickerListHtml(sel, filter){
  const f = (filter||'').toLowerCase().trim();
  const groups = [
    {label:'⭐ Polecane do miniaturek', list:FONTS_RECOMMENDED, tag:'top'},
    {label:'🔥 Wbudowane — działają zawsze offline', list:FONTS_EMBEDDED, tag:'wbudowana'},
    {label:'🌐 Google Fonts — setki stylów (wymaga internetu)', list:FONTS_GOOGLE, tag:'online'},
    {label:'💻 Systemowe (Windows / Office)', list:FONTS_SYSTEM, tag:'systemowa'}
  ];
  const sample = (sel.text||'').trim() ? sel.text.trim().split('\n')[0].slice(0,22) : 'AaBb 123';
  let html = '';
  groups.forEach(g=>{
    const filtered = f ? g.list.filter(name=> name.toLowerCase().includes(f)) : g.list;
    if(!filtered.length) return;
    html += `<div class="font-picker-group">${g.label} (${filtered.length})</div>`;
    filtered.forEach(name=>{
      const css = fontFamilyCss(name);
      const active = sel.fontFamily===css;
      html += `<div class="font-picker-item ${active?'active':''}" data-font="${escapeHtml(css)}" style="font-family:${escapeHtml(css)};">
        <span class="fp-sample">${escapeHtml(sample)}</span><span class="fp-tag">${escapeHtml(name)}</span>
      </div>`;
    });
  });
  if(!html) html = `<p class="hint" style="padding:10px;">Brak czcionek pasujących do "${escapeHtml(filter)}".</p>`;
  return html;
}

function bindFontPicker(sel){
  ensureGoogleFontsLoaded();
  const list = document.getElementById('fontPickerList');
  const search = document.getElementById('fontSearch');
  const refresh = ()=>{ list.innerHTML = fontPickerListHtml(sel, search.value); };
  search.oninput = refresh;
  list.addEventListener('click', (e)=>{
    const item = e.target.closest('.font-picker-item');
    if(!item) return;
    sel.fontFamily = item.dataset.font;
    render(); renderTextPanel(); pushHistory();
  });
}

function renderTextPanel(){
  const sel = getSelectedLayer();
  let html = `<h3>Tekst</h3><button id="addTextBtn" class="chip active" style="width:100%; padding:10px; margin-bottom:10px;">+ Dodaj tekst</button>`;
  html += `<p class="hint" style="margin-top:0;">🔤 Masz dostępnych <b style="color:var(--accent);">${FONTS_TOTAL_COUNT} czcionek</b> — wpisz frazę w wyszukiwarkę niżej, a każda pozycja od razu pokazuje jak wygląda na tekście.</p>`;
  if(sel && sel.type==='text'){
    html += `
      <div class="field"><label>Treść</label><textarea id="txtContent">${escapeHtml(sel.text)}</textarea></div>
      <div class="field">
        <label>Czcionka <span style="color:var(--accent);">(${FONTS_TOTAL_COUNT} dostępnych)</span></label>
        <input type="text" id="fontSearch" placeholder="🔍 Szukaj czcionki (np. bebas, comic, script...)">
        <div id="fontPickerList" class="font-picker-list">${fontPickerListHtml(sel,'')}</div>
      </div>
      <div class="field"><label>Wypełnienie tekstu</label><div class="chip-row">
        <button class="chip ${!sel.gradient?'active':''}" id="txtFillSolid">Jednolity kolor</button>
        <button class="chip ${sel.gradient?'active':''}" id="txtFillGradient">Gradient</button>
      </div></div>
      ${sel.gradient ? `
      <div class="field"><label>Typ gradientu</label><div class="chip-row">
        <button class="chip ${sel.gradient.type!=='radial'?'active':''}" id="txtGradLinear">Liniowy</button>
        <button class="chip ${sel.gradient.type==='radial'?'active':''}" id="txtGradRadial">Radialny (okrąg)</button>
      </div></div>
      ${sel.gradient.type==='radial' ? `
      <div class="row">
        <div class="field"><label>Środek X <span>${sel.gradient.cx!==undefined?sel.gradient.cx:50}%</span></label><input type="range" id="txtGradCx" min="0" max="100" value="${sel.gradient.cx!==undefined?sel.gradient.cx:50}"></div>
        <div class="field"><label>Środek Y <span>${sel.gradient.cy!==undefined?sel.gradient.cy:50}%</span></label><input type="range" id="txtGradCy" min="0" max="100" value="${sel.gradient.cy!==undefined?sel.gradient.cy:50}"></div>
      </div>
      <div class="field"><label>Promień <span>${sel.gradient.r!==undefined?sel.gradient.r:70}%</span></label><input type="range" id="txtGradR" min="10" max="150" value="${sel.gradient.r!==undefined?sel.gradient.r:70}"></div>
      ` : `
      <div class="field"><label>Kąt gradientu <span>${sel.gradient.angle}°</span></label><input type="range" id="txtGradAngle" min="0" max="360" value="${sel.gradient.angle}"></div>
      `}
      <div id="txtGradStops"></div>
      ` : ''}
      <div class="field"><label>Rozmiar <span>${sel.fontSize}px</span></label><input type="range" id="txtSize" min="10" max="220" value="${sel.fontSize}"></div>
      ${!sel.gradient ? `<div class="field"><label>Kolor</label><input type="color" id="txtColor" value="${sel.color}"></div>` : ''}
      <div class="field"><label>Styl</label><div class="chip-row">
        <button class="chip ${sel.bold?'active':''}" id="txtBold">Pogrubienie</button>
        <button class="chip ${sel.italic?'active':''}" id="txtItalic">Kursywa</button>
      </div></div>
      <div class="field"><label>Wyrównanie</label><div class="chip-row">
        <button class="chip ${sel.align==='left'?'active':''}" data-a="left">Lewo</button>
        <button class="chip ${sel.align==='center'?'active':''}" data-a="center">Środek</button>
        <button class="chip ${sel.align==='right'?'active':''}" data-a="right">Prawo</button>
      </div></div>
      <div class="row">
        <div class="field">
          <label>Obrys</label>
          <div class="chip-row" style="margin-bottom:6px;">
            <button class="chip ${!sel.strokeGradient?'active':''}" id="txtStrokeSolid">Jednolity</button>
            <button class="chip ${sel.strokeGradient?'active':''}" id="txtStrokeGrad">Gradient</button>
          </div>
          ${!sel.strokeGradient ? `<input type="color" id="txtStroke" value="${sel.strokeColor}">` : ''}
        </div>
        <div class="field"><label>Grubość obrysu <span>${sel.strokeWidth}</span></label><input type="range" id="txtStrokeW" min="0" max="20" value="${sel.strokeWidth}"></div>
      </div>
      ${sel.strokeGradient ? `
      <div class="field"><label>Kąt gradientu obrysu <span>${sel.strokeGradient.angle}°</span></label><input type="range" id="txtStrokeGradAngle" min="0" max="360" value="${sel.strokeGradient.angle}"></div>
      <div id="txtStrokeGradStops"></div>
      ` : ''}
      <div class="field"><label>Cień <input type="checkbox" id="txtShadowOn" ${sel.shadowEnabled?'checked':''}></label></div>
      ${sel.shadowEnabled ? `
      <div class="field"><label>Wypełnienie cienia</label><div class="chip-row">
        <button class="chip ${!sel.shadowGradient?'active':''}" id="txtShadowSolid">Jednolity</button>
        <button class="chip ${sel.shadowGradient?'active':''}" id="txtShadowGrad">Gradient</button>
      </div></div>
      <div class="row">
        ${!sel.shadowGradient ? `<div class="field"><label>Kolor cienia</label><input type="color" id="txtShadowColor" value="${sel.shadowColor}"></div>` : ''}
        <div class="field"><label>Rozmycie <span>${sel.shadowBlur}</span></label><input type="range" id="txtShadowBlur" min="0" max="40" value="${sel.shadowBlur}"></div>
      </div>
      ${sel.shadowGradient ? `
      <div class="field"><label>Kąt gradientu cienia <span>${sel.shadowGradient.angle}°</span></label><input type="range" id="txtShadowGradAngle" min="0" max="360" value="${sel.shadowGradient.angle}"></div>
      <div id="txtShadowGradStops"></div>
      ` : ''}` : ''}
      <div class="field"><label>Rotacja <span>${sel.rotation||0}°</span></label><input type="range" id="txtRot" min="-180" max="180" value="${sel.rotation||0}"></div>
      <div class="field"><label>Przezroczystość <span>${sel.opacity}%</span></label><input type="range" id="txtOpacity" min="0" max="100" value="${sel.opacity}"></div>
      ${adjControlsHtml(sel)}
    `;
  } else {
    html += `<p class="hint">Kliknij "+ Dodaj tekst" albo wybierz istniejącą warstwę tekstową z listy po prawej, żeby ją edytować.</p>`;
  }
  toolpanel.innerHTML = html;
  document.getElementById('addTextBtn').onclick = ()=>{
    addLayer({ type:'text', text:'Twój tekst', x:canvasW/2, y:canvasH/2, w:200,h:60, rotation:0, opacity:100, brightness:100,
      fontFamily:'Anton', fontSize:64, color:'#ffffff', gradient:null, bold:true, italic:false, align:'center',
      strokeColor:'#000000', strokeWidth:0, shadowEnabled:false, shadowColor:'#000000', shadowBlur:10, shadowOffsetX:2, shadowOffsetY:2 });
    currentTab='text'; renderTextPanel();
  };
  if(sel && sel.type==='text'){
    const upd = (fn)=>{ fn(); render(); };
    document.getElementById('txtContent').oninput = e=>upd(()=>sel.text=e.target.value);
    document.getElementById('txtContent').onblur = ()=>pushHistory();
    bindFontPicker(sel);
    document.getElementById('txtSize').oninput = e=>upd(()=>sel.fontSize=+e.target.value);
    document.getElementById('txtSize').onchange = ()=>pushHistory();
    document.getElementById('txtFillSolid').onclick = ()=>{ sel.gradient=null; render(); renderTextPanel(); pushHistory(); };
    document.getElementById('txtFillGradient').onclick = ()=>{
      if(!sel.gradient) sel.gradient = { type:'linear', angle:90, cx:50, cy:50, r:70, stops:[{c: sel.color||'#7c5cff',p:0},{c:'#00d1a0',p:1}] };
      render(); renderTextPanel(); pushHistory();
    };
    const tc = document.getElementById('txtColor');
    if(tc){ tc.oninput = e=>upd(()=>sel.color=e.target.value); tc.onchange = ()=>pushHistory(); }
    const glin = document.getElementById('txtGradLinear'), grad2 = document.getElementById('txtGradRadial');
    if(glin) glin.onclick = ()=>{ sel.gradient.type='linear'; render(); renderTextPanel(); pushHistory(); };
    if(grad2) grad2.onclick = ()=>{ sel.gradient.type='radial'; render(); renderTextPanel(); pushHistory(); };
    const ga = document.getElementById('txtGradAngle');
    if(ga){ ga.oninput=e=>upd(()=>sel.gradient.angle=+e.target.value); ga.onchange=()=>pushHistory(); }
    const gcx = document.getElementById('txtGradCx'), gcy = document.getElementById('txtGradCy'), gr2 = document.getElementById('txtGradR');
    if(gcx){ gcx.oninput=e=>upd(()=>sel.gradient.cx=+e.target.value); gcx.onchange=()=>pushHistory(); }
    if(gcy){ gcy.oninput=e=>upd(()=>sel.gradient.cy=+e.target.value); gcy.onchange=()=>pushHistory(); }
    if(gr2){ gr2.oninput=e=>upd(()=>sel.gradient.r=+e.target.value); gr2.onchange=()=>pushHistory(); }
    const gradStopsBox = document.getElementById('txtGradStops');
    if(gradStopsBox){
      gradStopsBox.appendChild(stopsEditor(sel.gradient.stops, ()=>render(), ()=>renderTextPanel()));
    }
    document.getElementById('txtBold').onclick = ()=>{ sel.bold=!sel.bold; render(); renderTextPanel(); pushHistory(); };
    document.getElementById('txtItalic').onclick = ()=>{ sel.italic=!sel.italic; render(); renderTextPanel(); pushHistory(); };
    toolpanel.querySelectorAll('[data-a]').forEach(b=> b.onclick = ()=>{ sel.align=b.dataset.a; render(); renderTextPanel(); pushHistory(); });
    const txtStroke = document.getElementById('txtStroke');
    if(txtStroke){ txtStroke.oninput = e=>upd(()=>sel.strokeColor=e.target.value); txtStroke.onchange = ()=>pushHistory(); }
    document.getElementById('txtStrokeW').oninput = e=>upd(()=>sel.strokeWidth=+e.target.value);
    document.getElementById('txtStrokeW').onchange = ()=>pushHistory();
    document.getElementById('txtStrokeSolid').onclick = ()=>{ sel.strokeGradient=null; render(); renderTextPanel(); pushHistory(); };
    document.getElementById('txtStrokeGrad').onclick = ()=>{
      if(!sel.strokeGradient) sel.strokeGradient = { angle:90, stops:[{c: sel.strokeColor||'#000000',p:0},{c:'#7c5cff',p:1}] };
      render(); renderTextPanel(); pushHistory();
    };
    const tsgAngle = document.getElementById('txtStrokeGradAngle');
    if(tsgAngle){ tsgAngle.oninput=e=>upd(()=>sel.strokeGradient.angle=+e.target.value); tsgAngle.onchange=()=>pushHistory(); }
    const tsgStops = document.getElementById('txtStrokeGradStops');
    if(tsgStops && sel.strokeGradient) tsgStops.appendChild(stopsEditor(sel.strokeGradient.stops, ()=>render(), ()=>renderTextPanel()));
    document.getElementById('txtShadowOn').onchange = e=>{ sel.shadowEnabled=e.target.checked; render(); renderTextPanel(); pushHistory(); };
    const sc = document.getElementById('txtShadowColor'), sb = document.getElementById('txtShadowBlur');
    if(sc){ sc.oninput=e=>upd(()=>sel.shadowColor=e.target.value); sc.onchange=()=>pushHistory(); }
    if(sb){ sb.oninput=e=>upd(()=>sel.shadowBlur=+e.target.value); sb.onchange=()=>pushHistory(); }
    const shSolidBtn = document.getElementById('txtShadowSolid'), shGradBtn = document.getElementById('txtShadowGrad');
    if(shSolidBtn) shSolidBtn.onclick = ()=>{ sel.shadowGradient=null; render(); renderTextPanel(); pushHistory(); };
    if(shGradBtn) shGradBtn.onclick = ()=>{
      if(!sel.shadowGradient) sel.shadowGradient = { angle:90, stops:[{c: sel.shadowColor||'#000000',p:0},{c:'#7c5cff',p:1}] };
      render(); renderTextPanel(); pushHistory();
    };
    const shgAngle = document.getElementById('txtShadowGradAngle');
    if(shgAngle){ shgAngle.oninput=e=>upd(()=>sel.shadowGradient.angle=+e.target.value); shgAngle.onchange=()=>pushHistory(); }
    const shgStops = document.getElementById('txtShadowGradStops');
    if(shgStops && sel.shadowGradient) shgStops.appendChild(stopsEditor(sel.shadowGradient.stops, ()=>render(), ()=>renderTextPanel()));
    document.getElementById('txtRot').oninput = e=>upd(()=>sel.rotation=+e.target.value);
    document.getElementById('txtRot').onchange = ()=>pushHistory();
    document.getElementById('txtOpacity').oninput = e=>upd(()=>sel.opacity=+e.target.value);
    document.getElementById('txtOpacity').onchange = ()=>pushHistory();
    bindAdjControls(sel);
  }
}

// ---------- PANEL: OBRAZ ----------
function applyDispersion(sel){
  if(!sel || sel.type!=='image' || !sel.canvas) return;
  const cnv = sel.canvas;
  const w = cnv.width, h = cnv.height;
  const amt = dispersionSettings.amount/100;
  const rad = dispersionSettings.angle*Math.PI/180;
  const dirX = Math.cos(rad), dirY = Math.sin(rad);
  const src = cloneCanvas(cnv);
  const octx = cnv.getContext('2d');
  octx.clearRect(0,0,w,h);
  const strips = 60;
  const stripH = Math.max(1, Math.ceil(h/strips));
  for(let i=0;i<strips;i++){
    const sy = i*stripH;
    const sh = Math.min(stripH, h-sy);
    if(sh<=0) continue;
    // im blizej krawedzi (gornej/dolnej) i losowo, tym wieksze przesuniecie - daje "rozpadajacy sie" wyglad
    const edgeFactor = Math.abs((sy+sh/2) - h/2) / (h/2); // 0 w centrum, 1 na krawedziach
    const rnd = (Math.sin(i*12.9898)*43758.5453) % 1;
    const strength = amt * (0.25 + 0.75*edgeFactor) * (0.4+Math.abs(rnd)*1.2) * w*0.35;
    const offX = dirX*strength;
    const offY = dirY*strength*0.3;
    const alpha = Math.max(0.15, 1 - edgeFactor*amt*0.9);
    octx.save();
    octx.globalAlpha = alpha;
    octx.drawImage(src, 0, sy, w, sh, offX, sy+offY, w, sh);
    // dodatkowe drobne "odpryski" - male kawalki dalej wysuniete
    if(amt>0.15 && Math.abs(rnd)>0.6){
      octx.globalAlpha = alpha*0.5;
      octx.drawImage(src, 0, sy, w, sh, offX*1.8, sy+offY*1.8, w, sh);
    }
    octx.restore();
  }
  render(); pushHistory();
}

function renderImagePanelDispersionBind(sel){
  const upd = fn=>{ fn(); };
  const da = document.getElementById('dispAmount'), dg = document.getElementById('dispAngle'), db = document.getElementById('dispApply');
  if(da) da.oninput = e=>{ dispersionSettings.amount=+e.target.value; document.getElementById('dispAmtLbl').textContent=dispersionSettings.amount+'%'; };
  if(dg) dg.oninput = e=>{ dispersionSettings.angle=+e.target.value; document.getElementById('dispAngLbl').textContent=dispersionSettings.angle+'°'; };
  if(db) db.onclick = ()=> applyDispersion(sel);
}

function renderImagePanel(){
  const sel = getSelectedLayer();
  let html = `<h3>Obraz</h3><div class="upload-btn" id="uploadTrigger">📤 Kliknij, żeby wgrać zdjęcie</div>`;
  if(sel && sel.type==='image'){
    const f = sel.filters, s = sel.shadow, o = sel.outline || {enabled:false,color:'#ffffff',width:14,glow:0};
    html += `
      <h3 style="margin-top:16px;">Ustawienia obrazka</h3>
      <div class="field"><label>Zaokrąglenie rogów <span>${sel.radius}</span></label><input type="range" id="imgRadius" min="0" max="300" value="${sel.radius}"></div>
      <div class="field"><label>Rotacja <span>${sel.rotation||0}°</span></label><input type="range" id="imgRot" min="-180" max="180" value="${sel.rotation||0}"></div>
      <div class="field"><label>Przezroczystość <span>${sel.opacity}%</span></label><input type="range" id="imgOpacity" min="0" max="100" value="${sel.opacity}"></div>
      <div class="row">
        <button class="chip" id="imgFlipH">↔️ Odbij poziomo</button>
        <button class="chip" id="imgFlipV">↕️ Odbij pionowo</button>
      </div>
      <h3 style="margin-top:16px;">Filtry (jak w Instagramie)</h3>
      <div class="field"><label>Jasność <span>${f.brightness}%</span></label><input type="range" id="fBrightness" min="0" max="200" value="${f.brightness}"></div>
      <div class="field"><label>Kontrast <span>${f.contrast}%</span></label><input type="range" id="fContrast" min="0" max="200" value="${f.contrast}"></div>
      <div class="field"><label>Nasycenie <span>${f.saturate}%</span></label><input type="range" id="fSaturate" min="0" max="200" value="${f.saturate}"></div>
      <div class="field"><label>Rozmycie <span>${f.blur}px</span></label><input type="range" id="fBlur" min="0" max="20" value="${f.blur}"></div>
      <div class="field"><label>Czarno-białe <span>${f.grayscale}%</span></label><input type="range" id="fGray" min="0" max="100" value="${f.grayscale}"></div>
      <div class="field"><label>Sepia <span>${f.sepia}%</span></label><input type="range" id="fSepia" min="0" max="100" value="${f.sepia}"></div>
      <div class="chip-row" style="margin-bottom:10px;">
        <button class="chip" data-preset="none">Reset</button>
        <button class="chip" data-preset="vivid">Żywe kolory</button>
        <button class="chip" data-preset="bw">Czarno-białe</button>
        <button class="chip" data-preset="warm">Ciepłe</button>
        <button class="chip" data-preset="cool">Chłodne</button>
      </div>
      <h3>Cień obrazka</h3>
      <div class="field"><label>Włącz cień <input type="checkbox" id="imgShadowOn" ${s.enabled?'checked':''}></label></div>
      ${s.enabled ? `
      <div class="field"><label>Wypełnienie cienia</label><div class="chip-row">
        <button class="chip ${!s.gradient?'active':''}" id="imgShadowSolid">Jednolity</button>
        <button class="chip ${s.gradient?'active':''}" id="imgShadowGrad">Gradient</button>
      </div></div>
      ${!s.gradient ? `<div class="field"><label>Kolor cienia</label><input type="color" id="imgShadowColor" value="${s.color}"></div>` : ''}
      <div class="field"><label>Rozmycie <span>${s.blur}</span></label><input type="range" id="imgShadowBlur" min="0" max="60" value="${s.blur}"></div>
      ${s.gradient ? `
      <div class="field"><label>Kąt gradientu cienia <span>${s.gradient.angle}°</span></label><input type="range" id="imgShadowGradAngle" min="0" max="360" value="${s.gradient.angle}"></div>
      <div id="imgShadowGradStops"></div>
      ` : ''}
      ` : ''}
      <h3 style="margin-top:16px;">Obrys / poświata wycięcia 🔥</h3>
      <p class="hint">Popularny efekt "naklejki" z miniaturek gamingowych — gruba kolorowa obwódka dookoła wyciętej postaci/zdjęcia (działa najlepiej na PNG z przezroczystością).</p>
      <div class="field"><label>Włącz obrys <input type="checkbox" id="imgOutlineOn" ${o.enabled?'checked':''}></label></div>
      ${o.enabled ? `
      <div class="field"><label>Wypełnienie obrysu</label><div class="chip-row">
        <button class="chip ${!o.gradient?'active':''}" id="imgOutlineSolid">Jednolity</button>
        <button class="chip ${o.gradient?'active':''}" id="imgOutlineGrad">Gradient</button>
      </div></div>
      ${!o.gradient ? `<div class="field"><label>Kolor obrysu</label><input type="color" id="imgOutlineColor" value="${o.color}"></div>` : ''}
      ${o.gradient ? `
      <div class="field"><label>Kąt gradientu obrysu <span>${o.gradient.angle}°</span></label><input type="range" id="imgOutlineGradAngle" min="0" max="360" value="${o.gradient.angle}"></div>
      <div id="imgOutlineGradStops"></div>
      ` : ''}
      <div class="field"><label>Grubość <span>${o.width}px</span></label><input type="range" id="imgOutlineWidth" min="2" max="60" value="${o.width}"></div>
      <div class="field"><label>Poświata (glow) <span>${o.glow}px</span></label><input type="range" id="imgOutlineGlow" min="0" max="40" value="${o.glow}"></div>
      ${!o.gradient ? `
      <div class="chip-row" style="margin-bottom:10px;">
        <button class="chip" data-outline-preset="white">Białe</button>
        <button class="chip" data-outline-preset="black">Czarne</button>
        <button class="chip" data-outline-preset="yellow">Neon żółty</button>
        <button class="chip" data-outline-preset="red">Czerwony gaming</button>
      </div>
      ` : ''}
      ` : ''}
      <h3 style="margin-top:16px;">Rozproszenie (efekt "eksplozji")</h3>
      <div class="field"><label>Ilość <span id="dispAmtLbl">${dispersionSettings.amount}%</span></label><input type="range" id="dispAmount" min="0" max="100" value="${dispersionSettings.amount}"></div>
      <div class="field"><label>Kierunek <span id="dispAngLbl">${dispersionSettings.angle}°</span></label><input type="range" id="dispAngle" min="0" max="360" value="${dispersionSettings.angle}"></div>
      <button id="dispApply" class="chip active" style="width:100%;">💥 Zastosuj rozproszenie</button>
      <p class="hint">Efekt wypala się bezpośrednio na obrazku (jak filtr w Photoshopie) — zawsze możesz cofnąć przez Ctrl+Z.</p>
    `;
  } else {
    html += `<p class="hint">Wgraj zdjęcie, żeby dodać je jako warstwę. Potem możesz je przesuwać, skalować (uchwyt w rogu), obracać i nakładać filtry.</p>`;
  }
  toolpanel.innerHTML = html;
  document.getElementById('uploadTrigger').onclick = ()=> fileInput.click();

  if(sel && sel.type==='image'){
    const upd = fn=>{ fn(); render(); };
    document.getElementById('imgRadius').oninput = e=>upd(()=>sel.radius=+e.target.value);
    document.getElementById('imgRadius').onchange = ()=>pushHistory();
    document.getElementById('imgRot').oninput = e=>upd(()=>sel.rotation=+e.target.value);
    document.getElementById('imgRot').onchange = ()=>pushHistory();
    document.getElementById('imgOpacity').oninput = e=>upd(()=>sel.opacity=+e.target.value);
    document.getElementById('imgOpacity').onchange = ()=>pushHistory();
    document.getElementById('imgFlipH').onclick = ()=>{ sel.flipH=!sel.flipH; render(); pushHistory(); };
    document.getElementById('imgFlipV').onclick = ()=>{ sel.flipV=!sel.flipV; render(); pushHistory(); };
    const f = sel.filters;
    const bind = (id,key,parse)=>{ const el=document.getElementById(id); el.oninput=e=>upd(()=>f[key]=parse(e.target.value)); el.onchange=()=>pushHistory(); };
    bind('fBrightness','brightness',Number); bind('fContrast','contrast',Number); bind('fSaturate','saturate',Number);
    bind('fBlur','blur',Number); bind('fGray','grayscale',Number); bind('fSepia','sepia',Number);
    toolpanel.querySelectorAll('[data-preset]').forEach(b=>{
      b.onclick = ()=>{
        const presets = {
          none:{brightness:100,contrast:100,saturate:100,blur:0,grayscale:0,sepia:0},
          vivid:{brightness:105,contrast:115,saturate:150,blur:0,grayscale:0,sepia:0},
          bw:{brightness:100,contrast:110,saturate:0,blur:0,grayscale:100,sepia:0},
          warm:{brightness:105,contrast:100,saturate:110,blur:0,grayscale:0,sepia:30},
          cool:{brightness:100,contrast:105,saturate:120,blur:0,grayscale:0,sepia:0}
        };
        Object.assign(sel.filters, presets[b.dataset.preset]);
        render(); renderImagePanel(); pushHistory();
      };
    });
    document.getElementById('imgShadowOn').onchange = e=>{ sel.shadow.enabled=e.target.checked; render(); renderImagePanel(); pushHistory(); };
    const sc = document.getElementById('imgShadowColor'), sb = document.getElementById('imgShadowBlur');
    if(sc){ sc.oninput=e=>upd(()=>sel.shadow.color=e.target.value); sc.onchange=()=>pushHistory(); }
    if(sb){ sb.oninput=e=>upd(()=>sel.shadow.blur=+e.target.value); sb.onchange=()=>pushHistory(); }
    const imgShSolid = document.getElementById('imgShadowSolid'), imgShGrad = document.getElementById('imgShadowGrad');
    if(imgShSolid) imgShSolid.onclick = ()=>{ sel.shadow.gradient=null; render(); renderImagePanel(); pushHistory(); };
    if(imgShGrad) imgShGrad.onclick = ()=>{
      if(!sel.shadow.gradient) sel.shadow.gradient = { angle:90, stops:[{c: sel.shadow.color||'#000000',p:0},{c:'#7c5cff',p:1}] };
      render(); renderImagePanel(); pushHistory();
    };
    const imgShGradAngle = document.getElementById('imgShadowGradAngle');
    if(imgShGradAngle){ imgShGradAngle.oninput=e=>upd(()=>sel.shadow.gradient.angle=+e.target.value); imgShGradAngle.onchange=()=>pushHistory(); }
    const imgShGradStops = document.getElementById('imgShadowGradStops');
    if(imgShGradStops && sel.shadow.gradient) imgShGradStops.appendChild(stopsEditor(sel.shadow.gradient.stops, ()=>render(), ()=>renderImagePanel()));
    if(!sel.outline) sel.outline = {enabled:false,color:'#ffffff',width:14,glow:0};
    document.getElementById('imgOutlineOn').onchange = e=>{ sel.outline.enabled=e.target.checked; render(); renderImagePanel(); pushHistory(); };
    const oc = document.getElementById('imgOutlineColor'), ow = document.getElementById('imgOutlineWidth'), og = document.getElementById('imgOutlineGlow');
    if(oc){ oc.oninput=e=>upd(()=>sel.outline.color=e.target.value); oc.onchange=()=>pushHistory(); }
    if(ow){ ow.oninput=e=>upd(()=>sel.outline.width=+e.target.value); ow.onchange=()=>pushHistory(); }
    if(og){ og.oninput=e=>upd(()=>sel.outline.glow=+e.target.value); og.onchange=()=>pushHistory(); }
    const imgOutSolid = document.getElementById('imgOutlineSolid'), imgOutGrad = document.getElementById('imgOutlineGrad');
    if(imgOutSolid) imgOutSolid.onclick = ()=>{ sel.outline.gradient=null; render(); renderImagePanel(); pushHistory(); };
    if(imgOutGrad) imgOutGrad.onclick = ()=>{
      if(!sel.outline.gradient) sel.outline.gradient = { angle:90, stops:[{c: sel.outline.color||'#ffffff',p:0},{c:'#7c5cff',p:1}] };
      render(); renderImagePanel(); pushHistory();
    };
    const imgOutGradAngle = document.getElementById('imgOutlineGradAngle');
    if(imgOutGradAngle){ imgOutGradAngle.oninput=e=>upd(()=>sel.outline.gradient.angle=+e.target.value); imgOutGradAngle.onchange=()=>pushHistory(); }
    const imgOutGradStops = document.getElementById('imgOutlineGradStops');
    if(imgOutGradStops && sel.outline.gradient) imgOutGradStops.appendChild(stopsEditor(sel.outline.gradient.stops, ()=>render(), ()=>renderImagePanel()));
    toolpanel.querySelectorAll('[data-outline-preset]').forEach(b=>{
      b.onclick = ()=>{
        const presets = { white:'#ffffff', black:'#000000', yellow:'#ffe600', red:'#ff1f3d' };
        sel.outline.color = presets[b.dataset.outlinePreset];
        render(); renderImagePanel(); pushHistory();
      };
    });
    renderImagePanelDispersionBind(sel);
  }
}

fileInput.addEventListener('change', (e)=>{
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = (ev)=>{
    const img = new Image();
    img.onload = ()=>{
      const maxDim = Math.min(canvasW,canvasH)*0.6;
      const ratio = Math.min(maxDim/img.width, maxDim/img.height, 1);
      const editCanvas = makeEditableCanvas(img);
      addLayer({ type:'image', canvas: editCanvas, x:canvasW/2, y:canvasH/2, w:img.width*ratio, h:img.height*ratio,
        rotation:0, opacity:100, radius:0, flipH:false, flipV:false,
        filters:{brightness:100,contrast:100,saturate:100,blur:0,grayscale:0,sepia:0},
        shadow:{enabled:false,color:'#000000',blur:20,offsetX:0,offsetY:8}, outline:{enabled:false,color:'#ffffff',width:14,glow:0} });
      currentTab='image'; renderImagePanel();
    };
    img.src = ev.target.result;
  };
  reader.readAsDataURL(file);
  fileInput.value = '';
});

// ---------- PANEL: KSZTAŁTY ----------
const SHAPES = [
  {k:'rect', ic:'▭', label:'Prostokąt'},
  {k:'circle', ic:'⬤', label:'Koło'},
  {k:'triangle', ic:'▲', label:'Trójkąt'},
  {k:'star', ic:'★', label:'Gwiazda'},
  {k:'arrow', ic:'➤', label:'Strzałka'},
  {k:'line', ic:'―', label:'Linia'}
];
function renderShapePanel(){
  const sel = getSelectedLayer();
  let html = `<h3>Dodaj kształt</h3><div class="grid-buttons" id="shapeGrid">
    ${SHAPES.map(s=>`<button data-k="${s.k}" title="${s.label}">${s.ic}</button>`).join('')}
  </div>`;
  if(sel && sel.type==='shape'){
    html += `
      <h3 style="margin-top:18px;">Ustawienia kształtu</h3>
      <div class="field"><label>Wypełnienie</label><input type="color" id="shFill" value="${sel.fill==='none'?'#ffffff':sel.fill}"></div>
      <div class="row">
        <div class="field"><label>Obrys</label><input type="color" id="shStroke" value="${sel.stroke}"></div>
        <div class="field"><label>Grubość <span>${sel.strokeWidth}</span></label><input type="range" id="shStrokeW" min="0" max="30" value="${sel.strokeWidth}"></div>
      </div>
      ${sel.shape==='rect' ? `<div class="field"><label>Zaokrąglenie <span>${sel.cornerRadius}</span></label><input type="range" id="shCorner" min="0" max="200" value="${sel.cornerRadius}"></div>` : ''}
      <div class="field"><label>Rotacja <span>${sel.rotation||0}°</span></label><input type="range" id="shRot" min="-180" max="180" value="${sel.rotation||0}"></div>
      <div class="field"><label>Przezroczystość <span>${sel.opacity}%</span></label><input type="range" id="shOpacity" min="0" max="100" value="${sel.opacity}"></div>
      ${adjControlsHtml(sel)}
    `;
  } else {
    html += `<p class="hint">Kliknij kształt, żeby dodać go na środku miniaturki. Potem przeciągnij, żeby przesunąć, albo złap za uchwyt w rogu / górze, żeby zmienić rozmiar / obrócić.</p>`;
  }
  toolpanel.innerHTML = html;
  document.getElementById('shapeGrid').querySelectorAll('button').forEach(b=>{
    b.onclick = ()=>{
      addLayer({ type:'shape', shape:b.dataset.k, x:canvasW/2, y:canvasH/2, w:220, h:b.dataset.k==='line'?4:220,
        rotation:0, opacity:100, fill:'#7c5cff', stroke:'#ffffff', strokeWidth: b.dataset.k==='line'?6:0, cornerRadius:24 });
      renderShapePanel();
    };
  });
  if(sel && sel.type==='shape'){
    const upd = fn=>{ fn(); render(); };
    document.getElementById('shFill').oninput = e=>upd(()=>sel.fill=e.target.value);
    document.getElementById('shFill').onchange = ()=>pushHistory();
    document.getElementById('shStroke').oninput = e=>upd(()=>sel.stroke=e.target.value);
    document.getElementById('shStroke').onchange = ()=>pushHistory();
    document.getElementById('shStrokeW').oninput = e=>upd(()=>sel.strokeWidth=+e.target.value);
    document.getElementById('shStrokeW').onchange = ()=>pushHistory();
    const corner = document.getElementById('shCorner');
    if(corner){ corner.oninput=e=>upd(()=>sel.cornerRadius=+e.target.value); corner.onchange=()=>pushHistory(); }
    document.getElementById('shRot').oninput = e=>upd(()=>sel.rotation=+e.target.value);
    document.getElementById('shRot').onchange = ()=>pushHistory();
    document.getElementById('shOpacity').oninput = e=>upd(()=>sel.opacity=+e.target.value);
    document.getElementById('shOpacity').onchange = ()=>pushHistory();
    bindAdjControls(sel);
  }
}

// ---------- PANEL: EMOJI ----------
const EMOJI_SET = ['🔥','⭐','💯','🚀','🎉','😱','😂','😍','👀','👍','👑','💰','⚡','❤️','✅','❌','⚠️','🆕','🎮','🏆','💡','📈','🎯','🔔','🎁','🥳','😎','🤯','💥','👇'];
function renderEmojiPanel(){
  const sel = getSelectedLayer();
  let html = `<h3>Dodaj emoji / naklejkę</h3>
    <div class="grid-buttons" id="emojiGrid">${EMOJI_SET.map(em=>`<button data-em="${em}">${em}</button>`).join('')}</div>
    <div class="field" style="margin-top:12px;"><label>Albo wpisz własne</label>
      <div class="row"><input type="text" id="customEmoji" maxlength="4" placeholder="np. 🐸"><button id="addCustomEmoji" class="chip">Dodaj</button></div>
    </div>
    <div class="upload-btn" id="stickerUploadTrigger" style="margin-top:12px;">📤 Wgraj własną naklejkę (PNG z przezroczystością)</div>`;
  if(sel && sel.type==='emoji'){
    html += `
      <h3 style="margin-top:18px;">Ustawienia</h3>
      <div class="field"><label>Rozmiar <span>${sel.size}px</span></label><input type="range" id="emSize" min="20" max="400" value="${sel.size}"></div>
      <div class="field"><label>Rotacja <span>${sel.rotation||0}°</span></label><input type="range" id="emRot" min="-180" max="180" value="${sel.rotation||0}"></div>
      <div class="field"><label>Przezroczystość <span>${sel.opacity}%</span></label><input type="range" id="emOpacity" min="0" max="100" value="${sel.opacity}"></div>
      ${adjControlsHtml(sel)}
    `;
  } else {
    html += `<p class="hint">Wybierz emoji z listy, żeby dodać je jako naklejkę na miniaturce.</p>`;
  }
  toolpanel.innerHTML = html;
  document.getElementById('emojiGrid').querySelectorAll('button').forEach(b=>{
    b.onclick = ()=>{ addLayer({ type:'emoji', char:b.dataset.em, x:canvasW/2, y:canvasH/2, w:100,h:100, size:100, rotation:0, opacity:100 }); renderEmojiPanel(); };
  });
  document.getElementById('addCustomEmoji').onclick = ()=>{
    const v = document.getElementById('customEmoji').value.trim();
    if(!v) return;
    addLayer({ type:'emoji', char:v, x:canvasW/2, y:canvasH/2, w:100,h:100, size:100, rotation:0, opacity:100 });
    renderEmojiPanel();
  };
  document.getElementById('stickerUploadTrigger').onclick = ()=> stickerInput.click();
  if(sel && sel.type==='emoji'){
    const upd = fn=>{ fn(); render(); };
    document.getElementById('emSize').oninput = e=>upd(()=>{ sel.size=+e.target.value; sel.w=sel.size; sel.h=sel.size; });
    document.getElementById('emSize').onchange = ()=>pushHistory();
    document.getElementById('emRot').oninput = e=>upd(()=>sel.rotation=+e.target.value);
    document.getElementById('emRot').onchange = ()=>pushHistory();
    document.getElementById('emOpacity').oninput = e=>upd(()=>sel.opacity=+e.target.value);
    document.getElementById('emOpacity').onchange = ()=>pushHistory();
    bindAdjControls(sel);
  }
}

const stickerInput = document.createElement('input');
stickerInput.type = 'file';
stickerInput.accept = 'image/png,image/webp,image/svg+xml';
stickerInput.style.display = 'none';
document.body.appendChild(stickerInput);
stickerInput.addEventListener('change', (e)=>{
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = (ev)=>{
    const img = new Image();
    img.onload = ()=>{
      const maxDim = Math.min(canvasW,canvasH)*0.35;
      const ratio = Math.min(maxDim/img.width, maxDim/img.height, 1);
      const editCanvas = makeEditableCanvas(img);
      addLayer({ type:'image', canvas: editCanvas, x:canvasW/2, y:canvasH/2, w:img.width*ratio, h:img.height*ratio,
        rotation:0, opacity:100, radius:0, flipH:false, flipV:false,
        filters:{brightness:100,contrast:100,saturate:100,blur:0,grayscale:0,sepia:0},
        shadow:{enabled:false,color:'#000000',blur:20,offsetX:0,offsetY:8}, outline:{enabled:false,color:'#ffffff',width:14,glow:0} });
      currentTab='image'; renderImagePanel();
      document.querySelectorAll('.tab-btn').forEach(b=> b.classList.toggle('active', b.dataset.tab==='image'));
    };
    img.src = ev.target.result;
  };
  reader.readAsDataURL(file);
  stickerInput.value = '';
});

const vsWatermarkInput = document.createElement('input');
vsWatermarkInput.type = 'file';
vsWatermarkInput.accept = 'image/png,image/webp';
vsWatermarkInput.style.display = 'none';
document.body.appendChild(vsWatermarkInput);
vsWatermarkInput.addEventListener('change', (e)=>{
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = (ev)=>{
    const img = new Image();
    img.onload = ()=>{
      bg.split.watermark.customImg = img;
      bg.split.watermark.customSrc = ev.target.result;
      render(); renderBgPanel(); pushHistory();
    };
    img.src = ev.target.result;
  };
  reader.readAsDataURL(file);
  vsWatermarkInput.value = '';
});

const bgImageInput = document.createElement('input');
bgImageInput.type = 'file';
bgImageInput.accept = 'image/*';
bgImageInput.style.display = 'none';
document.body.appendChild(bgImageInput);
bgImageInput.addEventListener('change', (e)=>{
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = (ev)=>{
    const img = new Image();
    img.onload = ()=>{
      bg.image.img = img;
      bg.image.src = ev.target.result;
      render(); renderBgPanel(); pushHistory();
    };
    img.src = ev.target.result;
  };
  reader.readAsDataURL(file);
  bgImageInput.value = '';
});

// ---------- PANEL: EFEKTY GLOBALNE ----------
function renderFiltersPanel(){
  toolpanel.innerHTML = `
    <h3>Efekty całej miniaturki</h3>
    <div class="chip-row" style="margin-bottom:14px;">
      <button class="chip" data-fp="clean">Czysty</button>
      <button class="chip" data-fp="cinematic">Kinowy</button>
      <button class="chip" data-fp="vibrant">Soczysty</button>
      <button class="chip" data-fp="moody">Mroczny</button>
    </div>
    <div class="field"><label>Jasność <span>${effects.brightness}%</span></label><input type="range" id="efBrightness" min="0" max="200" value="${effects.brightness}"></div>
    <div class="field"><label>Kontrast <span>${effects.contrast}%</span></label><input type="range" id="efContrast" min="0" max="200" value="${effects.contrast}"></div>
    <div class="field"><label>Nasycenie <span>${effects.saturate}%</span></label><input type="range" id="efSaturate" min="0" max="200" value="${effects.saturate}"></div>
    <div class="field"><label>Winieta <span>${effects.vignette}%</span></label><input type="range" id="efVignette" min="0" max="100" value="${effects.vignette}"></div>
    <div class="field"><label>Ziarno / szum <span>${effects.grain}%</span></label><input type="range" id="efGrain" min="0" max="100" value="${effects.grain}"></div>
    <p class="hint">To działa na całą kompozycję (tło + wszystkie warstwy naraz) — tak jak filtr nakładany na koniec w Canvie czy Photoshopie.</p>
  `;
  const upd=fn=>{ fn(); render(); };
  document.getElementById('efBrightness').oninput=e=>upd(()=>effects.brightness=+e.target.value);
  document.getElementById('efBrightness').onchange=()=>pushHistory();
  document.getElementById('efContrast').oninput=e=>upd(()=>effects.contrast=+e.target.value);
  document.getElementById('efContrast').onchange=()=>pushHistory();
  document.getElementById('efSaturate').oninput=e=>upd(()=>effects.saturate=+e.target.value);
  document.getElementById('efSaturate').onchange=()=>pushHistory();
  document.getElementById('efVignette').oninput=e=>upd(()=>effects.vignette=+e.target.value);
  document.getElementById('efVignette').onchange=()=>pushHistory();
  document.getElementById('efGrain').oninput=e=>upd(()=>effects.grain=+e.target.value);
  document.getElementById('efGrain').onchange=()=>pushHistory();
  toolpanel.querySelectorAll('[data-fp]').forEach(b=>{
    b.onclick=()=>{
      const presets = {
        clean:{brightness:100,contrast:100,saturate:100,vignette:0,grain:0},
        cinematic:{brightness:95,contrast:115,saturate:90,vignette:35,grain:8},
        vibrant:{brightness:105,contrast:110,saturate:140,vignette:10,grain:0},
        moody:{brightness:85,contrast:120,saturate:80,vignette:50,grain:15}
      };
      Object.assign(effects, presets[b.dataset.fp]);
      render(); renderFiltersPanel(); pushHistory();
    };
  });
}

// ---------- PANEL: NARZĘDZIA (dawniej "Retusz") ----------
const RETOUCH_TOOLS = [
  {k:'crop', ic:'⬜', label:'Kadrowanie', desc:'Przytnij zdjęcie do wybranego fragmentu.'},
  {k:'erase', ic:'🧹', label:'Gumka / Maska', desc:'Usuwa fragmenty obrazu pędzlem. Dla precyzji zmniejsz rozmiar pędzla.'},
  {k:'bgcolor', ic:'🎯', label:'Usuń kolor tła', desc:'Kliknij na tło zdjęcia — ten kolor (z tolerancją) zniknie od razu. Świetne przy jednolitych, prostych tłach.'},
  {k:'autobg', ic:'🤖', label:'Auto-usuwanie tła', desc:'Algorytm sam wykrywa i usuwa tło łączące się z krawędziami kadru — jednym kliknięciem, bez malowania.'},
  {k:'clone', ic:'🖨️', label:'Klonowanie', desc:'Alt + klik ustawia źródło, potem maluj żeby skopiować stamtąd piksele.'},
  {k:'blur', ic:'💧', label:'Rozmycie', desc:'Rozmywa fragment pod pędzlem (np. tło, niedoskonałości).'},
  {k:'sharpen', ic:'🔎', label:'Wyostrzenie', desc:'Prawdziwa maska wyostrzająca (unsharp mask) — wzmacnia krawędzie i detale pod pędzlem.'},
  {k:'dodge', ic:'☀️', label:'Rozjaśnianie (klasyczne)', desc:'Realnie rozjaśnia piksele pod pędzlem, podnosząc jasność (HSL).'},
  {k:'dodge2', ic:'🌤️', label:'Rozjaśnianie (delikatne)', desc:'Druga odmiana — działa na kanałach RGB, jaśniejsze piksele rozjaśniają się wolniej, więc mocno malowany obszar nie robi się płaskim, białym plackiem.'},
  {k:'burn', ic:'🌑', label:'Przyciemnianie (klasyczne)', desc:'Realnie przyciemnia piksele pod pędzlem, obniżając jasność (HSL).'},
  {k:'burn2', ic:'🌥️', label:'Przyciemnianie (delikatne)', desc:'Druga odmiana na kanałach RGB — bardziej naturalne, mniej "zamula" ciemne partie.'},
  {k:'sponge', ic:'🎨', label:'Gąbka / Nasycenie', desc:'Zwiększa lub zmniejsza nasycenie kolorów pod pędzlem.'},
  {k:'draw', ic:'✏️', label:'Rysowanie', desc:'Maluje własnym kolorem na nowej warstwie rysunkowej.'}
];
function renderRetouchPanel(){
  const sel = getSelectedLayer();
  const hasImage = sel && sel.type==='image';
  let html = `<h3>Narzędzia</h3>`;
  if(!hasImage){
    html += `<p class="hint">Wybierz warstwę zdjęcia (zakładka "Obraz" albo kliknij zdjęcie na płótnie), żeby edytować. "Rysowanie" działa też bez wybranego zdjęcia — utworzy nową, pustą warstwę.</p>`;
  }
  html += `<div class="grid-buttons" id="retouchGrid" style="grid-template-columns:repeat(3,1fr);">
    ${RETOUCH_TOOLS.map(t=>`<button data-k="${t.k}" title="${t.label}" style="font-size:20px; ${retouchTool===t.k?'border-color:var(--accent); background:#242a44;':''}">${t.ic}</button>`).join('')}
  </div>`;
  if(retouchTool){
    const active = RETOUCH_TOOLS.find(t=>t.k===retouchTool);
    html += `<p class="hint" style="margin-top:10px;"><b>${active.label}:</b> ${active.desc}</p>`;
    if(retouchTool==='crop'){
      html += `
        <p class="hint">Zaznacz przeciągnięciem obszar do przycięcia, potem kliknij Zastosuj. Działa tylko gdy rotacja zdjęcia = 0°.</p>
        <div class="row">
          <button id="cropApply" class="chip active" style="flex:1;">✅ Zastosuj kadrowanie</button>
          <button id="cropCancel" class="chip" style="flex:1;">✕ Anuluj</button>
        </div>
      `;
    } else if(retouchTool==='bgcolor'){
      html += `
        <div class="row">
          <div class="field"><label>Wybrany kolor tła</label><input type="color" id="bgColorPick" value="${retouchSettings.bgColor}"></div>
          <div class="field"><label>Tolerancja <span>${retouchSettings.bgTolerance}%</span></label><input type="range" id="bgColorTol" min="1" max="100" value="${retouchSettings.bgTolerance}"></div>
        </div>
        <p class="hint">🎯 Kliknij bezpośrednio na tle zdjęcia na płótnie — ten kolor zostanie pobrany i usunięty od razu. Możesz też ustawić kolor ręcznie powyżej i kliknąć "Zastosuj".</p>
        <button id="bgColorApply" class="chip active" style="width:100%; margin-bottom:8px;">✅ Zastosuj wybrany kolor</button>
        <button id="rtDone" class="chip" style="width:100%;">✕ Zakończ narzędzie</button>
      `;
    } else if(retouchTool==='autobg'){
      html += `
        <div class="field"><label>Czułość wykrywania <span>${retouchSettings.autoTolerance}%</span></label><input type="range" id="autoBgTol" min="5" max="80" value="${retouchSettings.autoTolerance}"></div>
        <p class="hint">🤖 To NIE jest sieć neuronowa (zdjęcie nigdzie nie jest wysyłane) — algorytm analizuje krawędzie zdjęcia i usuwa spójne, podobne kolorystycznie obszary połączone z brzegiem kadru. Najlepiej działa przy prostym, jednolitym tle. Przy skomplikowanych zdjęciach lepiej sprawdzi się "Usuń kolor tła" albo Gumka.</p>
        <button id="autoBgApply" class="chip active" style="width:100%; margin-bottom:8px;">🤖 Wykryj i usuń tło automatycznie</button>
        <button id="rtDone" class="chip" style="width:100%;">✕ Zakończ narzędzie</button>
      `;
    } else {
      if(retouchTool==='draw'){
        html += `
          <div class="field"><label>Kolor pędzla</label><input type="color" id="rtColor" value="${retouchSettings.color}"></div>
          <div class="field"><label>Rozmiar <span>${retouchSettings.drawSize}px</span></label>
            <div class="row" style="align-items:center;">
              <input type="range" id="rtDrawSize" min="1" max="4000" value="${retouchSettings.drawSize}" style="flex:1;">
              <input type="number" id="rtDrawSizeNum" min="1" max="4000" value="${retouchSettings.drawSize}" class="mini-num">
            </div>
          </div>
          <div class="field"><label>Przezroczystość <span>${retouchSettings.drawOpacity}%</span></label>
            <div class="row" style="align-items:center;">
              <input type="range" id="rtDrawOpacity" min="1" max="100" value="${retouchSettings.drawOpacity}" style="flex:1;">
              <input type="number" id="rtDrawOpacityNum" min="1" max="100" value="${retouchSettings.drawOpacity}" class="mini-num">
            </div>
          </div>
          <div class="field"><label>Twardość krawędzi <span>${retouchSettings.hardness}%</span></label>
            <div class="row" style="align-items:center;">
              <input type="range" id="rtHardness" min="0" max="100" value="${retouchSettings.hardness}" style="flex:1;">
              <input type="number" id="rtHardnessNum" min="0" max="100" value="${retouchSettings.hardness}" class="mini-num">
            </div>
          </div>
        `;
      } else {
        html += `
          <div class="field"><label>Rozmiar pędzla <span>${retouchSettings.size}px</span></label>
            <div class="row" style="align-items:center;">
              <input type="range" id="rtSize" min="4" max="4000" value="${retouchSettings.size}" style="flex:1;">
              <input type="number" id="rtSizeNum" min="4" max="4000" value="${retouchSettings.size}" class="mini-num">
            </div>
          </div>
          <div class="field"><label>Twardość krawędzi <span>${retouchSettings.hardness}%</span></label>
            <div class="row" style="align-items:center;">
              <input type="range" id="rtHardness" min="0" max="100" value="${retouchSettings.hardness}" style="flex:1;">
              <input type="number" id="rtHardnessNum" min="0" max="100" value="${retouchSettings.hardness}" class="mini-num">
            </div>
          </div>
          ${retouchTool!=='erase' && retouchTool!=='clone' ? `<div class="field"><label>Siła efektu <span>${retouchSettings.strength}%</span></label>
            <div class="row" style="align-items:center;">
              <input type="range" id="rtStrength" min="1" max="100" value="${retouchSettings.strength}" style="flex:1;">
              <input type="number" id="rtStrengthNum" min="1" max="100" value="${retouchSettings.strength}" class="mini-num">
            </div>
          </div>` : ''}
          ${retouchTool==='sponge' ? `<div class="chip-row">
            <button class="chip ${retouchSettings.saturateUp?'active':''}" id="rtSatUp">Zwiększ nasycenie</button>
            <button class="chip ${!retouchSettings.saturateUp?'active':''}" id="rtSatDown">Zmniejsz nasycenie</button>
          </div>` : ''}
          ${retouchTool==='clone' ? `<p class="hint">${cloneSource? '✅ Źródło ustawione — maluj, żeby kopiować.' : '⚠️ Najpierw Alt + klik na obrazie, żeby ustawić źródło.'}</p>` : ''}
        `;
      }
      html += `<button id="rtDone" class="chip" style="width:100%; margin-top:8px;">✕ Zakończ narzędzie</button>`;
    }
  }
  toolpanel.innerHTML = html;

  document.getElementById('retouchGrid').querySelectorAll('button').forEach(b=>{
    b.onclick = ()=>{
      const k = b.dataset.k;
      if(k!=='draw'){
        const s = getSelectedLayer();
        if(!s || s.type!=='image'){ alert('Najpierw kliknij zdjęcie na płótnie (albo na liście Warstwy po prawej), żeby je zaznaczyć — dopiero wtedy narzędzie zadziała.'); return; }
      }
      retouchTool = (retouchTool===k) ? null : k;
      cloneSource = null; cropState = null;
      mainCanvas.style.cursor = retouchTool ? 'crosshair' : 'default';
      render(); renderRetouchPanel();
    };
  });

  const cropApply = document.getElementById('cropApply'), cropCancel = document.getElementById('cropCancel');
  if(cropApply) cropApply.onclick = applyCrop;
  if(cropCancel) cropCancel.onclick = ()=>{ cancelCrop(); retouchTool=null; renderRetouchPanel(); };

  const rtDone = document.getElementById('rtDone');
  if(rtDone) rtDone.onclick = ()=>{ retouchTool=null; cloneSource=null; mainCanvas.style.cursor='default'; render(); renderRetouchPanel(); };

  const rtSize = document.getElementById('rtSize'), rtHardness = document.getElementById('rtHardness'), rtStrength = document.getElementById('rtStrength');
  const rtSizeNum = document.getElementById('rtSizeNum'), rtHardnessNum = document.getElementById('rtHardnessNum'), rtStrengthNum = document.getElementById('rtStrengthNum');
  if(rtSize) rtSize.oninput = e=>{ retouchSettings.size=+e.target.value; renderRetouchPanel(); };
  if(rtSizeNum) rtSizeNum.oninput = e=>{ const v=Math.max(4,Math.min(4000,+e.target.value||4)); retouchSettings.size=v; renderRetouchPanel(); };
  if(rtHardness) rtHardness.oninput = e=>{ retouchSettings.hardness=+e.target.value; renderRetouchPanel(); };
  if(rtHardnessNum) rtHardnessNum.oninput = e=>{ const v=Math.max(0,Math.min(100,+e.target.value||0)); retouchSettings.hardness=v; renderRetouchPanel(); };
  if(rtStrength) rtStrength.oninput = e=>{ retouchSettings.strength=+e.target.value; renderRetouchPanel(); };
  if(rtStrengthNum) rtStrengthNum.oninput = e=>{ const v=Math.max(1,Math.min(100,+e.target.value||1)); retouchSettings.strength=v; renderRetouchPanel(); };
  const rtColor = document.getElementById('rtColor'), rtDrawSize = document.getElementById('rtDrawSize'), rtDrawSizeNum = document.getElementById('rtDrawSizeNum'), rtDrawOpacity = document.getElementById('rtDrawOpacity'), rtDrawOpacityNum = document.getElementById('rtDrawOpacityNum');
  if(rtColor) rtColor.oninput = e=>{ retouchSettings.color=e.target.value; };
  if(rtDrawSize) rtDrawSize.oninput = e=>{ retouchSettings.drawSize=+e.target.value; renderRetouchPanel(); };
  if(rtDrawSizeNum) rtDrawSizeNum.oninput = e=>{ const v=Math.max(1,Math.min(4000,+e.target.value||1)); retouchSettings.drawSize=v; renderRetouchPanel(); };
  if(rtDrawOpacity) rtDrawOpacity.oninput = e=>{ retouchSettings.drawOpacity=+e.target.value; renderRetouchPanel(); };
  if(rtDrawOpacityNum) rtDrawOpacityNum.oninput = e=>{ const v=Math.max(1,Math.min(100,+e.target.value||1)); retouchSettings.drawOpacity=v; renderRetouchPanel(); };
  const satUp = document.getElementById('rtSatUp'), satDown = document.getElementById('rtSatDown');
  if(satUp) satUp.onclick = ()=>{ retouchSettings.saturateUp=true; renderRetouchPanel(); };
  if(satDown) satDown.onclick = ()=>{ retouchSettings.saturateUp=false; renderRetouchPanel(); };

  const bgColorPick = document.getElementById('bgColorPick'), bgColorTol = document.getElementById('bgColorTol'), bgColorApply = document.getElementById('bgColorApply');
  if(bgColorPick) bgColorPick.oninput = e=>{ retouchSettings.bgColor=e.target.value; };
  if(bgColorTol) bgColorTol.oninput = e=>{ retouchSettings.bgTolerance=+e.target.value; renderRetouchPanel(); };
  if(bgColorApply) bgColorApply.onclick = ()=>{
    const s = getSelectedLayer();
    if(!s || s.type!=='image') return;
    removeColorFromLayer(s, retouchSettings.bgColor, retouchSettings.bgTolerance);
    render(); pushHistory();
  };
  const autoBgTol = document.getElementById('autoBgTol'), autoBgApply = document.getElementById('autoBgApply');
  if(autoBgTol) autoBgTol.oninput = e=>{ retouchSettings.autoTolerance=+e.target.value; renderRetouchPanel(); };
  if(autoBgApply) autoBgApply.onclick = ()=>{
    const s = getSelectedLayer();
    if(!s || s.type!=='image') return;
    autoRemoveBackground(s, retouchSettings.autoTolerance);
    render(); pushHistory();
  };
}

// ---------- SERIALIZACJA (do historii i zapisu projektu) ----------
function serializeState(){
  return {
    canvasW, canvasH,
    bg: JSON.parse(JSON.stringify(bg, (k,v)=> (k==='customImg'||k==='img') ? undefined : v)),
    effects: JSON.parse(JSON.stringify(effects)),
    layers: layers.map(l=>{
      const copy = JSON.parse(JSON.stringify(l, (k,v)=> (k==='canvas'||k==='img') ? undefined : v));
      if(l.type==='image' && l.canvas) copy.imgSrc = l.canvas.toDataURL('image/png');
      return copy;
    }),
    selectedId
  };
}

function loadState(state, cb){
  canvasW = state.canvasW; canvasH = state.canvasH;
  mainCanvas.width = canvasW; mainCanvas.height = canvasH;
  fitStageToView();
  bg = state.bg;
  effects = state.effects;
  selectedId = state.selectedId;
  let pending = 0;
  if(bg.split && bg.split.watermark && bg.split.watermark.customSrc){
    pending++;
    const wmImg = new Image();
    wmImg.onload = ()=>{ bg.split.watermark.customImg = wmImg; pending--; if(pending===0){ layers = newLayersRef; render(); if(cb) cb(); } };
    wmImg.src = bg.split.watermark.customSrc;
  }
  if(bg.image && bg.image.src){
    pending++;
    const bgImg = new Image();
    bgImg.onload = ()=>{ bg.image.img = bgImg; pending--; if(pending===0){ layers = newLayersRef; render(); if(cb) cb(); } };
    bgImg.src = bg.image.src;
  }
  const newLayers = state.layers.map(l=>JSON.parse(JSON.stringify(l)));
  var newLayersRef = newLayers;
  newLayers.forEach(l=>{
    if(l.type==='image' && l.imgSrc){
      pending++;
      const img = new Image();
      img.onload = ()=>{
        const cnv = document.createElement('canvas');
        cnv.width = img.width; cnv.height = img.height;
        cnv.getContext('2d').drawImage(img,0,0);
        l.canvas = cnv;
        pending--; if(pending===0){ layers = newLayers; render(); if(cb) cb(); }
      };
      img.src = l.imgSrc;
    }
  });
  layers = newLayers;
  if(pending===0){ render(); if(cb) cb(); }
  renderToolPanel();
}

function pushHistory(){
  if(suppressHistory) return;
  history = history.slice(0, historyIndex+1);
  history.push(serializeState());
  if(history.length>60) history.shift();
  historyIndex = history.length-1;
}

function undo(){
  if(historyIndex<=0) return;
  historyIndex--;
  suppressHistory = true;
  loadState(JSON.parse(JSON.stringify(history[historyIndex])), ()=>{ suppressHistory=false; });
}
function redo(){
  if(historyIndex>=history.length-1) return;
  historyIndex++;
  suppressHistory = true;
  loadState(JSON.parse(JSON.stringify(history[historyIndex])), ()=>{ suppressHistory=false; });
}
document.getElementById('undoBtn').onclick = undo;
document.getElementById('redoBtn').onclick = redo;

window.addEventListener('keydown',(e)=>{
  const tag = (e.target.tagName||'').toLowerCase();
  if(tag==='input' || tag==='textarea') return;
  if((e.ctrlKey||e.metaKey) && e.key==='z' && !e.shiftKey){ e.preventDefault(); undo(); }
  if((e.ctrlKey||e.metaKey) && (e.key==='y' || (e.key==='z'&&e.shiftKey))){ e.preventDefault(); redo(); }
  if((e.key==='Delete'||e.key==='Backspace') && selectedId){ e.preventDefault(); deleteLayer(selectedId); }
});

// ---------- ROZMIAR PŁÓTNA (PRESETY) ----------
const presetSelect = document.getElementById('presetSelect');
const customSizeBox = document.getElementById('customSizeBox');
presetSelect.onchange = ()=>{
  if(presetSelect.value==='custom'){
    customSizeBox.style.display='flex';
    return;
  }
  customSizeBox.style.display='none';
  const [w,h] = presetSelect.value.split('x').map(Number);
  setCanvasSize(w,h);
  pushHistory();
};
document.getElementById('applyCustomSize').onclick = ()=>{
  const w = Math.max(100, Math.min(4000, +document.getElementById('customW').value||1280));
  const h = Math.max(100, Math.min(4000, +document.getElementById('customH').value||720));
  setCanvasSize(w,h);
  pushHistory();
};

// ---------- ZAPIS / WCZYTANIE PROJEKTU ----------
document.getElementById('saveProjectBtn').onclick = ()=>{
  const data = JSON.stringify(serializeState());
  const blob = new Blob([data], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'miniaturka-projekt.json';
  a.click();
  setTimeout(()=>URL.revokeObjectURL(url), 2000);
};
document.getElementById('loadProjectBtn').onclick = ()=> projectInput.click();
projectInput.addEventListener('change', (e)=>{
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = (ev)=>{
    try{
      const state = JSON.parse(ev.target.result);
      loadState(state, ()=>{ pushHistory(); });
    }catch(err){ alert('Nie udało się wczytać projektu — plik jest uszkodzony.'); }
  };
  reader.readAsText(file);
  projectInput.value = '';
});

// ---------- EKSPORT PNG ----------
document.getElementById('exportBtn').onclick = ()=>{
  const temp = document.createElement('canvas');
  temp.width = canvasW; temp.height = canvasH;
  const tctx = temp.getContext('2d');
  renderComposite(tctx, canvasW, canvasH);
  temp.toBlob((blob)=>{
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'miniaturka.png';
    a.click();
    setTimeout(()=>URL.revokeObjectURL(url), 2000);
  }, 'image/png');
};

// ---------- PODGLĄD YOUTUBE (jak wyglada w realnym, malym rozmiarze) ----------
const ytPreviewModal = document.getElementById('ytPreviewModal');
document.getElementById('ytPreviewBtn').onclick = ()=>{
  const temp = document.createElement('canvas');
  temp.width = canvasW; temp.height = canvasH;
  renderComposite(temp.getContext('2d'), canvasW, canvasH);

  ['ytPrevCanvasSmall','ytPrevCanvasMed','ytPrevCanvasTiny'].forEach(id=>{
    const target = document.getElementById(id);
    const tctx = target.getContext('2d');
    tctx.clearRect(0,0,target.width,target.height);
    // "cover" - wypelnij caly maly kadr zachowujac proporcje (tak jak robi YouTube)
    const scale = Math.max(target.width/canvasW, target.height/canvasH);
    const dw = canvasW*scale, dh = canvasH*scale;
    tctx.drawImage(temp, (target.width-dw)/2, (target.height-dh)/2, dw, dh);
  });

  ytPreviewModal.style.display = 'flex';
};
document.getElementById('ytPreviewClose').onclick = ()=>{ ytPreviewModal.style.display = 'none'; };
ytPreviewModal.addEventListener('click', (e)=>{ if(e.target===ytPreviewModal) ytPreviewModal.style.display='none'; });

// ---------- INIT ----------
function init(){
  setCanvasSize(canvasW, canvasH);
  renderToolPanel();
  renderLayerList();
  pushHistory();

  // integracja z appką Sigmanek (jeśli dostępna)
  if(window.sigmanek){
    try{ window.sigmanek.perf && window.sigmanek.perf.getStatus && window.sigmanek.perf.getStatus(); }catch(e){}
  }
}
init();
